import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { GoogleGenAI, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;

function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in the server environment.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '15mb' }));

  // Real AI Translation endpoint (gemini-4-hydrogen)
  app.post('/api/ai/translate', async (req, res) => {
    try {
      const { text, sourceLang, targetLang } = req.body as {
        text?: string;
        sourceLang?: string;
        targetLang?: string;
      };
      if (!text || !text.trim() || !targetLang) {
        res.status(400).json({ error: 'Both text and targetLang are required.' });
        return;
      }

      const ai = getAiClient();
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Translate the following text into ${targetLang}. Source language hint: ${sourceLang || 'auto'}. Preserve meaning, punctuation, and Arabic diacritics if appropriate.\n\nText:\n${text}`,
        config: {
          systemInstruction:
            'You are a precise multilingual translator for a smart keyboard. Return JSON with detectedSourceLang and translatedText only.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              detectedSourceLang: { type: Type.STRING },
              translatedText: { type: Type.STRING },
            },
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim()) as {
        detectedSourceLang?: string;
        translatedText?: string;
      };
      res.json({
        detectedSourceLang: parsed.detectedSourceLang || sourceLang || 'auto',
        translatedText: parsed.translatedText || '',
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Translation failed.';
      res.status(500).json({ error: message });
    }
  });

  // Real AI Writing Assistant endpoint (gemini-4-hydrogen)
  app.post('/api/ai/assist', async (req, res) => {
    try {
      const { text, action, language } = req.body as {
        text?: string;
        action?: string;
        language?: string;
      };
      if (!text || !text.trim() || !action) {
        res.status(400).json({ error: 'Text and action are required.' });
        return;
      }

      const actionInstructions: Record<string, string> = {
        rephrase: 'Rephrase the text clearly while preserving its original meaning and language.',
        grammar: 'Correct grammar, spelling, and punctuation errors in the original language.',
        improve_style: 'Improve flow, clarity, and natural phrasing in the original language.',
        formal: 'Rewrite in a polished, formal tone suitable for business or official messages.',
        friendly: 'Rewrite in a warm, friendly, conversational tone.',
        shorten: 'Make the text concise and brief without losing key meaning.',
        expand: 'Expand slightly with helpful clarity and polite detail.',
        summarize: 'Provide a crisp 1-2 sentence summary in the same language.',
        replies: 'Suggest 3 short natural replies to this message.',
        professional_email: 'Polish this into a clear, professional message.',
        proofread_ar_en: 'Proofread Arabic and/or English carefully, fixing spelling, hamza, and punctuation.',
      };

      const instruction = actionInstructions[action] || actionInstructions.rephrase;
      const ai = getAiClient();
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `${instruction}\nTarget/Context Language: ${language || 'auto'}.\n\nInput text:\n${text}`,
        config: {
          systemInstruction:
            'You are Lisan AI Writing Assistant. Return JSON with primaryResult (string) and alternatives (array of strings, up to 3 items). Never wrap in markdown.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              primaryResult: { type: Type.STRING },
              alternatives: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim()) as {
        primaryResult?: string;
        alternatives?: string[];
      };
      res.json({
        primaryResult: parsed.primaryResult || '',
        alternatives: Array.isArray(parsed.alternatives) ? parsed.alternatives : [],
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Writing assistant failed.';
      res.status(500).json({ error: message });
    }
  });

  // Real Audio Transcription endpoint (gemini-3.5-transcribe)
  app.post('/api/ai/transcribe', async (req, res) => {
    try {
      const { audioBase64, mimeType, languageHint } = req.body as {
        audioBase64?: string;
        mimeType?: string;
        languageHint?: string;
      };
      if (!audioBase64) {
        res.status(400).json({ error: 'Audio payload is required.' });
        return;
      }

      const ai = getAiClient();
      const promptText =
        languageHint && languageHint !== 'auto'
          ? `Transcribe this spoken audio accurately in ${languageHint} with natural punctuation. Return only the transcribed text.`
          : 'Auto-detect the spoken language (Arabic, English, or other) and transcribe accurately with natural punctuation. Return only the transcribed text.';

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-transcribe',
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: mimeType || 'audio/webm',
                data: audioBase64,
              },
            },
            { text: promptText },
          ],
        },
      });

      res.json({ transcript: (response.text ?? '').trim() });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Audio transcription failed.';
      res.status(500).json({ error: message });
    }
  });

  // Vite dev middleware or static dist serving
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Lisan AI Keyboard server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
