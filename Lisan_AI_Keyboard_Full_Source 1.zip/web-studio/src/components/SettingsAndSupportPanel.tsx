import React, { useState } from 'react';
import {
  Check,
  Copy,
  Download,
  Mail,
  Pause,
  Play,
  RotateCcw,
  Share2,
  ShieldCheck,
  Trash2,
  Upload,
} from 'lucide-react';
import type { KeyboardLangCode, LanguagePackItem, LisanSettings, UiLanguage } from '../types/lisan';

interface SettingsAndSupportPanelProps {
  uiLang: UiLanguage;
  settings: LisanSettings;
  onUpdateSettings: (patch: Partial<LisanSettings>) => void;
  onResetAllSettings: () => void;
  onExportBackup: () => void;
  onImportBackup: (json: string) => boolean;
  onWipeLocalData: () => void;
  languagePacks: LanguagePackItem[];
  onToggleLanguagePack: (code: KeyboardLangCode) => void;
  onSetDefaultLanguagePack: (code: KeyboardLangCode) => void;
  onDownloadLanguageModel: (code: KeyboardLangCode, kind: 'dict' | 'model', action: 'start' | 'pause' | 'delete') => void;
  personalWords: string[];
  onRemovePersonalWord: (word: string) => void;
  ignoredWords: string[];
  onRemoveIgnoredWord: (word: string) => void;
}

export const SettingsAndSupportPanel: React.FC<SettingsAndSupportPanelProps> = ({
  uiLang,
  settings,
  onUpdateSettings,
  onResetAllSettings,
  onExportBackup,
  onImportBackup,
  onWipeLocalData,
  languagePacks,
  onToggleLanguagePack,
  onSetDefaultLanguagePack,
  onDownloadLanguageModel,
  personalWords,
  onRemovePersonalWord,
  ignoredWords,
  onRemoveIgnoredWord,
}) => {
  const isAr = uiLang === 'ar';
  const [subView, setSubView] = useState<'languages' | 'settings20' | 'privacy_support'>('settings20');
  const [langSearch, setLangSearch] = useState('');
  const [backupInput, setBackupInput] = useState('');
  const [backupMessage, setBackupMessage] = useState<string | null>(null);

  // Support / Contact Developer state
  const [issueType, setIssueType] = useState('Keyboard Layout / Arabic');
  const [issueDesc, setIssueDesc] = useState('');
  const [includeDeviceInfo, setIncludeDeviceInfo] = useState(true);
  const [includeRedactedLogs, setIncludeRedactedLogs] = useState(false);
  const [reportFeedback, setReportFeedback] = useState<string | null>(null);

  const filteredPacks = languagePacks.filter(
    (p) =>
      p.nameEn.toLowerCase().includes(langSearch.toLowerCase()) ||
      p.nameAr.includes(langSearch) ||
      p.nativeName.toLowerCase().includes(langSearch.toLowerCase())
  );

  const totalInstalledStorageMb = languagePacks.reduce((acc, p) => {
    let sum = acc;
    if (p.dictStatus === 'installed') sum += p.dictSizeMb;
    if (p.modelStatus === 'installed') sum += p.mlModelSizeMb;
    return sum;
  }, 0);

  const buildReportPayload = () => {
    const lines = [
      `Issue Category: ${issueType}`,
      `Description: ${issueDesc || '(No description entered)'}`,
      `App Version: Lisan AI Keyboard 1.0.0`,
    ];
    if (includeDeviceInfo) {
      lines.push(`Platform/Browser: ${navigator.userAgent}`);
      lines.push(`UI Language: ${settings.appUiLang} | Keyboard Language: ${settings.keyboardLang}`);
    }
    if (includeRedactedLogs) {
      lines.push(`Redacted Diagnostics: No personal typed text, passwords, or clipboard contents attached.`);
    }
    return lines.join('\n');
  };

  const handleMailtoSupport = () => {
    const subject = encodeURIComponent(`Lisan AI Keyboard – ${issueType}`);
    const body = encodeURIComponent(buildReportPayload());
    window.location.href = `mailto:nidalwatfa99@gmail.com?subject=${subject}&body=${body}`;
    setReportFeedback(
      isAr
        ? 'تم فتح تطبيق البريد الإلكتروني. إذا لم يفتح تلقائياً، استخدم زر نسخ التقرير أدناه.'
        : 'Email client triggered. If no email app opened, use Copy Report below.'
    );
  };

  const handleCopyReport = async () => {
    try {
      await navigator.clipboard.writeText(`To: nidalwatfa99@gmail.com\n\n${buildReportPayload()}`);
      setReportFeedback(isAr ? 'تم نسخ التقرير إلى الحافظة.' : 'Report copied to clipboard.');
    } catch {
      setReportFeedback(isAr ? 'تعذر النسخ التلقائي.' : 'Could not copy automatically.');
    }
  };

  const handleShareApp = async () => {
    const shareData = {
      title: 'Lisan AI Keyboard – لسان',
      text: isAr
        ? 'جرب لوحة مفاتيح لسان الذكية متعددة اللغات: اكتب، تحدث، ترجم... بلغتك وبكل اللغات.'
        : 'Try Lisan AI Keyboard – Write, speak, and translate in Arabic, English, and more.',
      url: window.location.href,
    };
    if (navigator.share) {
      try {
        await navigator.share(shareData);
        return;
      } catch {
        // User cancelled or unsupported
      }
    }
    try {
      await navigator.clipboard.writeText(`${shareData.title}\n${shareData.text}\n${shareData.url}`);
      setReportFeedback(isAr ? 'تم نسخ رابط المشاركة.' : 'Share link copied to clipboard.');
    } catch {
      setReportFeedback(window.location.href);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 flex-wrap border-b border-slate-200 dark:border-slate-800 pb-3">
        {[
          { id: 'settings20', ar: 'مركز الإعدادات الكامل (20 قسماً)', en: 'All 20 Settings Sections' },
          { id: 'languages', ar: 'مدير اللغات والحزم', en: 'Language & Pack Manager' },
          { id: 'privacy_support', ar: 'الخصوصية والدعم والمشاركة', en: 'Privacy, Support & Deliverables' },
        ].map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setSubView(item.id as typeof subView)}
            className={`px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap cursor-pointer ${
              subView === item.id
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            {isAr ? item.ar : item.en}
          </button>
        ))}
      </div>

      {/* LANGUAGE PACKS & INDEPENDENT LANGUAGE SETTINGS */}
      {subView === 'languages' && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <label className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5 block text-xs">
              <span className="font-semibold block">{isAr ? '1. لغة لوحة المفاتيح' : '1. Keyboard Layout'}</span>
              <select
                value={settings.keyboardLang}
                onChange={(e) => onUpdateSettings({ keyboardLang: e.target.value as KeyboardLangCode })}
                className="w-full px-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
              >
                {languagePacks.map((p) => (
                  <option key={p.code} value={p.code}>
                    {p.nativeName} ({p.nameEn})
                  </option>
                ))}
              </select>
            </label>

            <label className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5 block text-xs">
              <span className="font-semibold block">{isAr ? '2. لغة التعرف الصوتي' : '2. Voice Recognition'}</span>
              <select
                value={settings.voiceLang}
                onChange={(e) => onUpdateSettings({ voiceLang: e.target.value })}
                className="w-full px-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
              >
                <option value="auto">{isAr ? 'كشف تلقائي' : 'Auto Detect'}</option>
                <option value="Arabic">العربية</option>
                <option value="English">English</option>
                <option value="French">Français</option>
                <option value="Spanish">Español</option>
              </select>
            </label>

            <label className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5 block text-xs">
              <span className="font-semibold block">{isAr ? '3. لغة هدف الترجمة' : '3. Translation Target'}</span>
              <select
                value={settings.translationTargetLang}
                onChange={(e) => onUpdateSettings({ translationTargetLang: e.target.value })}
                className="w-full px-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
              >
                <option value="en">English</option>
                <option value="ar">العربية</option>
                <option value="fr">Français</option>
                <option value="es">Español</option>
                <option value="tr">Türkçe</option>
                <option value="de">Deutsch</option>
              </select>
            </label>

            <label className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5 block text-xs">
              <span className="font-semibold block">{isAr ? '4. لغة واجهة التطبيق' : '4. App Interface Language'}</span>
              <select
                value={settings.appUiLang}
                onChange={(e) => onUpdateSettings({ appUiLang: e.target.value as UiLanguage })}
                className="w-full px-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
              >
                <option value="ar">العربية (RTL)</option>
                <option value="en">English (LTR)</option>
              </select>
            </label>
          </div>

          <div className="flex items-center justify-between gap-3 flex-wrap">
            <input
              type="text"
              value={langSearch}
              onChange={(e) => setLangSearch(e.target.value)}
              placeholder={isAr ? 'ابحث عن لغة بالاسم...' : 'Search language by name...'}
              className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-xs min-w-[240px]"
            />
            <span className="text-xs text-slate-500 tabular-nums">
              {isAr
                ? `المساحة المستخدمة للحزم: ${totalInstalledStorageMb.toFixed(1)} MB`
                : `Installed Pack Storage: ${totalInstalledStorageMb.toFixed(1)} MB`}
            </span>
          </div>

          <div className="space-y-2.5">
            {filteredPacks.map((pack) => (
              <div
                key={pack.code}
                className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2 text-sm font-semibold">
                    <span>{pack.nativeName}</span>
                    <span className="text-xs font-normal text-slate-500">· {pack.nameEn} ({pack.dir.toUpperCase()})</span>
                    {pack.isDefault && (
                      <span className="text-xs text-indigo-500 font-medium">· {isAr ? 'افتراضية' : 'Default'}</span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 tabular-nums mt-0.5">
                    {isAr ? 'القاموس:' : 'Dictionary:'} {pack.dictSizeMb} MB ({pack.dictStatus}) ·{' '}
                    {isAr ? 'نموذج الترجمة (ML Kit):' : 'Translation Model (ML Kit):'} {pack.mlModelSizeMb} MB ({pack.modelStatus})
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={() => onToggleLanguagePack(pack.code)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer ${
                      pack.enabledOnKeyboard
                        ? 'bg-emerald-600 text-white'
                        : 'border border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    {pack.enabledOnKeyboard ? (isAr ? 'مفعلة في الكيبورد' : 'Enabled') : isAr ? 'إضافة للكيبورد' : 'Enable'}
                  </button>

                  {!pack.isDefault && (
                    <button
                      type="button"
                      onClick={() => onSetDefaultLanguagePack(pack.code)}
                      className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs cursor-pointer"
                    >
                      {isAr ? 'تعيين كافتراضية' : 'Set Default'}
                    </button>
                  )}

                  {pack.modelStatus === 'installed' ? (
                    <button
                      type="button"
                      onClick={() => onDownloadLanguageModel(pack.code, 'model', 'delete')}
                      className="px-2.5 py-1.5 rounded-lg text-xs text-rose-500 border border-rose-500/30 cursor-pointer"
                    >
                      {isAr ? 'حذف النموذج' : 'Delete Model'}
                    </button>
                  ) : pack.modelStatus === 'downloading' ? (
                    <button
                      type="button"
                      onClick={() => onDownloadLanguageModel(pack.code, 'model', 'pause')}
                      className="px-3 py-1.5 rounded-lg bg-amber-600 text-white text-xs flex items-center gap-1 cursor-pointer tabular-nums"
                    >
                      <Pause className="w-3 h-3" /> {pack.progress}%
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => onDownloadLanguageModel(pack.code, 'model', 'start')}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs flex items-center gap-1 cursor-pointer"
                    >
                      {pack.modelStatus === 'paused' ? <Play className="w-3 h-3" /> : <Download className="w-3 h-3" />}
                      {pack.modelStatus === 'paused'
                        ? isAr
                          ? 'استئناف'
                          : 'Resume'
                        : isAr
                          ? 'تنزيل نموذج ML Kit'
                          : 'Download Model'}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ALL 20 SETTINGS SECTIONS */}
      {subView === 'settings20' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            {
              num: '01',
              ar: 'الإعدادات العامة',
              en: 'General Settings',
              body: (
                <div className="space-y-2 text-xs">
                  <label className="flex items-center justify-between">
                    <span>{isAr ? 'لغة واجهة التطبيق' : 'App Interface Language'}</span>
                    <select
                      value={settings.appUiLang}
                      onChange={(e) => onUpdateSettings({ appUiLang: e.target.value as UiLanguage })}
                      className="px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-transparent"
                    >
                      <option value="ar">العربية</option>
                      <option value="en">English</option>
                    </select>
                  </label>
                  <label className="flex items-center justify-between">
                    <span>{isAr ? 'الوضع الليلي للوحة التحكم' : 'Studio Dark Mode'}</span>
                    <input
                      type="checkbox"
                      checked={settings.appDarkMode}
                      onChange={(e) => onUpdateSettings({ appDarkMode: e.target.checked })}
                      className="accent-indigo-600"
                    />
                  </label>
                </div>
              ),
            },
            {
              num: '02',
              ar: 'إعدادات لوحة المفاتيح',
              en: 'Keyboard Behavior',
              body: (
                <div className="space-y-2 text-xs">
                  <label className="flex items-center justify-between">
                    <span>{isAr ? 'اهتزاز اللمس (ms)' : 'Haptic Duration (ms)'}</span>
                    <input
                      type="range"
                      min={0}
                      max={40}
                      value={settings.hapticMs}
                      onChange={(e) => onUpdateSettings({ hapticMs: Number(e.target.value) })}
                      className="accent-indigo-600"
                    />
                  </label>
                  <label className="flex items-center justify-between">
                    <span>{isAr ? 'صوت نقر المفاتيح' : 'Keypress Sound'}</span>
                    <input
                      type="checkbox"
                      checked={settings.keypressSound}
                      onChange={(e) => onUpdateSettings({ keypressSound: e.target.checked })}
                      className="accent-indigo-600"
                    />
                  </label>
                </div>
              ),
            },
            {
              num: '03',
              ar: 'اللغات والتخطيطات',
              en: 'Languages & Layouts',
              body: (
                <div className="space-y-2 text-xs">
                  <label className="flex items-center justify-between">
                    <span>{isAr ? 'اللغة النشطة' : 'Active Layout'}</span>
                    <select
                      value={settings.keyboardLang}
                      onChange={(e) => onUpdateSettings({ keyboardLang: e.target.value as KeyboardLangCode })}
                      className="px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-transparent"
                    >
                      <option value="ar">العربية</option>
                      <option value="en">English</option>
                    </select>
                  </label>
                  <button
                    type="button"
                    onClick={() => setSubView('languages')}
                    className="text-indigo-500 hover:underline cursor-pointer"
                  >
                    {isAr ? 'فتح مدير اللغات الكامل →' : 'Open Language Manager →'}
                  </button>
                </div>
              ),
            },
            {
              num: '04',
              ar: 'إعدادات الترجمة',
              en: 'Translation Settings',
              body: (
                <div className="space-y-2 text-xs">
                  <label className="flex items-center justify-between">
                    <span>{isAr ? 'السماح بالترجمة السحابية عند الطلب' : 'Allow On-Demand Cloud Translation'}</span>
                    <input
                      type="checkbox"
                      checked={settings.enableCloudTranslation}
                      onChange={(e) => onUpdateSettings({ enableCloudTranslation: e.target.checked })}
                      className="accent-indigo-600"
                    />
                  </label>
                  <label className="flex items-center justify-between">
                    <span>{isAr ? 'لغة الهدف الافتراضية' : 'Default Target Language'}</span>
                    <select
                      value={settings.translationTargetLang}
                      onChange={(e) => onUpdateSettings({ translationTargetLang: e.target.value })}
                      className="px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-transparent"
                    >
                      <option value="en">English</option>
                      <option value="ar">العربية</option>
                      <option value="fr">Français</option>
                    </select>
                  </label>
                </div>
              ),
            },
            {
              num: '05',
              ar: 'إعدادات الصوت والميكروفون',
              en: 'Voice & Microphone',
              body: (
                <div className="space-y-2 text-xs">
                  <label className="flex items-center justify-between">
                    <span>{isAr ? 'تفضيل التعرف الصوتي دون اتصال (Android)' : 'Prefer Offline Speech Engine (Android)'}</span>
                    <input
                      type="checkbox"
                      checked={settings.preferOfflineVoice}
                      onChange={(e) => onUpdateSettings({ preferOfflineVoice: e.target.checked })}
                      className="accent-indigo-600"
                    />
                  </label>
                  <p className="text-slate-500">{isAr ? 'لا يتم تسجيل الصوت أبداً في الخلفية.' : 'Never records audio in background.'}</p>
                </div>
              ),
            },
            {
              num: '06',
              ar: 'إعدادات التصحيح التلقائي',
              en: 'Autocorrect Engine',
              body: (
                <div className="space-y-2 text-xs">
                  <label className="flex items-center justify-between">
                    <span>{isAr ? 'مستوى التصحيح التلقائي' : 'Autocorrect Intensity'}</span>
                    <select
                      value={settings.autocorrectLevel}
                      onChange={(e) => onUpdateSettings({ autocorrectLevel: Number(e.target.value) as 0 | 1 | 2 | 3 })}
                      className="px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-transparent"
                    >
                      <option value={0}>{isAr ? 'متوقف' : 'Off'}</option>
                      <option value={1}>{isAr ? 'خفيف' : 'Gentle'}</option>
                      <option value={2}>{isAr ? 'قياسي' : 'Standard'}</option>
                      <option value={3}>{isAr ? 'صارم' : 'Strict'}</option>
                    </select>
                  </label>
                  <label className="flex items-center justify-between">
                    <span>{isAr ? 'حماية التشكيل العربي وعدم حذفه' : 'Preserve Arabic Diacritics'}</span>
                    <input
                      type="checkbox"
                      checked={settings.preserveArabicDiacritics}
                      onChange={(e) => onUpdateSettings({ preserveArabicDiacritics: e.target.checked })}
                      className="accent-indigo-600"
                    />
                  </label>
                </div>
              ),
            },
            {
              num: '07',
              ar: 'التنبؤ بالكلمات والقاموس الشخصي',
              en: 'Word Prediction & Personal Dict',
              body: (
                <div className="space-y-2 text-xs">
                  <label className="flex items-center justify-between">
                    <span>{isAr ? 'تفعيل شريط الاقتراحات' : 'Enable Word Predictions'}</span>
                    <input
                      type="checkbox"
                      checked={settings.enablePredictions}
                      onChange={(e) => onUpdateSettings({ enablePredictions: e.target.checked })}
                      className="accent-indigo-600"
                    />
                  </label>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {personalWords.length === 0 ? (
                      <span className="text-slate-500">{isAr ? 'لا توجد كلمات شخصية مضافة.' : 'No personal words yet.'}</span>
                    ) : (
                      personalWords.map((w) => (
                        <button
                          key={w}
                          type="button"
                          onClick={() => onRemovePersonalWord(w)}
                          className="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-xs cursor-pointer"
                          title="Click to remove"
                        >
                          {w} ×
                        </button>
                      ))
                    )}
                    {ignoredWords.map((w) => (
                      <button
                        key={w}
                        type="button"
                        onClick={() => onRemoveIgnoredWord(w)}
                        className="px-2 py-0.5 rounded bg-rose-500/10 text-rose-500 text-xs cursor-pointer"
                      >
                        {isAr ? 'متجاهلة:' : 'Ignored:'} {w} ×
                      </button>
                    ))}
                  </div>
                </div>
              ),
            },
            {
              num: '08–10',
              ar: 'الخطوط والأحجام والسمات والأبعاد',
              en: 'Fonts, Themes & Dimensions',
              body: (
                <p className="text-xs text-slate-500">
                  {isAr
                    ? 'متوفرة بالكامل في تبويب «التصميم والتخصيص» مع معاينة حية فورية للارتفاع والعرض والألوان والخطوط.'
                    : 'Configured live in the Design & Themes Studio tab (height, width, spacing, radii, colors, and open-license fonts).'}
                </p>
              ),
            },
            {
              num: '11',
              ar: 'الإيموجي والرموز',
              en: 'Emoji & Symbols',
              body: (
                <label className="flex items-center justify-between text-xs">
                  <span>{isAr ? 'لون البشرة الافتراضي' : 'Default Emoji Skin Tone'}</span>
                  <select
                    value={settings.emojiSkinTone}
                    onChange={(e) => onUpdateSettings({ emojiSkinTone: e.target.value })}
                    className="px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-transparent"
                  >
                    <option value="">Default</option>
                    <option value="🏻">Light 🏻 </option>
                    <option value="🏼">Medium-Light 🏼</option>
                    <option value="🏽">Medium 🏽</option>
                    <option value="🏾">Medium-Dark 🏾</option>
                    <option value="🏿">Dark 🏿</option>
                  </select>
                </label>
              ),
            },
            {
              num: '12',
              ar: 'إعدادات الحافظة',
              en: 'Clipboard Settings',
              body: (
                <label className="flex items-center justify-between text-xs">
                  <span>{isAr ? 'تفعيل سجل الحافظة اليدوي' : 'Enable On-Demand Clipboard History'}</span>
                  <input
                    type="checkbox"
                    checked={settings.enableClipboardHistory}
                    onChange={(e) => onUpdateSettings({ enableClipboardHistory: e.target.checked })}
                    className="accent-indigo-600"
                  />
                </label>
              ),
            },
            {
              num: '13',
              ar: 'مساعد الذكاء الاصطناعي',
              en: 'AI Writing Assistant',
              body: (
                <label className="flex items-center justify-between text-xs">
                  <span>{isAr ? 'تفعيل أدوات الصياغة والتدقيق' : 'Enable AI Writing Tools'}</span>
                  <input
                    type="checkbox"
                    checked={settings.enableCloudAiAssistant}
                    onChange={(e) => onUpdateSettings({ enableCloudAiAssistant: e.target.checked })}
                    className="accent-indigo-600"
                  />
                </label>
              ),
            },
            {
              num: '14–16',
              ar: 'الخصوصية والنماذج والتخزين',
              en: 'Privacy, Models & Storage',
              body: (
                <div className="space-y-2 text-xs">
                  <p className="text-slate-500 tabular-nums">
                    {isAr
                      ? `مساحة الحزم المثبتة: ${totalInstalledStorageMb.toFixed(1)} MB`
                      : `Model & Dictionary Storage: ${totalInstalledStorageMb.toFixed(1)} MB`}
                  </p>
                  <button
                    type="button"
                    onClick={onWipeLocalData}
                    className="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    {isAr ? 'حذف جميع البيانات المحلية' : 'Delete All Local Data'}
                  </button>
                </div>
              ),
            },
            {
              num: '17',
              ar: 'النسخ الاحتياطي والاستعادة',
              en: 'Backup & Restore',
              body: (
                <div className="space-y-2 text-xs">
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={onExportBackup}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white font-medium flex items-center gap-1 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      {isAr ? 'تصدير نسخة JSON' : 'Export Backup'}
                    </button>
                    <button
                      type="button"
                      onClick={onResetAllSettings}
                      className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 flex items-center gap-1 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      {isAr ? 'استعادة الافتراضي' : 'Reset Defaults'}
                    </button>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="text"
                      value={backupInput}
                      onChange={(e) => setBackupInput(e.target.value)}
                      placeholder={isAr ? 'الصق JSON للاستعادة...' : 'Paste backup JSON...'}
                      className="flex-1 px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-transparent font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const ok = onImportBackup(backupInput);
                        setBackupMessage(ok ? (isAr ? 'تمت الاستعادة بنجاح.' : 'Backup restored.') : isAr ? 'صيغة غير صالحة.' : 'Invalid JSON.');
                        if (ok) setBackupInput('');
                      }}
                      className="px-2.5 py-1 rounded bg-slate-800 text-white flex items-center gap-1 cursor-pointer"
                    >
                      <Upload className="w-3 h-3" /> {isAr ? 'استعادة' : 'Restore'}
                    </button>
                  </div>
                  {backupMessage && <p className="text-indigo-500">{backupMessage}</p>}
                </div>
              ),
            },
            {
              num: '18–20',
              ar: 'الإشعارات والدعم وحول التطبيق',
              en: 'Notifications, Support & About',
              body: (
                <div className="space-y-2 text-xs">
                  <label className="flex items-center justify-between">
                    <span>{isAr ? 'إشعارات تحديث الحزم اللغوية' : 'Language Pack Update Notifications'}</span>
                    <input
                      type="checkbox"
                      checked={settings.notificationsEnabled}
                      onChange={(e) => onUpdateSettings({ notificationsEnabled: e.target.checked })}
                      className="accent-indigo-600"
                    />
                  </label>
                  <p className="text-slate-500">
                    Lisan AI Keyboard – لسان · v1.0.0 · {isAr ? 'المطور:' : 'Developer:'} nidalwatfa99@gmail.com
                  </p>
                </div>
              ),
            },
          ].map((sec) => (
            <div key={sec.num} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2.5">
              <h4 className="text-sm font-semibold">
                {sec.num}. {isAr ? sec.ar : sec.en}
              </h4>
              {sec.body}
            </div>
          ))}
        </div>
      )}

      {/* PRIVACY, SHARE, DEVELOPER SUPPORT & BUILD ARCHIVE */}
      {subView === 'privacy_support' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Contact Developer – Report a Problem */}
          <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold">
                {isAr ? 'تواصل مع المطور – Report a Problem' : 'Contact Developer – Report a Problem'}
              </h3>
              <span className="text-xs font-mono text-indigo-500">nidalwatfa99@gmail.com</span>
            </div>

            <label className="block space-y-1 text-xs">
              <span className="font-medium">{isAr ? 'نوع المشكلة' : 'Problem Category'}</span>
              <select
                value={issueType}
                onChange={(e) => setIssueType(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
              >
                <option value="Keyboard Layout / Arabic">Keyboard Layout / Arabic</option>
                <option value="Voice to Text">Voice to Text</option>
                <option value="AI Translation">AI Translation</option>
                <option value="Themes & Fonts">Themes & Fonts</option>
                <option value="Android APK / Build">Android APK / Build</option>
              </select>
            </label>

            <label className="block space-y-1 text-xs">
              <span className="font-medium">{isAr ? 'وصف المشكلة' : 'Describe the Issue'}</span>
              <textarea
                rows={3}
                value={issueDesc}
                onChange={(e) => setIssueDesc(e.target.value)}
                placeholder={
                  isAr
                    ? 'اكتب تفاصيل المشكلة (لا نجمع نصوصك الشخصية أو محتوى الحافظة)...'
                    : 'Describe the issue (no personal text or clipboard contents are included)...'
                }
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
              />
            </label>

            <div className="space-y-2 text-xs">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeDeviceInfo}
                  onChange={(e) => setIncludeDeviceInfo(e.target.checked)}
                  className="accent-indigo-600"
                />
                <span>{isAr ? 'إرفاق إصدار التطبيق ومعلومات الجهاز اختيارياً' : 'Optionally attach app version & device info'}</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeRedactedLogs}
                  onChange={(e) => setIncludeRedactedLogs(e.target.checked)}
                  className="accent-indigo-600"
                />
                <span>{isAr ? 'إرفاق سجل تشخيصي منقح (خالٍ من البيانات الشخصية)' : 'Attach redacted diagnostic metadata (zero personal data)'}</span>
              </label>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={handleMailtoSupport}
                className="px-4 py-2 rounded-lg bg-indigo-600 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Mail className="w-4 h-4" />
                {isAr ? 'مراسلة المطور عبر البريد' : 'Email Developer'}
              </button>
              <button
                type="button"
                onClick={handleCopyReport}
                className="px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
              >
                <Copy className="w-4 h-4" />
                {isAr ? 'نسخ التقرير' : 'Copy Report'}
              </button>
              <button
                type="button"
                onClick={handleShareApp}
                className="px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                {isAr ? 'مشاركة التطبيق' : 'Share App'}
              </button>
            </div>

            {reportFeedback && <p className="text-xs text-emerald-500">{reportFeedback}</p>}
          </div>

          {/* Privacy Guarantee + APK Status */}
          <div className="space-y-4">
            <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
              <h3 className="text-base font-semibold flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-500" />
                {isAr ? 'الخصوصية والأمان' : 'Privacy & Security Guarantee'}
              </h3>
              <ul className="text-xs space-y-1.5 text-slate-600 dark:text-slate-300 list-disc ps-4 leading-relaxed">
                <li>{isAr ? 'عدم تسجيل ضغطات المفاتيح أو تخزين كلمات المرور.' : 'Zero keystroke logging and zero password storage.'}</li>
                <li>{isAr ? 'تعطيل التنبؤ والذكاء الاصطناعي تلقائياً في حقول كلمات المرور.' : 'Automatic AI & prediction lock on password/sensitive fields.'}</li>
                <li>{isAr ? 'عدم مراقبة الحافظة في الخلفية — القراءة فقط عند طلبك.' : 'No background clipboard spying — explicit user read only.'}</li>
                <li>{isAr ? 'لا يُرسل أي نص أو صوت للسحابة إلا بإجراء صريح منك عبر HTTPS.' : 'No text or audio leaves the device without explicit user action over HTTPS.'}</li>
              </ul>
            </div>

            <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
              <h3 className="text-base font-semibold">
                {isAr ? 'حالة بناء APK' : 'APK Build Status'}
              </h3>
              <div className="text-xs text-amber-600 dark:text-amber-400">
                <strong>{isAr ? 'توضيح تقني صادق حول ملف APK:' : 'Honest APK Build Note:'}</strong>{' '}
                {isAr
                  ? 'يُبنى ملف APK محلياً: افتح مجلد android-project في Android Studio (JDK 17) ثم شغّل ./gradlew assembleDebug.'
                  : 'The APK is built locally: open android-project in Android Studio (JDK 17) and run ./gradlew assembleDebug.'}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
