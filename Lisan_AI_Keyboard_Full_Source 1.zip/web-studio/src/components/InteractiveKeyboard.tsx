import React, { useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Clipboard,
  ClipboardCopy,
  Delete,
  Eraser,
  Globe,
  Languages,
  Lock,
  Mic,
  MicOff,
  Pause,
  Pin,
  Play,
  Plus,
  Search,
  Send,
  Settings,
  Smile,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import {
  ARABIC_BIGRAMS,
  ARABIC_HARAKAT_KEYS,
  ARABIC_LETTER_ROWS,
  ARABIC_PREDICTIONS_POOL,
  EMOJI_DATA,
  ENGLISH_BIGRAMS,
  ENGLISH_PREDICTIONS_POOL,
  LATIN_LETTER_ROWS,
  NUMBER_KEYS,
  SYMBOLS_ROWS,
} from '../data/lisanData';
import type {
  ClipboardItem,
  KeyboardCustomization,
  KeyboardLangCode,
  KeyboardTheme,
  KeyDef,
  LisanSettings,
  ToolbarButtonId,
  TranslationHistoryEntry,
  UiLanguage,
} from '../types/lisan';

interface InteractiveKeyboardProps {
  uiLang: UiLanguage;
  theme: KeyboardTheme;
  customization: KeyboardCustomization;
  settings: LisanSettings;
  text: string;
  onTextChange: (next: string) => void;
  cursorPos: number;
  onCursorChange: (pos: number) => void;
  isSensitiveField: boolean;
  personalWords: string[];
  ignoredWords: string[];
  onAddPersonalWord: (word: string) => void;
  clipboardItems: ClipboardItem[];
  onSaveClipboard: (text: string, category?: ClipboardItem['category']) => void;
  onTogglePinClip: (id: string) => void;
  onDeleteClip: (id: string) => void;
  onClearClips: () => void;
  onEditClip: (id: string, newText: string) => void;
  onAddTranslationHistory: (entry: TranslationHistoryEntry) => void;
  onToggleLanguage: () => void;
  onToggleHarakat: () => void;
  onOpenSettings: () => void;
  onVisibleChange?: (visible: boolean) => void;
}

type ActivePanel = 'keys' | 'voice' | 'translate' | 'clipboard' | 'emoji' | 'ai';

export const InteractiveKeyboard: React.FC<InteractiveKeyboardProps> = ({
  uiLang,
  theme,
  customization,
  settings,
  text,
  onTextChange,
  cursorPos,
  onCursorChange,
  isSensitiveField,
  personalWords,
  ignoredWords,
  onAddPersonalWord,
  clipboardItems,
  onSaveClipboard,
  onTogglePinClip,
  onDeleteClip,
  onClearClips,
  onEditClip,
  onAddTranslationHistory,
  onToggleLanguage,
  onToggleHarakat,
  onOpenSettings,
}) => {
  const isArUi = uiLang === 'ar';
  const [activePanel, setActivePanel] = useState<ActivePanel>('keys');
  const [symbolsMode, setSymbolsMode] = useState(false);
  const [shifted, setShifted] = useState(false);
  const [longPressKey, setLongPressKey] = useState<KeyDef | null>(null);
  const [pressedKeyId, setPressedKeyId] = useState<string | null>(null);
  const longPressTimerRef = useRef<number | null>(null);

  // Voice state
  const [voiceStatus, setVoiceStatus] = useState<'idle' | 'listening' | 'paused' | 'processing' | 'error'>('idle');
  const [voiceDraft, setVoiceDraft] = useState('');
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const [voiceLangLocal, setVoiceLangLocal] = useState<string>(settings.voiceLang);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Translation state
  const [trSourceText, setTrSourceText] = useState('');
  const [trResultText, setTrResultText] = useState('');
  const [trSourceLang, setTrSourceLang] = useState(settings.translationSourceLang);
  const [trTargetLang, setTrTargetLang] = useState(settings.translationTargetLang);
  const [trDetected, setTrDetected] = useState<string | null>(null);
  const [trLoading, setTrLoading] = useState(false);
  const [trError, setTrError] = useState<string | null>(null);

  // AI Writing Assistant state
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState('');
  const [aiAlternatives, setAiAlternatives] = useState<string[]>([]);
  const [aiError, setAiError] = useState<string | null>(null);

  // Emoji state
  const [emojiCategory, setEmojiCategory] = useState<string>('Popular');
  const [emojiSearch, setEmojiSearch] = useState('');
  const [recentEmojis, setRecentEmojis] = useState<string[]>(['😀', '👍', '❤️', '🌙']);
  const [favoriteEmojis, setFavoriteEmojis] = useState<string[]>(['❤️', '🙏', '✨']);
  const [skinTone, setSkinTone] = useState(settings.emojiSkinTone);

  // Clipboard UI state
  const [clipSearch, setClipSearch] = useState('');
  const [editingClipId, setEditingClipId] = useState<string | null>(null);
  const [editingClipDraft, setEditingClipDraft] = useState('');

  // Extract current word before cursor for predictions
  const { currentToken, previousWord } = useMemo(() => {
    const safePos = Math.max(0, Math.min(cursorPos, text.length));
    const before = text.slice(0, safePos);
    const parts = before.split(/\s+/);
    const cur = parts[parts.length - 1] ?? '';
    const prev = parts.length >= 2 ? parts[parts.length - 2] : '';
    return { currentToken: cur, previousWord: prev };
  }, [text, cursorPos]);

  const suggestions = useMemo(() => {
    if (!settings.enablePredictions || isSensitiveField) return [];
    const isArabic = settings.keyboardLang === 'ar';
    if (!currentToken) {
      const bigrams = isArabic
        ? ARABIC_BIGRAMS[previousWord]
        : ENGLISH_BIGRAMS[previousWord.toLowerCase()];
      if (bigrams && bigrams.length > 0) return bigrams.slice(0, 4);
      return isArabic
        ? ['السلام', 'مرحباً', 'شكراً', 'اليوم']
        : ['Hello', 'Thanks', 'Please', 'Schedule'];
    }
    const pool = Array.from(
      new Set([
        ...personalWords,
        ...(isArabic ? ARABIC_PREDICTIONS_POOL : ENGLISH_PREDICTIONS_POOL),
      ])
    );
    return pool
      .filter(
        (w) =>
          w.toLowerCase().startsWith(currentToken.toLowerCase()) &&
          !ignoredWords.includes(w.toLowerCase())
      )
      .slice(0, 4);
  }, [settings.enablePredictions, settings.keyboardLang, isSensitiveField, currentToken, previousWord, personalWords, ignoredWords]);

  const insertAtCursor = (snippet: string) => {
    const safePos = Math.max(0, Math.min(cursorPos, text.length));
    let out = snippet;
    if (settings.keyboardLang !== 'ar' && shifted && /^[a-z]$/.test(out)) {
      out = out.toUpperCase();
    }
    const next = text.slice(0, safePos) + out + text.slice(safePos);
    onTextChange(next);
    onCursorChange(safePos + out.length);
    if (shifted) setShifted(false);
  };

  const handleBackspace = (deleteWholeWord = false) => {
    const safePos = Math.max(0, Math.min(cursorPos, text.length));
    if (safePos === 0) return;
    if (deleteWholeWord) {
      const before = text.slice(0, safePos).replace(/\S+\s*$/, '');
      const next = before + text.slice(safePos);
      onTextChange(next);
      onCursorChange(before.length);
      return;
    }
    const next = text.slice(0, safePos - 1) + text.slice(safePos);
    onTextChange(next);
    onCursorChange(safePos - 1);
  };

  const applySuggestion = (word: string) => {
    const safePos = Math.max(0, Math.min(cursorPos, text.length));
    const before = text.slice(0, safePos);
    const replacedBefore = currentToken
      ? before.slice(0, before.length - currentToken.length) + word + ' '
      : before + word + ' ';
    onTextChange(replacedBefore + text.slice(safePos));
    onCursorChange(replacedBefore.length);
  };

  const handleSpace = () => {
    if (
      settings.autocorrectLevel > 0 &&
      !isSensitiveField &&
      currentToken.length >= 2 &&
      !personalWords.includes(currentToken)
    ) {
      // Never strip Arabic diacritics if preserveArabicDiacritics is enabled
      const hasDiacritics = /[\u064B-\u065F]/.test(currentToken);
      if (!(settings.preserveArabicDiacritics && hasDiacritics)) {
        const typoMap: Record<string, string> = {
          teh: 'the',
          recieve: 'receive',
          adn: 'and',
          thnak: 'thank',
          السلا: 'السلام',
          شكرا: 'شكراً',
        };
        const fix = typoMap[currentToken] || typoMap[currentToken.toLowerCase()];
        if (fix) {
          applySuggestion(fix);
          return;
        }
      }
    }
    insertAtCursor(' ');
  };

  // Voice Recording + Gemini Transcribe
  const startVoiceRecording = async () => {
    setVoiceError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setVoiceStatus('error');
        setVoiceError(isArUi ? 'المتصفح لا يدعم الوصول للميكروفون.' : 'Browser microphone API unavailable.');
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];
      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) audioChunksRef.current.push(ev.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        if (audioChunksRef.current.length === 0) {
          setVoiceStatus('idle');
          return;
        }
        setVoiceStatus('processing');
        try {
          const blob = new Blob(audioChunksRef.current, { type: recorder.mimeType || 'audio/webm' });
          const buffer = await blob.arrayBuffer();
          const bytes = new Uint8Array(buffer);
          let binary = '';
          for (let i = 0; i < bytes.length; i += 0x8000) {
            binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
          }
          const base64 = btoa(binary);
          const resp = await fetch('/api/ai/transcribe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioBase64: base64,
              mimeType: recorder.mimeType || 'audio/webm',
              languageHint: voiceLangLocal,
            }),
          });
          const data = await resp.json();
          if (!resp.ok) throw new Error(data.error || 'Transcription error');
          const transcript = (data.transcript || '').trim();
          setVoiceDraft((prev) => (prev ? `${prev} ${transcript}` : transcript));
          setVoiceStatus('paused');
        } catch (e) {
          setVoiceStatus('error');
          setVoiceError(e instanceof Error ? e.message : 'Transcription failed');
        }
      };
      mediaRecorderRef.current = recorder;
      recorder.start();
      setVoiceStatus('listening');
    } catch (e) {
      setVoiceStatus('error');
      setVoiceError(
        e instanceof Error
          ? e.message
          : isArUi
            ? 'تعذر الحصول على إذن الميكروفون.'
            : 'Microphone permission denied.'
      );
    }
  };

  const stopVoiceRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    } else {
      setVoiceStatus('idle');
    }
  };

  // Translation action
  const runTranslation = async (overrideSource?: string) => {
    const input = (overrideSource ?? (trSourceText || text)).trim();
    if (!input) {
      setTrError(isArUi ? 'أدخل نصاً للترجمة أولاً.' : 'Enter text to translate first.');
      return;
    }
    if (isSensitiveField) {
      setTrError(isArUi ? 'الترجمة السحابية معطلة في حقول كلمات المرور.' : 'Cloud translation disabled in password fields.');
      return;
    }
    if (!settings.enableCloudTranslation) {
      setTrError(isArUi ? 'فعّل خيار الترجمة السحابية من الإعدادات للمتابعة.' : 'Enable Cloud Translation in Settings first.');
      return;
    }
    setTrLoading(true);
    setTrError(null);
    setTrSourceText(input);
    try {
      const resp = await fetch('/api/ai/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: input,
          sourceLang: trSourceLang,
          targetLang: trTargetLang,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error || 'Translation error');
      setTrDetected(data.detectedSourceLang);
      setTrResultText(data.translatedText);
      onAddTranslationHistory({
        id: `tr-${Date.now()}`,
        original: input,
        translated: data.translatedText,
        sourceLang: data.detectedSourceLang || trSourceLang,
        targetLang: trTargetLang,
        provider: 'Gemini AI Translation',
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      });
    } catch (e) {
      setTrError(e instanceof Error ? e.message : 'Translation failed');
    } finally {
      setTrLoading(false);
    }
  };

  // AI Writing Assistant action
  const runAiAssist = async (action: string) => {
    const input = text.trim();
    if (!input) {
      setAiError(isArUi ? 'اكتب نصاً في حقل الإدخال أولاً.' : 'Type some text in the input field first.');
      return;
    }
    if (isSensitiveField || !settings.enableCloudAiAssistant) {
      setAiError(
        isSensitiveField
          ? isArUi
            ? 'المساعد الذكي معطل تلقائياً في الحقول الحساسة.'
            : 'AI Assistant is locked in password fields.'
          : isArUi
            ? 'فعّل مساعد الكتابة الذكي من الإعدادات.'
            : 'Enable AI Writing Assistant in Settings.'
      );
      return;
    }
    setAiLoading(true);
    setAiError(null);
    try {
      const resp = await fetch('/api/ai/assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: input,
          action,
          language: settings.keyboardLang,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error || 'AI Assistant error');
      setAiResult(data.primaryResult || '');
      setAiAlternatives(data.alternatives || []);
    } catch (e) {
      setAiError(e instanceof Error ? e.message : 'AI request failed');
    } finally {
      setAiLoading(false);
    }
  };

  const handleExplicitClipboardRead = async () => {
    try {
      const clip = await navigator.clipboard.readText();
      if (clip && clip.trim()) {
        onSaveClipboard(clip.trim(), 'General');
      }
    } catch {
      // Browser may deny clipboard read without focus; user can still paste manually
    }
  };

  const keyBorderRadius =
    customization.keyShape === 'pill'
      ? '9999px'
      : customization.keyShape === 'sharp'
        ? '4px'
        : customization.keyShape === 'squircle'
          ? `${Math.max(10, customization.cornerRadiusPx)}px`
          : `${customization.cornerRadiusPx}px`;

  const containerStyle: React.CSSProperties = {
    width: `${customization.widthPercent}%`,
    minHeight: `${customization.heightPx}px`,
    fontFamily: customization.fontFamily,
  };

  const bgLayerStyle: React.CSSProperties = {
    position: 'absolute',
    inset: 0,
    zIndex: -1,
    background: theme.bgGradientEnd
      ? `linear-gradient(155deg, ${theme.bgColor}, ${theme.bgGradientEnd})`
      : theme.bgColor,
    opacity: customization.bgOpacity,
  };

  const keyShadow =
    customization.shadowLevel === 0
      ? 'none'
      : customization.shadowLevel === 1
        ? '0 1px 2px rgba(0,0,0,0.22)'
        : '0 2px 5px rgba(0,0,0,0.34)';

  const renderToolbarButton = (id: ToolbarButtonId) => {
    const isActive =
      (id === 'translate' && activePanel === 'translate') ||
      (id === 'voice' && activePanel === 'voice') ||
      (id === 'clipboard' && activePanel === 'clipboard') ||
      (id === 'emoji' && activePanel === 'emoji') ||
      (id === 'ai' && activePanel === 'ai');

    const iconProps = { className: 'w-4 h-4' };
    const meta: Record<ToolbarButtonId, { icon: React.ReactNode; label: string; onClick: () => void; accent?: string }> = {
      translate: {
        icon: <Languages {...iconProps} />,
        label: isArUi ? 'ترجمة' : 'Translate',
        onClick: () => {
          setTrSourceText(text);
          setActivePanel(activePanel === 'translate' ? 'keys' : 'translate');
        },
        accent: theme.translateKeyBg,
      },
      voice: {
        icon: voiceStatus === 'listening' ? <MicOff {...iconProps} /> : <Mic {...iconProps} />,
        label: isArUi ? 'صوت' : 'Voice',
        onClick: () => setActivePanel(activePanel === 'voice' ? 'keys' : 'voice'),
        accent: theme.micKeyBg,
      },
      clipboard: {
        icon: <Clipboard {...iconProps} />,
        label: isArUi ? 'الحافظة' : 'Clipboard',
        onClick: () => setActivePanel(activePanel === 'clipboard' ? 'keys' : 'clipboard'),
      },
      emoji: {
        icon: <Smile {...iconProps} />,
        label: isArUi ? 'إيموجي' : 'Emoji',
        onClick: () => setActivePanel(activePanel === 'emoji' ? 'keys' : 'emoji'),
      },
      harakat: {
        icon: <span className="text-xs font-bold leading-none">تَشْكيل</span>,
        label: isArUi ? 'الحركات' : 'Harakat',
        onClick: onToggleHarakat,
      },
      ai: {
        icon: <Sparkles {...iconProps} />,
        label: isArUi ? 'مساعد' : 'AI',
        onClick: () => setActivePanel(activePanel === 'ai' ? 'keys' : 'ai'),
      },
      language: {
        icon: <Globe {...iconProps} />,
        label: settings.keyboardLang.toUpperCase(),
        onClick: onToggleLanguage,
      },
      search: {
        icon: <Search {...iconProps} />,
        label: isArUi ? 'بحث' : 'Search',
        onClick: () => setActivePanel(activePanel === 'emoji' ? 'keys' : 'emoji'),
      },
      settings: {
        icon: <Settings {...iconProps} />,
        label: isArUi ? 'إعدادات' : 'Settings',
        onClick: onOpenSettings,
      },
    };
    const item = meta[id];
    return (
      <button
        key={id}
        type="button"
        onClick={item.onClick}
        title={item.label}
        aria-label={item.label}
        style={{
          backgroundColor: isActive ? item.accent || theme.micKeyBg : theme.specialKeyBg,
          color: isActive ? '#FFFFFF' : theme.keyText,
          borderRadius: keyBorderRadius,
          border: `${customization.borderWidthPx}px solid ${theme.borderColor}`,
        }}
        className="h-8 min-w-[34px] px-2 flex items-center justify-center gap-1 text-xs font-medium transition-transform active:scale-95 whitespace-nowrap shrink-0 cursor-pointer"
      >
        {item.icon}
        {(id === 'translate' || id === 'voice' || id === 'language') && (
          <span className="hidden sm:inline text-[11px]">{item.label}</span>
        )}
      </button>
    );
  };

  const activeLetterRows = symbolsMode
    ? SYMBOLS_ROWS
    : settings.keyboardLang === 'ar'
      ? ARABIC_LETTER_ROWS
      : LATIN_LETTER_ROWS;

  const startKeyLongPress = (key: KeyDef) => {
    setPressedKeyId(key.id);
    if (!key.alternates || key.alternates.length === 0) return;
    longPressTimerRef.current = window.setTimeout(() => {
      setLongPressKey(key);
    }, 360);
  };

  const endKeyPress = (key: KeyDef) => {
    setPressedKeyId(null);
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    if (longPressKey && longPressKey.id === key.id) {
      return;
    }
    insertAtCursor(key.output);
  };

  const filteredEmojis = useMemo(() => {
    const q = emojiSearch.trim().toLowerCase();
    return EMOJI_DATA.filter((e) => {
      if (q) {
        return e.nameEn.toLowerCase().includes(q) || e.nameAr.includes(q) || e.glyph.includes(q);
      }
      if (emojiCategory === 'Recent') return recentEmojis.includes(e.glyph);
      if (emojiCategory === 'Favorites') return favoriteEmojis.includes(e.glyph);
      return e.category === emojiCategory;
    });
  }, [emojiCategory, emojiSearch, recentEmojis, favoriteEmojis]);

  const filteredClips = useMemo(() => {
    const q = clipSearch.trim().toLowerCase();
    return [...clipboardItems]
      .sort((a, b) => Number(b.pinned) - Number(a.pinned))
      .filter((c) => !q || c.text.toLowerCase().includes(q) || c.category.toLowerCase().includes(q));
  }, [clipboardItems, clipSearch]);

  return (
    <div className="w-full flex flex-col items-center select-none">
      <div
        style={containerStyle}
        dir="ltr"
        className="relative isolate rounded-2xl p-1.5 sm:p-2 transition-all duration-150 border border-slate-700/40 shadow-xl overflow-hidden"
      >
        <div aria-hidden="true" style={bgLayerStyle} />
        {/* Sensitive Password Field Privacy Notice */}
        {isSensitiveField && (
          <div
            dir={isArUi ? 'rtl' : 'ltr'}
            style={{ backgroundColor: theme.specialKeyBg, color: theme.numberText }}
            className="mb-1.5 px-2.5 py-1 rounded-lg flex items-center justify-between text-[11px]"
          >
            <span className="flex items-center gap-1.5 font-medium">
              <Lock className="w-3.5 h-3.5" />
              {isArUi
                ? 'حقل كلمة مرور: الاقتراحات والذكاء الاصطناعي معطلان'
                : 'Password field: suggestions and AI off'}
            </span>
          </div>
        )}

        {/* Smart Customizable Toolbar */}
        {customization.showToolbarRow && (
          <div
            style={{ minHeight: `${customization.toolbarHeightPx}px` }}
            className="flex items-center justify-between gap-1.5 pb-1.5 overflow-x-auto lisan-scroll"
          >
            <div className="flex items-center gap-1.5">
              {customization.toolbarOrder
                .filter((id) => !customization.hiddenToolbarButtons.includes(id))
                .map(renderToolbarButton)}
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={() => onCursorChange(Math.max(0, cursorPos - 1))}
                title="Move Cursor Left"
                style={{ backgroundColor: theme.specialKeyBg, color: theme.keyText, borderRadius: keyBorderRadius }}
                className="h-8 w-8 flex items-center justify-center cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onCursorChange(Math.min(text.length, cursorPos + 1))}
                title="Move Cursor Right"
                style={{ backgroundColor: theme.specialKeyBg, color: theme.keyText, borderRadius: keyBorderRadius }}
                className="h-8 w-8 flex items-center justify-center cursor-pointer active:scale-95"
              >
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Long-press alternates popup */}
        {longPressKey && longPressKey.alternates && (
          <div
            style={{ backgroundColor: theme.specialKeyBg, borderColor: theme.borderColor }}
            className="mb-1.5 p-1.5 rounded-xl border flex items-center justify-center gap-1.5 flex-wrap shadow-lg"
          >
            <button
              type="button"
              onClick={() => {
                insertAtCursor(longPressKey.output);
                setLongPressKey(null);
              }}
              style={{ backgroundColor: theme.keyBg, color: theme.keyText, borderRadius: keyBorderRadius }}
              className="px-3 py-1.5 text-base font-semibold cursor-pointer"
            >
              {longPressKey.output}
            </button>
            {longPressKey.alternates.map((alt) => (
              <button
                key={alt}
                type="button"
                onClick={() => {
                  insertAtCursor(alt);
                  setLongPressKey(null);
                }}
                style={{ backgroundColor: theme.micKeyBg, color: '#FFFFFF', borderRadius: keyBorderRadius }}
                className="px-3 py-1.5 text-base font-semibold cursor-pointer"
              >
                {alt}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setLongPressKey(null)}
              style={{ color: theme.symbolText }}
              className="p-1.5 cursor-pointer"
              aria-label="Close alternates"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* PANEL 1: VOICE TO TEXT */}
        {activePanel === 'voice' && (
          <div
            dir={isArUi ? 'rtl' : 'ltr'}
            style={{ backgroundColor: theme.specialKeyBg, color: theme.keyText }}
            className="rounded-xl p-3 space-y-2.5"
          >
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold">
                  {isArUi ? 'الكتابة الصوتية الذكية' : 'Smart Voice Dictation'}
                </span>
                <select
                  value={voiceLangLocal}
                  onChange={(e) => setVoiceLangLocal(e.target.value)}
                  style={{ backgroundColor: theme.keyBg, color: theme.keyText, borderColor: theme.borderColor }}
                  className="text-xs rounded-lg px-2 py-1 border"
                >
                  <option value="auto">{isArUi ? 'كشف تلقائي' : 'Auto Detect'}</option>
                  <option value="Arabic">العربية</option>
                  <option value="English">English</option>
                  <option value="French">Français</option>
                  <option value="Spanish">Español</option>
                </select>
              </div>
              <button
                type="button"
                onClick={() => setActivePanel('keys')}
                className="text-xs opacity-75 hover:opacity-100 px-2 py-1 cursor-pointer"
              >
                {isArUi ? 'العودة للمفاتيح' : 'Back to Keys'}
              </button>
            </div>

            <div className="flex items-center gap-2">
              {voiceStatus !== 'listening' ? (
                <button
                  type="button"
                  onClick={startVoiceRecording}
                  style={{ backgroundColor: theme.micKeyBg, color: '#FFFFFF' }}
                  className="px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <Mic className="w-4 h-4" />
                  {voiceStatus === 'paused'
                    ? isArUi
                      ? 'متابعة التحدث'
                      : 'Resume Speaking'
                    : isArUi
                      ? 'بدء التحدث'
                      : 'Start Dictation'}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={stopVoiceRecording}
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 text-white flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <Pause className="w-4 h-4" />
                  {isArUi ? 'إيقاف ومعالجة' : 'Stop & Transcribe'}
                </button>
              )}

              <span className="text-xs tabular-nums opacity-80">
                {voiceStatus === 'listening'
                  ? isArUi
                    ? 'جارٍ الاستماع...'
                    : 'Listening...'
                  : voiceStatus === 'processing'
                    ? isArUi
                      ? 'جارٍ تحويل الصوت إلى نص...'
                      : 'Transcribing...'
                    : voiceStatus === 'paused'
                      ? isArUi
                        ? 'متوقف مؤقتاً — يمكنك التعديل أو الإدراج'
                        : 'Paused — edit or insert'
                      : isArUi
                        ? 'جاهز للتسجيل (لا يتم التسجيل في الخلفية)'
                        : 'Ready (never records in background)'}
              </span>
            </div>

            {voiceError && (
              <div className="text-xs text-rose-400 bg-rose-950/40 px-2.5 py-1.5 rounded-lg">{voiceError}</div>
            )}

            <textarea
              rows={2}
              value={voiceDraft}
              onChange={(e) => setVoiceDraft(e.target.value)}
              placeholder={
                isArUi ? 'سيظهر النص المحول من الصوت هنا لتعديله قبل الإدراج...' : 'Transcribed speech appears here for editing...'
              }
              style={{ backgroundColor: theme.keyBg, color: theme.keyText, borderColor: theme.borderColor }}
              className="w-full rounded-lg p-2 text-sm border outline-none"
            />

            <div className="flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => {
                  setVoiceDraft('');
                  setVoiceStatus('idle');
                }}
                className="text-xs px-2.5 py-1.5 rounded-lg opacity-80 hover:opacity-100 cursor-pointer"
              >
                {isArUi ? 'مسح' : 'Clear'}
              </button>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (voiceDraft.trim()) {
                      setTrSourceText(voiceDraft.trim());
                      setActivePanel('translate');
                      runTranslation(voiceDraft.trim());
                    }
                  }}
                  disabled={!voiceDraft.trim()}
                  style={{ backgroundColor: theme.translateKeyBg, color: '#FFFFFF' }}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium disabled:opacity-40 cursor-pointer"
                >
                  {isArUi ? 'ترجمة النص' : 'Translate Speech'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (voiceDraft.trim()) {
                      insertAtCursor((text && !text.endsWith(' ') ? ' ' : '') + voiceDraft.trim());
                      setVoiceDraft('');
                      setVoiceStatus('idle');
                      setActivePanel('keys');
                    }
                  }}
                  disabled={!voiceDraft.trim()}
                  style={{ backgroundColor: theme.micKeyBg, color: '#FFFFFF' }}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 disabled:opacity-40 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  {isArUi ? 'إدراج في الحقل' : 'Insert Text'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* PANEL 2: IN-KEYBOARD AI TRANSLATION */}
        {activePanel === 'translate' && (
          <div
            dir={isArUi ? 'rtl' : 'ltr'}
            style={{ backgroundColor: theme.specialKeyBg, color: theme.keyText }}
            className="rounded-xl p-3 space-y-2"
          >
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-1.5 text-xs">
                <select
                  value={trSourceLang}
                  onChange={(e) => setTrSourceLang(e.target.value)}
                  style={{ backgroundColor: theme.keyBg, color: theme.keyText, borderColor: theme.borderColor }}
                  className="rounded-lg px-2 py-1 border"
                >
                  <option value="auto">{isArUi ? 'المصدر: تلقائي' : 'Source: Auto'}</option>
                  <option value="Arabic">العربية</option>
                  <option value="English">English</option>
                  <option value="French">Français</option>
                  <option value="Spanish">Español</option>
                  <option value="Turkish">Türkçe</option>
                  <option value="German">Deutsch</option>
                </select>
                <span>→</span>
                <select
                  value={trTargetLang}
                  onChange={(e) => setTrTargetLang(e.target.value)}
                  style={{ backgroundColor: theme.keyBg, color: theme.keyText, borderColor: theme.borderColor }}
                  className="rounded-lg px-2 py-1 border"
                >
                  <option value="English">English</option>
                  <option value="Arabic">العربية</option>
                  <option value="French">Français</option>
                  <option value="Spanish">Español</option>
                  <option value="Turkish">Türkçe</option>
                  <option value="German">Deutsch</option>
                </select>
              </div>
              <button
                type="button"
                onClick={() => setActivePanel('keys')}
                className="text-xs opacity-75 hover:opacity-100 cursor-pointer"
              >
                {isArUi ? 'إغلاق' : 'Close'}
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <textarea
                rows={2}
                value={trSourceText}
                onChange={(e) => setTrSourceText(e.target.value)}
                placeholder={isArUi ? 'اكتب أو الصق النص للترجمة...' : 'Type or paste text to translate...'}
                style={{ backgroundColor: theme.keyBg, color: theme.keyText, borderColor: theme.borderColor }}
                className="w-full rounded-lg p-2 text-xs border outline-none"
              />
              <textarea
                rows={2}
                readOnly
                value={trResultText}
                placeholder={
                  trDetected
                    ? `${trDetected} → ${trTargetLang}`
                    : isArUi
                      ? 'النتيجة المترجمة...'
                      : 'Translated output...'
                }
                style={{ backgroundColor: theme.keyBg, color: theme.keyText, borderColor: theme.borderColor }}
                className="w-full rounded-lg p-2 text-xs border outline-none"
              />
            </div>

            {trError && <div className="text-xs text-rose-400">{trError}</div>}

            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => runTranslation()}
                  disabled={trLoading}
                  style={{ backgroundColor: theme.translateKeyBg, color: '#FFFFFF' }}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer disabled:opacity-50"
                >
                  {trLoading ? (isArUi ? 'جارٍ الترجمة...' : 'Translating...') : isArUi ? 'ترجمة الآن' : 'Translate Now'}
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      const clip = await navigator.clipboard.readText();
                      if (clip) runTranslation(clip);
                    } catch {
                      if (clipboardItems[0]) runTranslation(clipboardItems[0].text);
                    }
                  }}
                  style={{ backgroundColor: theme.keyBg, color: theme.keyText, borderColor: theme.borderColor }}
                  className="px-2.5 py-1.5 rounded-lg text-xs border cursor-pointer"
                >
                  {isArUi ? 'ترجمة المنسوخ' : 'Translate Copied'}
                </button>
              </div>
              <button
                type="button"
                disabled={!trResultText}
                onClick={() => {
                  onTextChange(trResultText);
                  onCursorChange(trResultText.length);
                  setActivePanel('keys');
                }}
                style={{ backgroundColor: theme.micKeyBg, color: '#FFFFFF' }}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold disabled:opacity-40 cursor-pointer"
              >
                {isArUi ? 'إدراج في حقل الكتابة' : 'Insert into Field'}
              </button>
            </div>
          </div>
        )}

        {/* PANEL 3: AI WRITING ASSISTANT */}
        {activePanel === 'ai' && (
          <div
            dir={isArUi ? 'rtl' : 'ltr'}
            style={{ backgroundColor: theme.specialKeyBg, color: theme.keyText }}
            className="rounded-xl p-3 space-y-2.5"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold">
                {isArUi ? 'مساعد الكتابة الذكي (بإذنك فقط)' : 'AI Writing Assistant (On-Demand Only)'}
              </span>
              <button type="button" onClick={() => setActivePanel('keys')} className="text-xs opacity-75 cursor-pointer">
                {isArUi ? 'إغلاق' : 'Close'}
              </button>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {[
                { id: 'rephrase', ar: 'إعادة صياغة', en: 'Rephrase' },
                { id: 'grammar', ar: 'تصحيح القواعد', en: 'Fix Grammar' },
                { id: 'formal', ar: 'أسلوب رسمي', en: 'Formal' },
                { id: 'friendly', ar: 'أسلوب ودي', en: 'Friendly' },
                { id: 'shorten', ar: 'اختصار', en: 'Shorten' },
                { id: 'expand', ar: 'توسيع', en: 'Expand' },
                { id: 'summarize', ar: 'تلخيص', en: 'Summarize' },
                { id: 'replies', ar: 'اقتراح ردود', en: 'Replies' },
                { id: 'proofread_ar_en', ar: 'تدقيق عربي/إنجليزي', en: 'Proofread AR/EN' },
              ].map((btn) => (
                <button
                  key={btn.id}
                  type="button"
                  disabled={aiLoading}
                  onClick={() => runAiAssist(btn.id)}
                  style={{ backgroundColor: theme.keyBg, color: theme.keyText, borderColor: theme.borderColor }}
                  className="px-2.5 py-1 rounded-lg text-xs border hover:opacity-90 cursor-pointer"
                >
                  {isArUi ? btn.ar : btn.en}
                </button>
              ))}
            </div>

            {aiLoading && <div className="text-xs opacity-80">{isArUi ? 'جارٍ المعالجة...' : 'Processing...'}</div>}
            {aiError && <div className="text-xs text-rose-400">{aiError}</div>}

            {aiResult && (
              <div
                style={{ backgroundColor: theme.keyBg, borderColor: theme.borderColor }}
                className="p-2.5 rounded-lg border space-y-2"
              >
                <p className="text-xs leading-relaxed">{aiResult}</p>
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={() => {
                      onTextChange(aiResult);
                      onCursorChange(aiResult.length);
                      setActivePanel('keys');
                    }}
                    style={{ backgroundColor: theme.micKeyBg, color: '#FFFFFF' }}
                    className="px-2.5 py-1 rounded-md text-xs font-semibold cursor-pointer"
                  >
                    {isArUi ? 'استبدال النص' : 'Replace Text'}
                  </button>
                  {aiAlternatives.map((alt, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => {
                        onTextChange(alt);
                        onCursorChange(alt.length);
                        setActivePanel('keys');
                      }}
                      style={{ backgroundColor: theme.specialKeyBg, color: theme.keyText }}
                      className="px-2 py-1 rounded-md text-[11px] truncate max-w-[200px] cursor-pointer"
                    >
                      {alt}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* PANEL 4: CLIPBOARD MANAGER */}
        {activePanel === 'clipboard' && (
          <div
            dir={isArUi ? 'rtl' : 'ltr'}
            style={{ backgroundColor: theme.specialKeyBg, color: theme.keyText }}
            className="rounded-xl p-2.5 space-y-2 max-h-[240px] flex flex-col"
          >
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2 flex-1 min-w-[160px]">
                <input
                  type="text"
                  value={clipSearch}
                  onChange={(e) => setClipSearch(e.target.value)}
                  placeholder={isArUi ? 'بحث في الحافظة...' : 'Search clipboard...'}
                  style={{ backgroundColor: theme.keyBg, color: theme.keyText, borderColor: theme.borderColor }}
                  className="flex-1 text-xs rounded-lg px-2.5 py-1.5 border outline-none"
                />
                <button
                  type="button"
                  onClick={handleExplicitClipboardRead}
                  style={{ backgroundColor: theme.translateKeyBg, color: '#FFFFFF' }}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap cursor-pointer"
                >
                  {isArUi ? 'استيراد المنسوخ' : 'Import Clip'}
                </button>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={onClearClips}
                  className="text-xs text-rose-400 hover:underline px-2 cursor-pointer"
                >
                  {isArUi ? 'مسح الكل' : 'Clear All'}
                </button>
                <button type="button" onClick={() => setActivePanel('keys')} className="text-xs opacity-75 px-2 cursor-pointer">
                  {isArUi ? 'إغلاق' : 'Close'}
                </button>
              </div>
            </div>

            <div className="overflow-y-auto lisan-scroll space-y-1.5 pr-1">
              {filteredClips.length === 0 ? (
                <p className="text-xs opacity-70 py-4 text-center">
                  {isArUi ? 'لا توجد عناصر محفوظة في الحافظة.' : 'No saved clipboard items.'}
                </p>
              ) : (
                filteredClips.map((clip) => (
                  <div
                    key={clip.id}
                    style={{ backgroundColor: theme.keyBg, borderColor: theme.borderColor }}
                    className="p-2 rounded-lg border flex items-start justify-between gap-2"
                  >
                    {editingClipId === clip.id ? (
                      <div className="flex-1 flex items-center gap-1.5">
                        <input
                          value={editingClipDraft}
                          onChange={(e) => setEditingClipDraft(e.target.value)}
                          style={{ backgroundColor: theme.specialKeyBg, color: theme.keyText }}
                          className="flex-1 text-xs px-2 py-1 rounded"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            onEditClip(clip.id, editingClipDraft);
                            setEditingClipId(null);
                          }}
                          className="text-xs text-emerald-400 px-1.5 cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          insertAtCursor(clip.text);
                          setActivePanel('keys');
                        }}
                        className="flex-1 text-start text-xs leading-snug cursor-pointer hover:opacity-85"
                      >
                        {clip.text}
                      </button>
                    )}

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => onTogglePinClip(clip.id)}
                        title="Pin"
                        className={`p-1 rounded cursor-pointer ${clip.pinned ? 'text-amber-400' : 'opacity-50'}`}
                      >
                        <Pin className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setTrSourceText(clip.text);
                          setActivePanel('translate');
                          runTranslation(clip.text);
                        }}
                        title="Translate"
                        className="p-1 opacity-75 hover:opacity-100 cursor-pointer"
                      >
                        <Languages className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setEditingClipId(clip.id);
                          setEditingClipDraft(clip.text);
                        }}
                        title="Edit"
                        className="p-1 text-[11px] opacity-75 hover:opacity-100 cursor-pointer"
                      >
                        ✎
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteClip(clip.id)}
                        title="Delete"
                        className="p-1 text-rose-400 opacity-75 hover:opacity-100 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* PANEL 5: EMOJI PICKER */}
        {activePanel === 'emoji' && (
          <div
            dir={isArUi ? 'rtl' : 'ltr'}
            style={{ backgroundColor: theme.specialKeyBg, color: theme.keyText }}
            className="rounded-xl p-2.5 space-y-2"
          >
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <input
                type="text"
                value={emojiSearch}
                onChange={(e) => setEmojiSearch(e.target.value)}
                placeholder={isArUi ? 'بحث عن إيموجي...' : 'Search emoji...'}
                style={{ backgroundColor: theme.keyBg, color: theme.keyText, borderColor: theme.borderColor }}
                className="flex-1 min-w-[140px] text-xs rounded-lg px-2.5 py-1.5 border outline-none"
              />
              <div className="flex items-center gap-1">
                {['', '🏻', '🏼', '🏽', '🏾', '🏿'].map((tone, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setSkinTone(tone)}
                    style={{
                      backgroundColor: skinTone === tone ? theme.micKeyBg : theme.keyBg,
                    }}
                    className="w-6 h-6 rounded text-xs flex items-center justify-center cursor-pointer"
                    title="Skin tone"
                  >
                    {tone ? `👍${tone}` : '👍'}
                  </button>
                ))}
              </div>
              <button type="button" onClick={() => setActivePanel('keys')} className="text-xs opacity-75 px-2 cursor-pointer">
                {isArUi ? 'إغلاق' : 'Close'}
              </button>
            </div>

            <div className="flex items-center gap-1 overflow-x-auto lisan-scroll pb-1">
              {['Recent', 'Favorites', 'Popular', 'Smileys', 'Animals', 'Food', 'Nature', 'Travel', 'Activities', 'Objects', 'Symbols', 'Flags'].map(
                (cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => {
                      setEmojiCategory(cat);
                      setEmojiSearch('');
                    }}
                    style={{
                      backgroundColor: emojiCategory === cat ? theme.micKeyBg : theme.keyBg,
                      color: emojiCategory === cat ? '#FFFFFF' : theme.keyText,
                    }}
                    className="px-2.5 py-1 rounded-md text-[11px] font-medium whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    {cat}
                  </button>
                )
              )}
            </div>

            <div className="grid grid-cols-8 sm:grid-cols-10 gap-1 max-h-[140px] overflow-y-auto lisan-scroll">
              {filteredEmojis.map((item) => {
                const glyph = item.skinTone && skinTone ? `${item.glyph}${skinTone}` : item.glyph;
                return (
                  <div key={item.glyph} className="relative group">
                    <button
                      type="button"
                      onClick={() => {
                        insertAtCursor(glyph);
                        setRecentEmojis((prev) => [item.glyph, ...prev.filter((g) => g !== item.glyph)].slice(0, 12));
                      }}
                      onContextMenu={(e) => {
                        e.preventDefault();
                        setFavoriteEmojis((prev) =>
                          prev.includes(item.glyph) ? prev.filter((g) => g !== item.glyph) : [item.glyph, ...prev]
                        );
                      }}
                      title={`${item.nameEn} · ${item.nameAr}`}
                      className="w-full h-9 text-xl rounded-lg hover:bg-black/15 flex items-center justify-center cursor-pointer active:scale-90"
                    >
                      {glyph}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* PANEL 6: STANDARD KEYS SURFACE */}
        {activePanel === 'keys' && (
          <div className="space-y-1.5" style={{ gap: `${customization.keyGapPx}px` }}>
            {/* Word Prediction & Personal Dictionary Strip */}
            {customization.showSuggestionsRow && (
              <div className="flex items-center gap-1.5">
                {suggestions.length === 0 ? (
                  <div className="w-full h-8" aria-hidden="true" />
                ) : (
                  <>
                    {suggestions.map((word) => (
                      <button
                        key={word}
                        type="button"
                        onClick={() => applySuggestion(word)}
                        style={{
                          backgroundColor: theme.specialKeyBg,
                          color: theme.keyText,
                          borderRadius: keyBorderRadius,
                        }}
                        className="flex-1 h-8 px-2 text-xs sm:text-sm font-medium truncate cursor-pointer active:scale-95"
                      >
                        {word}
                      </button>
                    ))}
                    {currentToken.length >= 2 && !personalWords.includes(currentToken) && (
                      <button
                        type="button"
                        onClick={() => onAddPersonalWord(currentToken)}
                        title={isArUi ? 'حفظ في قاموسي' : 'Save to Personal Dictionary'}
                        style={{
                          backgroundColor: theme.translateKeyBg,
                          color: '#FFFFFF',
                          borderRadius: keyBorderRadius,
                        }}
                        className="h-8 px-2.5 text-xs font-medium flex items-center gap-1 shrink-0 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </>
                )}
              </div>
            )}

            {/* Number Row */}
            {customization.showNumberRow && (
              <div className="grid grid-cols-10" style={{ gap: `${customization.keyGapPx}px` }}>
                {NUMBER_KEYS.map((key) => (
                  <button
                    key={key.id}
                    type="button"
                    onMouseDown={() => startKeyLongPress(key)}
                    onMouseUp={() => endKeyPress(key)}
                    onMouseLeave={() => setPressedKeyId(null)}
                    style={{
                      height: `${Math.max(32, customization.keyHeightPx - 6)}px`,
                      backgroundColor: pressedKeyId === key.id ? theme.micKeyBg : theme.keyBg,
                      color: pressedKeyId === key.id ? '#FFFFFF' : theme.numberText,
                      borderRadius: keyBorderRadius,
                      border: `${customization.borderWidthPx}px solid ${theme.borderColor}`,
                      fontSize: `${customization.symbolSizePx + 2}px`,
                      boxShadow: keyShadow,
                    }}
                    className="font-medium tabular-nums flex items-center justify-center transition-transform active:scale-95 cursor-pointer"
                  >
                    {key.label}
                  </button>
                ))}
              </div>
            )}

            {/* Arabic Harakat / Tashkeel Row */}
            {customization.showArabicHarakatRow && settings.keyboardLang === 'ar' && !symbolsMode && (
              <div className="grid grid-cols-10" style={{ gap: `${customization.keyGapPx}px` }}>
                {ARABIC_HARAKAT_KEYS.map((key) => (
                  <button
                    key={key.id}
                    type="button"
                    onMouseDown={() => startKeyLongPress(key)}
                    onMouseUp={() => endKeyPress(key)}
                    onMouseLeave={() => setPressedKeyId(null)}
                    style={{
                      height: '32px',
                      backgroundColor: pressedKeyId === key.id ? theme.translateKeyBg : theme.specialKeyBg,
                      color: pressedKeyId === key.id ? '#FFFFFF' : theme.keyText,
                      borderRadius: keyBorderRadius,
                      border: `${customization.borderWidthPx}px solid ${theme.borderColor}`,
                      fontSize: '18px',
                    }}
                    className="flex items-center justify-center transition-transform active:scale-95 cursor-pointer"
                    title={key.alternates ? `Long press: ${key.alternates.join(' ')}` : undefined}
                  >
                    {key.label}
                  </button>
                ))}
              </div>
            )}

            {/* Main Letter / Symbol Rows */}
            {activeLetterRows.map((row, rIdx) => (
              <div
                key={rIdx}
                className="flex items-center justify-center"
                style={{ gap: `${customization.keyGapPx}px` }}
              >
                {rIdx === 2 && !symbolsMode && settings.keyboardLang !== 'ar' && (
                  <button
                    type="button"
                    onClick={() => setShifted((s) => !s)}
                    style={{
                      height: `${customization.keyHeightPx}px`,
                      backgroundColor: shifted ? theme.micKeyBg : theme.specialKeyBg,
                      color: shifted ? '#FFFFFF' : theme.keyText,
                      borderRadius: keyBorderRadius,
                      border: `${customization.borderWidthPx}px solid ${theme.borderColor}`,
                    }}
                    className="px-3 text-sm font-semibold flex items-center justify-center cursor-pointer active:scale-95"
                  >
                    ⇧
                  </button>
                )}

                {row.map((key) => {
                  const display =
                    settings.keyboardLang !== 'ar' && !symbolsMode && shifted
                      ? key.label.toUpperCase()
                      : key.label;
                  return (
                    <button
                      key={key.id}
                      type="button"
                      onMouseDown={() => startKeyLongPress(key)}
                      onMouseUp={() => endKeyPress(key)}
                      onMouseLeave={() => setPressedKeyId(null)}
                      style={{
                        height: `${customization.keyHeightPx}px`,
                        backgroundColor: pressedKeyId === key.id ? theme.micKeyBg : theme.keyBg,
                        color: pressedKeyId === key.id ? '#FFFFFF' : theme.keyText,
                        borderRadius: keyBorderRadius,
                        border: `${customization.borderWidthPx}px solid ${theme.borderColor}`,
                        fontSize: `${customization.letterSizePx}px`,
                        boxShadow: keyShadow,
                      }}
                      className="relative flex-1 min-w-0 font-medium flex items-center justify-center transition-transform active:scale-95 cursor-pointer"
                    >
                      <span>{display}</span>
                      {key.alternates && (
                        <span
                          style={{ color: theme.symbolText }}
                          className="absolute top-0.5 right-1 text-[8px] leading-none opacity-70"
                        >
                          •
                        </span>
                      )}
                    </button>
                  );
                })}

                {rIdx === 2 && (
                  <button
                    type="button"
                    onClick={() => handleBackspace(false)}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      handleBackspace(true);
                    }}
                    title={isArUi ? 'حذف (انقر بزر الفأرة الأيمن لحذف كلمة)' : 'Backspace (Right-click deletes word)'}
                    style={{
                      height: `${customization.keyHeightPx}px`,
                      backgroundColor: theme.specialKeyBg,
                      color: theme.keyText,
                      borderRadius: keyBorderRadius,
                      border: `${customization.borderWidthPx}px solid ${theme.borderColor}`,
                    }}
                    className="px-3 flex items-center justify-center cursor-pointer active:scale-95"
                  >
                    <Delete className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}

            {/* Bottom Control Row */}
            <div className="flex items-center" style={{ gap: `${customization.keyGapPx}px` }}>
              <button
                type="button"
                onClick={() => setSymbolsMode((s) => !s)}
                style={{
                  height: `${customization.keyHeightPx}px`,
                  backgroundColor: symbolsMode ? theme.translateKeyBg : theme.specialKeyBg,
                  color: symbolsMode ? '#FFFFFF' : theme.symbolText,
                  borderRadius: keyBorderRadius,
                  border: `${customization.borderWidthPx}px solid ${theme.borderColor}`,
                  fontSize: `${customization.symbolSizePx}px`,
                }}
                className="px-3 font-semibold cursor-pointer active:scale-95"
              >
                {symbolsMode ? (settings.keyboardLang === 'ar' ? 'أبج' : 'ABC') : '?!#123'}
              </button>

              <button
                type="button"
                onClick={onToggleLanguage}
                style={{
                  height: `${customization.keyHeightPx}px`,
                  backgroundColor: theme.specialKeyBg,
                  color: theme.keyText,
                  borderRadius: keyBorderRadius,
                  border: `${customization.borderWidthPx}px solid ${theme.borderColor}`,
                }}
                className="px-2.5 text-xs font-semibold flex items-center gap-1 cursor-pointer active:scale-95"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>{settings.keyboardLang.toUpperCase()}</span>
              </button>

              <button
                type="button"
                onClick={() => insertAtCursor(settings.keyboardLang === 'ar' ? '،' : ',')}
                style={{
                  height: `${customization.keyHeightPx}px`,
                  backgroundColor: theme.keyBg,
                  color: theme.symbolText,
                  borderRadius: keyBorderRadius,
                  border: `${customization.borderWidthPx}px solid ${theme.borderColor}`,
                }}
                className="w-9 text-base font-medium flex items-center justify-center cursor-pointer active:scale-95"
              >
                {settings.keyboardLang === 'ar' ? '،' : ','}
              </button>

              <button
                type="button"
                onClick={handleSpace}
                style={{
                  height: `${customization.keyHeightPx}px`,
                  backgroundColor: theme.keyBg,
                  color: theme.numberText,
                  borderRadius: keyBorderRadius,
                  border: `${customization.borderWidthPx}px solid ${theme.borderColor}`,
                  boxShadow: keyShadow,
                }}
                className="flex-1 text-xs font-medium flex items-center justify-center cursor-pointer active:scale-98"
              >
                {settings.keyboardLang === 'ar' ? 'العربية · Lisan' : `${settings.keyboardLang.toUpperCase()} · Lisan`}
              </button>

              <button
                type="button"
                onClick={() => insertAtCursor('.')}
                style={{
                  height: `${customization.keyHeightPx}px`,
                  backgroundColor: theme.keyBg,
                  color: theme.symbolText,
                  borderRadius: keyBorderRadius,
                  border: `${customization.borderWidthPx}px solid ${theme.borderColor}`,
                }}
                className="w-9 text-base font-medium flex items-center justify-center cursor-pointer active:scale-95"
              >
                .
              </button>

              <button
                type="button"
                onClick={() => setActivePanel('voice')}
                title={isArUi ? 'كتابة صوتية' : 'Voice Input'}
                style={{
                  height: `${customization.keyHeightPx}px`,
                  backgroundColor: theme.micKeyBg,
                  color: '#FFFFFF',
                  borderRadius: keyBorderRadius,
                }}
                className="w-10 flex items-center justify-center cursor-pointer active:scale-95"
              >
                <Mic className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => insertAtCursor('\n')}
                style={{
                  height: `${customization.keyHeightPx}px`,
                  backgroundColor: theme.translateKeyBg,
                  color: '#FFFFFF',
                  borderRadius: keyBorderRadius,
                }}
                className="px-3.5 text-sm font-semibold flex items-center justify-center cursor-pointer active:scale-95"
              >
                ↵
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
