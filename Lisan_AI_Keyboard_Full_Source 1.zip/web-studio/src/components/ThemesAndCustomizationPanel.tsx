import React, { useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Check,
  Download,
  Eye,
  EyeOff,
  FileUp,
  Palette,
  RotateCcw,
  Save,
  Trash2,
  Type as TypeIcon,
} from 'lucide-react';
import { DEFAULT_CUSTOMIZATION, GALLERY_THEMES, SIGNATURE_THEMES } from '../data/lisanData';
import type {
  FontItem,
  KeyboardCustomization,
  KeyboardTheme,
  KeyShape,
  ToolbarButtonId,
  UiLanguage,
} from '../types/lisan';

interface ThemesAndCustomizationPanelProps {
  uiLang: UiLanguage;
  activeTheme: KeyboardTheme;
  customThemes: KeyboardTheme[];
  onSelectTheme: (theme: KeyboardTheme) => void;
  onSaveCustomTheme: (theme: KeyboardTheme) => void;
  customization: KeyboardCustomization;
  onChangeCustomization: (next: KeyboardCustomization) => void;
  fonts: FontItem[];
  onToggleInstallFont: (id: string) => void;
}

export const ThemesAndCustomizationPanel: React.FC<ThemesAndCustomizationPanelProps> = ({
  uiLang,
  activeTheme,
  customThemes,
  onSelectTheme,
  onSaveCustomTheme,
  customization,
  onChangeCustomization,
  fonts,
  onToggleInstallFont,
}) => {
  const isAr = uiLang === 'ar';
  const [tab, setTab] = useState<'models' | 'gallery' | 'dimensions' | 'fonts'>('models');
  const [galleryCategory, setGalleryCategory] = useState<string>('All');
  const [draftTheme, setDraftTheme] = useState<KeyboardTheme>({
    ...activeTheme,
    id: `custom_${Date.now()}`,
    nameEn: 'My Custom Theme',
    nameAr: 'سمتي المخصصة',
    category: 'Custom',
  });
  const [importText, setImportText] = useState('');
  const [importError, setImportError] = useState<string | null>(null);
  const [fontPreviewSize, setFontPreviewSize] = useState(22);

  const allThemes = [...GALLERY_THEMES, ...customThemes];
  const filteredGallery =
    galleryCategory === 'All' ? allThemes : allThemes.filter((t) => t.category === galleryCategory);

  const moveToolbarButton = (idx: number, dir: -1 | 1) => {
    const nextIdx = idx + dir;
    if (nextIdx < 0 || nextIdx >= customization.toolbarOrder.length) return;
    const copy = [...customization.toolbarOrder];
    const [removed] = copy.splice(idx, 1);
    copy.splice(nextIdx, 0, removed);
    onChangeCustomization({ ...customization, toolbarOrder: copy });
  };

  const toggleToolbarHidden = (id: ToolbarButtonId) => {
    const hidden = customization.hiddenToolbarButtons.includes(id)
      ? customization.hiddenToolbarButtons.filter((x) => x !== id)
      : [...customization.hiddenToolbarButtons, id];
    onChangeCustomization({ ...customization, hiddenToolbarButtons: hidden });
  };

  const exportThemeJson = () => {
    const blob = new Blob([JSON.stringify(activeTheme, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activeTheme.id}_theme.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportTheme = () => {
    setImportError(null);
    try {
      const parsed = JSON.parse(importText) as KeyboardTheme;
      if (!parsed.bgColor || !parsed.keyBg || !parsed.keyText) {
        throw new Error('Invalid theme JSON fields.');
      }
      const normalized: KeyboardTheme = {
        ...parsed,
        id: `imported_${Date.now()}`,
        category: 'Custom',
      };
      onSaveCustomTheme(normalized);
      onSelectTheme(normalized);
      setImportText('');
    } catch (e) {
      setImportError(e instanceof Error ? e.message : 'Invalid JSON');
    }
  };

  return (
    <div className="space-y-6">
      {/* Sub-navigation */}
      <div className="flex items-center gap-2 flex-wrap border-b border-slate-200 dark:border-slate-800 pb-3">
        {[
          { id: 'models', ar: 'النماذج الأربعة الأساسية', en: '4 Signature Models' },
          { id: 'gallery', ar: 'معرض السمات وإنشاء سمة', en: 'Themes Gallery & Custom' },
          { id: 'dimensions', ar: 'الأبعاد والصفوف والأدوات', en: 'Layout, Sizes & Toolbar' },
          { id: 'fonts', ar: 'مكتبة الخطوط والتشكيل', en: 'Font Library & Tashkeel' },
        ].map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setTab(item.id as typeof tab)}
            className={`px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
              tab === item.id
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            {isAr ? item.ar : item.en}
          </button>
        ))}
      </div>

      {/* TAB 1: 4 SIGNATURE DESIGN MODELS */}
      {tab === 'models' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {SIGNATURE_THEMES.map((model, idx) => {
            const isSelected = activeTheme.id === model.id;
            return (
              <div
                key={model.id}
                className={`rounded-xl border p-4 transition-colors ${
                  isSelected
                    ? 'border-indigo-500 bg-indigo-500/5'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div>
                    <h4 className="text-sm font-semibold">
                      0{idx + 1}. {isAr ? model.nameAr : model.nameEn}
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {isAr ? model.nameEn : model.nameAr}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSelectTheme(model)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-900 dark:bg-slate-800 text-white hover:bg-slate-700'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5" />}
                    {isSelected ? (isAr ? 'مُعتمد حالياً' : 'Active') : isAr ? 'اعتماد النموذج' : 'Apply Model'}
                  </button>
                </div>

                {/* Live Mini Preview of the Design Model */}
                <div
                  style={{
                    background: model.bgGradientEnd
                      ? `linear-gradient(155deg, ${model.bgColor}, ${model.bgGradientEnd})`
                      : model.bgColor,
                    borderColor: model.borderColor,
                  }}
                  className="rounded-xl p-2.5 border space-y-1.5"
                >
                  <div className="grid grid-cols-6 gap-1">
                    {['ض', 'ص', 'ث', 'ق', 'ف', 'غ'].map((k) => (
                      <div
                        key={k}
                        style={{
                          backgroundColor: model.keyBg,
                          color: model.keyText,
                          borderRadius: `${model.cornerRadius}px`,
                          border: `${model.borderWidth}px solid ${model.borderColor}`,
                        }}
                        className="h-7 flex items-center justify-center text-xs font-medium"
                      >
                        {k}
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center gap-1">
                    <div
                      style={{ backgroundColor: model.translateKeyBg }}
                      className="h-7 w-10 rounded-md text-white text-[10px] flex items-center justify-center"
                    >
                      AR/EN
                    </div>
                    <div
                      style={{ backgroundColor: model.keyBg, color: model.numberText }}
                      className="flex-1 h-7 rounded-md text-[10px] flex items-center justify-center"
                    >
                      Lisan AI Keyboard
                    </div>
                    <div
                      style={{ backgroundColor: model.micKeyBg }}
                      className="h-7 w-10 rounded-md text-white text-[10px] flex items-center justify-center"
                    >
                      Mic
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 2: THEMES GALLERY + CUSTOM THEME BUILDER */}
      {tab === 'gallery' && (
        <div className="space-y-6">
          <div className="flex items-center gap-1.5 flex-wrap">
            {['All', 'Signature', 'Dark', 'Light', 'Colorful', 'Gradient', 'Transparent', 'Professional', 'Nature', 'Futuristic', 'Custom'].map(
              (cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setGalleryCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer ${
                    galleryCategory === cat
                      ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {cat}
                </button>
              )
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {filteredGallery.map((theme) => (
              <button
                key={theme.id}
                type="button"
                onClick={() => onSelectTheme(theme)}
                className={`text-start rounded-xl border p-3 transition-colors cursor-pointer ${
                  activeTheme.id === theme.id
                    ? 'border-indigo-500 ring-1 ring-indigo-500'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-400 dark:hover:border-slate-600'
                }`}
              >
                <div
                  style={{
                    background: theme.bgGradientEnd
                      ? `linear-gradient(155deg, ${theme.bgColor}, ${theme.bgGradientEnd})`
                      : theme.bgColor,
                    opacity: theme.bgOpacity,
                  }}
                  className="h-14 rounded-lg p-2 flex items-center justify-between gap-1.5 mb-2.5 border border-black/10"
                >
                  <span
                    style={{ backgroundColor: theme.keyBg, color: theme.keyText, borderRadius: `${theme.cornerRadius}px` }}
                    className="px-2.5 py-1 text-xs font-medium"
                  >
                    ض ص
                  </span>
                  <span
                    style={{ backgroundColor: theme.specialKeyBg, color: theme.numberText, borderRadius: `${theme.cornerRadius}px` }}
                    className="px-2.5 py-1 text-xs"
                  >
                    123
                  </span>
                  <span
                    style={{ backgroundColor: theme.micKeyBg, borderRadius: `${theme.cornerRadius}px` }}
                    className="px-2.5 py-1 text-xs text-white"
                  >
                    Mic
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold">{isAr ? theme.nameAr : theme.nameEn}</span>
                  <span className="text-slate-500">{theme.category}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Custom Theme Creator + JSON Export/Import */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h4 className="text-sm font-semibold flex items-center gap-2">
                <Palette className="w-4 h-4 text-indigo-500" />
                {isAr ? 'مصمم السمة الشخصية وتصديرها' : 'Custom Theme Builder & JSON Export/Import'}
              </h4>
              <button
                type="button"
                onClick={exportThemeJson}
                className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                {isAr ? 'تصدير السمة الحالية JSON' : 'Export Active JSON'}
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
              {[
                { key: 'bgColor', ar: 'لون الخلفية', en: 'Background' },
                { key: 'keyBg', ar: 'خلفية المفتاح', en: 'Key Surface' },
                { key: 'keyText', ar: 'لون الأحرف', en: 'Letters' },
                { key: 'numberText', ar: 'لون الأرقام', en: 'Numbers' },
                { key: 'symbolText', ar: 'لون الرموز', en: 'Symbols' },
                { key: 'specialKeyBg', ar: 'الأزرار الخاصة', en: 'Special Keys' },
                { key: 'micKeyBg', ar: 'زر الميكروفون', en: 'Mic Key' },
                { key: 'translateKeyBg', ar: 'زر الترجمة', en: 'Translate Key' },
                { key: 'borderColor', ar: 'لون الحدود', en: 'Border Color' },
              ].map((field) => (
                <label key={field.key} className="flex items-center justify-between gap-2 text-xs p-2 rounded-lg border border-slate-200 dark:border-slate-800">
                  <span>{isAr ? field.ar : field.en}</span>
                  <input
                    type="color"
                    value={String(draftTheme[field.key as keyof KeyboardTheme] ?? '#000000')}
                    onChange={(e) => {
                      const updated = { ...draftTheme, [field.key]: e.target.value };
                      setDraftTheme(updated);
                      onSelectTheme(updated);
                    }}
                    className="w-7 h-7 rounded cursor-pointer border-0 bg-transparent"
                  />
                </label>
              ))}
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <input
                type="text"
                value={isAr ? draftTheme.nameAr : draftTheme.nameEn}
                onChange={(e) =>
                  setDraftTheme({
                    ...draftTheme,
                    nameAr: isAr ? e.target.value : draftTheme.nameAr,
                    nameEn: !isAr ? e.target.value : draftTheme.nameEn,
                  })
                }
                className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent text-xs"
                placeholder={isAr ? 'اسم السمة' : 'Theme name'}
              />
              <button
                type="button"
                onClick={() => {
                  const saved = { ...draftTheme, id: `custom_${Date.now()}` };
                  onSaveCustomTheme(saved);
                  onSelectTheme(saved);
                }}
                className="px-3.5 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                {isAr ? 'حفظ السمة في المعرض' : 'Save Custom Theme'}
              </button>
            </div>

            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  placeholder={isAr ? 'الصق كود JSON للسمة لاستيرادها...' : 'Paste Theme JSON to import...'}
                  className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent text-xs font-mono"
                />
                <button
                  type="button"
                  onClick={handleImportTheme}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                >
                  <FileUp className="w-3.5 h-3.5" />
                  {isAr ? 'استيراد' : 'Import'}
                </button>
              </div>
              {importError && <p className="text-xs text-rose-500">{importError}</p>}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: DIMENSIONS, ROWS & TOOLBAR ORDER */}
      {tab === 'dimensions' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold">
              {isAr ? 'التحكم المباشر بأبعاد وشكل لوحة المفاتيح' : 'Live Keyboard Geometry & Style Controls'}
            </h4>
            <button
              type="button"
              onClick={() => onChangeCustomization(DEFAULT_CUSTOMIZATION)}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              {isAr ? 'استعادة الأبعاد الافتراضية' : 'Reset Geometry'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { key: 'heightPx', ar: 'ارتفاع اللوحة (px)', en: 'Keyboard Height (px)', min: 220, max: 380, step: 5 },
              { key: 'widthPercent', ar: 'عرض اللوحة (%)', en: 'Keyboard Width (%)', min: 75, max: 100, step: 1 },
              { key: 'keyHeightPx', ar: 'ارتفاع الأزرار (px)', en: 'Key Height (px)', min: 34, max: 56, step: 1 },
              { key: 'keyGapPx', ar: 'المسافة بين الأزرار (px)', en: 'Key Spacing (px)', min: 2, max: 10, step: 1 },
              { key: 'letterSizePx', ar: 'حجم الأحرف (px)', en: 'Letter Size (px)', min: 13, max: 24, step: 1 },
              { key: 'symbolSizePx', ar: 'حجم الرموز (px)', en: 'Symbol Size (px)', min: 10, max: 18, step: 1 },
              { key: 'toolbarHeightPx', ar: 'ارتفاع شريط الأدوات (px)', en: 'Toolbar Height (px)', min: 34, max: 56, step: 2 },
              { key: 'cornerRadiusPx', ar: 'استدارة الحواف (px)', en: 'Corner Radius (px)', min: 0, max: 20, step: 1 },
              { key: 'borderWidthPx', ar: 'سماكة الحدود (px)', en: 'Border Width (px)', min: 0, max: 3, step: 1 },
              { key: 'shadowLevel', ar: 'الظلال (0-2)', en: 'Shadow Depth (0-2)', min: 0, max: 2, step: 1 },
              { key: 'bgOpacity', ar: 'شفافية الخلفية', en: 'Background Opacity', min: 0.5, max: 1, step: 0.05 },
            ].map((ctrl) => {
              const val = Number(customization[ctrl.key as keyof KeyboardCustomization]);
              return (
                <label key={ctrl.key} className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2 block">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium">{isAr ? ctrl.ar : ctrl.en}</span>
                    <span className="font-mono tabular-nums text-indigo-500">{val}</span>
                  </div>
                  <input
                    type="range"
                    min={ctrl.min}
                    max={ctrl.max}
                    step={ctrl.step}
                    value={val}
                    onChange={(e) =>
                      onChangeCustomization({
                        ...customization,
                        [ctrl.key]: Number(e.target.value),
                      })
                    }
                    className="w-full accent-indigo-600 cursor-pointer"
                  />
                </label>
              );
            })}

            <label className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2 block">
              <span className="text-xs font-medium block">{isAr ? 'شكل الأزرار' : 'Key Shape'}</span>
              <select
                value={customization.keyShape}
                onChange={(e) =>
                  onChangeCustomization({ ...customization, keyShape: e.target.value as KeyShape })
                }
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent text-xs"
              >
                <option value="rounded">{isAr ? 'مستدير ناعم' : 'Rounded'}</option>
                <option value="squircle">{isAr ? 'بيضاوي حديث' : 'Squircle'}</option>
                <option value="pill">{isAr ? 'كبسولة' : 'Pill'}</option>
                <option value="sharp">{isAr ? 'حواف حادة دقيقة' : 'Sharp Modular'}</option>
              </select>
            </label>
          </div>

          {/* Row Visibility Toggles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { key: 'showNumberRow', ar: 'إظهار صف الأرقام', en: 'Show Number Row' },
              { key: 'showSuggestionsRow', ar: 'إظهار صف الاقتراحات', en: 'Show Suggestions Row' },
              { key: 'showToolbarRow', ar: 'إظهار شريط الأدوات', en: 'Show Toolbar Row' },
              { key: 'showArabicHarakatRow', ar: 'إظهار صف الحركات العربية', en: 'Show Arabic Harakat Row' },
            ].map((toggle) => {
              const checked = Boolean(customization[toggle.key as keyof KeyboardCustomization]);
              return (
                <label
                  key={toggle.key}
                  className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-medium cursor-pointer"
                >
                  <span>{isAr ? toggle.ar : toggle.en}</span>
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={(e) =>
                      onChangeCustomization({ ...customization, [toggle.key]: e.target.checked })
                    }
                    className="w-4 h-4 accent-indigo-600"
                  />
                </label>
              );
            })}
          </div>

          {/* Toolbar Reorder & Visibility */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
            <h4 className="text-sm font-semibold">
              {isAr ? 'ترتيب وإظهار أزرار شريط الأدوات الذكي' : 'Smart Toolbar Button Order & Visibility'}
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {customization.toolbarOrder.map((btnId, idx) => {
                const isHidden = customization.hiddenToolbarButtons.includes(btnId);
                return (
                  <div
                    key={btnId}
                    className="flex items-center justify-between px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 text-xs"
                  >
                    <span className={`font-medium capitalize ${isHidden ? 'opacity-40 line-through' : ''}`}>
                      {btnId}
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => moveToolbarButton(idx, -1)}
                        className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded cursor-pointer"
                        aria-label="Move up"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => moveToolbarButton(idx, 1)}
                        className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded cursor-pointer"
                        aria-label="Move down"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => toggleToolbarHidden(btnId)}
                        className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded cursor-pointer"
                        aria-label="Toggle visibility"
                      >
                        {isHidden ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: FONT LIBRARY & TASHKEEL PREVIEW */}
      {tab === 'fonts' && (
        <div className="space-y-4">
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <TypeIcon className="w-4 h-4 text-indigo-500" />
                <span className="text-sm font-semibold">
                  {isAr ? 'معاينة الحروف العربية المشكّلة' : 'Arabic Tashkeel & Typography Preview'}
                </span>
              </div>
              <label className="flex items-center gap-2 text-xs">
                <span>{isAr ? 'حجم المعاينة:' : 'Size:'}</span>
                <input
                  type="range"
                  min={14}
                  max={32}
                  value={fontPreviewSize}
                  onChange={(e) => setFontPreviewSize(Number(e.target.value))}
                  className="accent-indigo-600"
                />
                <span className="font-mono tabular-nums">{fontPreviewSize}px</span>
              </label>
            </div>
            <p
              style={{ fontFamily: customization.fontFamily, fontSize: `${fontPreviewSize}px` }}
              className="leading-relaxed py-2"
            >
              اُكْتُبْ، تَحَدَّثْ، تَرْجِمْ... بِلُغَتِكَ وَبِكُلِّ اللُّغَاتِ — Lisan AI Keyboard ٠١٢٣٤٥٦٧٨٩
            </p>
            <p className="text-xs text-slate-500">
              {isAr
                ? 'ملاحظة شفافة: اختيار الخط يغيّر عرض أحرف لوحة المفاتيح وواجهاتها، ولا يفرض تغيير الخط داخل التطبيقات المستقبِلة للنص.'
                : 'Transparency note: Font selection styles the keyboard keys and Lisan UI; external receiving apps control their own rendering fonts.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {fonts.map((font) => {
              const isActive = customization.fontFamily === font.cssFamily;
              return (
                <div
                  key={font.id}
                  className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 ${
                    isActive
                      ? 'border-indigo-500 bg-indigo-500/5'
                      : 'border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div className="min-w-0">
                    <p style={{ fontFamily: font.cssFamily }} className="text-base font-semibold truncate">
                      {font.name} — لِسَان
                    </p>
                    <p className="text-xs text-slate-500 tabular-nums">
                      {font.script} · {font.license} · {font.sizeKb} KB
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {font.installed ? (
                      <>
                        <button
                          type="button"
                          onClick={() => onChangeCustomization({ ...customization, fontFamily: font.cssFamily })}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer ${
                            isActive
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-900 dark:bg-slate-800 text-white'
                          }`}
                        >
                          {isActive ? (isAr ? 'نشط' : 'Active') : isAr ? 'اختيار' : 'Select'}
                        </button>
                        {!font.builtin && (
                          <button
                            type="button"
                            onClick={() => onToggleInstallFont(font.id)}
                            className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-500/10 cursor-pointer"
                            title={isAr ? 'حذف الخط' : 'Remove font'}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onToggleInstallFont(font.id)}
                        className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-medium flex items-center gap-1 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        {isAr ? 'تنزيل' : 'Download'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
