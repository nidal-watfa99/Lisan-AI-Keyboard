import React, { useEffect, useRef, useState } from 'react';
import {
  Check,
  CheckCircle2,
  ClipboardCopy,
  Download,
  Globe,
  Keyboard,
  Languages,
  Lock,
  Mail,
  MessageSquare,
  Mic,
  Moon,
  Palette,
  RefreshCw,
  Send,
  Settings,
  Share2,
  Sliders,
  Sun,
  Trash2,
} from 'lucide-react';
import { InteractiveKeyboard } from './components/InteractiveKeyboard';
import { SettingsAndSupportPanel } from './components/SettingsAndSupportPanel';
import { ThemesAndCustomizationPanel } from './components/ThemesAndCustomizationPanel';
import {
  DEFAULT_CUSTOMIZATION,
  DEFAULT_SETTINGS,
  FONT_LIBRARY,
  INITIAL_CLIPBOARD,
  INITIAL_LANGUAGE_PACKS,
  SIGNATURE_THEMES,
} from './data/lisanData';
import type {
  ClipboardItem,
  FontItem,
  KeyboardCustomization,
  KeyboardLangCode,
  KeyboardTheme,
  LanguagePackItem,
  LisanSettings,
  TranslationHistoryEntry,
} from './types/lisan';
import brandEmblem from './assets/images/lisan_brand_emblem_1795380532594.jpg';
import heroBackdrop from './assets/images/lisan_hero_backdrop_1795380533533.jpg';

type MainTab = 'overview' | 'keyboard' | 'design' | 'translate' | 'settings';
type SimAppId = 'whatsapp' | 'telegram' | 'gmail' | 'notes' | 'browser' | 'password';

const STORAGE_KEY = 'lisan_ai_keyboard_studio_v1';

const SIM_APPS: {
  id: SimAppId;
  name: string;
  placeholderAr: string;
  placeholderEn: string;
  sensitive?: boolean;
}[] = [
  { id: 'whatsapp', name: 'WhatsApp', placeholderAr: 'اكتب رسالة واتساب بالعربية أو الإنجليزية...', placeholderEn: 'Type a WhatsApp message...' },
  { id: 'telegram', name: 'Telegram', placeholderAr: 'رسالة تيليجرام سريعة مع التشكيل...', placeholderEn: 'Write a Telegram message...' },
  { id: 'gmail', name: 'Gmail', placeholderAr: 'صياغة بريد إلكتروني احترافي...', placeholderEn: 'Compose a professional email...' },
  { id: 'notes', name: 'Notes', placeholderAr: 'دوّن ملاحظاتك بالصوت أو لوحة المفاتيح...', placeholderEn: 'Capture notes by typing or voice...' },
  { id: 'browser', name: 'Browser', placeholderAr: 'ابحث أو اكتب رابطاً...', placeholderEn: 'Search or enter URL...' },
  { id: 'password', name: 'Password Field', placeholderAr: 'حقل كلمة مرور حساس (وضع الخصوصية)...', placeholderEn: 'Sensitive password input (Private Mode)...', sensitive: true },
];

export default function App() {
  const loaded = (() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  })();

  const [activeTab, setActiveTab] = useState<MainTab>('keyboard');
  const [settings, setSettings] = useState<LisanSettings>(() => ({
    ...DEFAULT_SETTINGS,
    ...(loaded?.settings || {}),
  }));
  const [activeTheme, setActiveTheme] = useState<KeyboardTheme>(loaded?.activeTheme || SIGNATURE_THEMES[0]);
  const [customThemes, setCustomThemes] = useState<KeyboardTheme[]>(loaded?.customThemes || []);
  const [customization, setCustomization] = useState<KeyboardCustomization>(() => ({
    ...DEFAULT_CUSTOMIZATION,
    ...(loaded?.customization || {}),
  }));
  const [languagePacks, setLanguagePacks] = useState<LanguagePackItem[]>(
    loaded?.languagePacks || INITIAL_LANGUAGE_PACKS
  );
  const [fonts, setFonts] = useState<FontItem[]>(loaded?.fonts || FONT_LIBRARY);
  const [clipboardItems, setClipboardItems] = useState<ClipboardItem[]>(
    loaded?.clipboardItems || INITIAL_CLIPBOARD
  );
  const [personalWords, setPersonalWords] = useState<string[]>(loaded?.personalWords || ['لسان', 'Lisan']);
  const [ignoredWords, setIgnoredWords] = useState<string[]>(loaded?.ignoredWords || []);
  const [translationHistory, setTranslationHistory] = useState<TranslationHistoryEntry[]>(
    loaded?.translationHistory || []
  );

  // Interactive testbed state
  const [simApp, setSimApp] = useState<SimAppId>('whatsapp');
  const [simTexts, setSimTexts] = useState<Record<SimAppId, string>>({
    whatsapp: 'السَّلَامُ عَلَيْكُمْ، أهلاً بكم في لوحة مفاتيح لسان الذكية!',
    telegram: '',
    gmail: '',
    notes: '',
    browser: '',
    password: '',
  });
  const [cursorPos, setCursorPos] = useState<number>(simTexts.whatsapp.length);
  const [onboardingStep, setOnboardingStep] = useState<number>(1);
  const [keyboardVisible, setKeyboardVisible] = useState<boolean>(true);
  const textInputRef = useRef<HTMLTextAreaElement | null>(null);

  // Manual translation studio state
  const [manualSourceText, setManualSourceText] = useState('اكتب، تحدث، ترجم... بلغتك وبكل اللغات.');
  const [manualResultText, setManualResultText] = useState('');
  const [manualSourceLang, setManualSourceLang] = useState('auto');
  const [manualTargetLang, setManualTargetLang] = useState('English');
  const [manualLoading, setManualLoading] = useState(false);
  const [manualError, setManualError] = useState<string | null>(null);

  const isAr = settings.appUiLang === 'ar';

  // Sync HTML dir/lang and .dark class cleanly
  useEffect(() => {
    const html = document.documentElement;
    html.lang = settings.appUiLang;
    html.dir = settings.appUiLang === 'ar' ? 'rtl' : 'ltr';
    if (settings.appDarkMode) {
      html.classList.add('dark');
    } else {
      html.classList.remove('dark');
    }
  }, [settings.appUiLang, settings.appDarkMode]);

  // Persist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          settings,
          activeTheme,
          customThemes,
          customization,
          languagePacks,
          fonts,
          clipboardItems,
          personalWords,
          ignoredWords,
          translationHistory,
        })
      );
    } catch {
      // Ignore storage quota issues
    }
  }, [
    settings,
    activeTheme,
    customThemes,
    customization,
    languagePacks,
    fonts,
    clipboardItems,
    personalWords,
    ignoredWords,
    translationHistory,
  ]);

  const currentSimMeta = SIM_APPS.find((a) => a.id === simApp) || SIM_APPS[0];
  const currentFieldText = simTexts[simApp];

  const handleFieldTextChange = (next: string) => {
    setSimTexts((prev) => ({ ...prev, [simApp]: next }));
  };

  const updateSettings = (patch: Partial<LisanSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  };

  const handleToggleKeyboardLang = () => {
    const enabled = languagePacks.filter((p) => p.enabledOnKeyboard);
    const list = enabled.length > 0 ? enabled : languagePacks.slice(0, 2);
    const idx = list.findIndex((p) => p.code === settings.keyboardLang);
    const next = list[(idx + 1) % list.length];
    updateSettings({ keyboardLang: next.code });
  };

  const handleDownloadLanguageModel = (
    code: KeyboardLangCode,
    _kind: 'dict' | 'model',
    action: 'start' | 'pause' | 'delete'
  ) => {
    if (action === 'delete') {
      setLanguagePacks((prev) =>
        prev.map((p) => (p.code === code ? { ...p, modelStatus: 'available', progress: 0 } : p))
      );
      return;
    }
    if (action === 'pause') {
      setLanguagePacks((prev) =>
        prev.map((p) => (p.code === code ? { ...p, modelStatus: 'paused' } : p))
      );
      return;
    }
    setLanguagePacks((prev) =>
      prev.map((p) => (p.code === code ? { ...p, modelStatus: 'downloading', progress: 45 } : p))
    );
    window.setTimeout(() => {
      setLanguagePacks((prev) =>
        prev.map((p) =>
          p.code === code && p.modelStatus === 'downloading'
            ? { ...p, modelStatus: 'installed', dictStatus: 'installed', progress: 100 }
            : p
        )
      );
    }, 800);
  };

  const runManualTranslate = async () => {
    if (!manualSourceText.trim()) return;
    if (!settings.enableCloudTranslation) {
      setManualError(
        isAr ? 'الترجمة السحابية معطلة في الإعدادات. فعّلها للمتابعة.' : 'Cloud Translation is disabled in Settings.'
      );
      return;
    }
    setManualLoading(true);
    setManualError(null);
    try {
      const resp = await fetch('/api/ai/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: manualSourceText,
          sourceLang: manualSourceLang,
          targetLang: manualTargetLang,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error || 'Translation error');
      setManualResultText(data.translatedText);
      setTranslationHistory((prev) => [
        {
          id: `hist-${Date.now()}`,
          original: manualSourceText,
          translated: data.translatedText,
          sourceLang: data.detectedSourceLang || manualSourceLang,
          targetLang: manualTargetLang,
          provider: 'Gemini AI Translation',
          createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
        ...prev.slice(0, 24),
      ]);
    } catch (e) {
      setManualError(e instanceof Error ? e.message : 'Translation failed');
    } finally {
      setManualLoading(false);
    }
  };

  const handleExportFullBackup = () => {
    const payload = JSON.stringify(
      { settings, activeTheme, customThemes, customization, personalWords, clipboardItems },
      null,
      2
    );
    const blob = new Blob([payload], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'lisan_keyboard_backup.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportFullBackup = (raw: string): boolean => {
    try {
      const parsed = JSON.parse(raw);
      if (parsed.settings) setSettings({ ...DEFAULT_SETTINGS, ...parsed.settings });
      if (parsed.activeTheme) setActiveTheme(parsed.activeTheme);
      if (parsed.customization) setCustomization({ ...DEFAULT_CUSTOMIZATION, ...parsed.customization });
      if (Array.isArray(parsed.personalWords)) setPersonalWords(parsed.personalWords);
      return true;
    } catch {
      return false;
    }
  };

  const handleWipeAllData = () => {
    localStorage.removeItem(STORAGE_KEY);
    setSettings(DEFAULT_SETTINGS);
    setActiveTheme(SIGNATURE_THEMES[0]);
    setCustomThemes([]);
    setCustomization(DEFAULT_CUSTOMIZATION);
    setClipboardItems([]);
    setPersonalWords([]);
    setTranslationHistory([]);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      {/* 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-950/95 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className="text-lg font-bold tracking-tight whitespace-nowrap shrink-0 cursor-pointer"
          >
            {isAr ? 'لسان · Lisan AI' : 'Lisan AI Keyboard'}
          </button>

          {/* Zone 2: 5 concise single-line nav links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300">
            {[
              { id: 'overview', ar: 'الرئيسية', en: 'Overview' },
              { id: 'keyboard', ar: 'لوحة المفاتيح', en: 'Live Keyboard' },
              { id: 'design', ar: 'التصميم والخطوط', en: 'Design & Fonts' },
              { id: 'translate', ar: 'الترجمة', en: 'Translation' },
              { id: 'settings', ar: 'الإعدادات والدعم', en: 'Settings' },
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id as MainTab)}
                className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
                  activeTab === item.id
                    ? 'border-indigo-500 text-slate-900 dark:text-white'
                    : 'border-transparent hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {isAr ? item.ar : item.en}
              </button>
            ))}
          </nav>

        </div>
      </header>

      {/* Workspace Utility Strip (below top header) */}
      <div className="border-b border-slate-200 dark:border-slate-800 bg-slate-100/70 dark:bg-slate-900/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-2 overflow-x-auto md:hidden">
            {[
              { id: 'overview', ar: 'الرئيسية', en: 'Overview' },
              { id: 'keyboard', ar: 'الكيبورد', en: 'Keyboard' },
              { id: 'design', ar: 'التصميم', en: 'Design' },
              { id: 'translate', ar: 'الترجمة', en: 'Translate' },
              { id: 'settings', ar: 'الإعدادات', en: 'Settings' },
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id as MainTab)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === item.id ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-slate-800'
                }`}
              >
                {isAr ? item.ar : item.en}
              </button>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-3 text-xs text-slate-600 dark:text-slate-400">
            <span>{isAr ? 'اكتب، تحدث، ترجم... بلغتك وبكل اللغات.' : 'Write, speak, and translate... in your language and every language.'}</span>
            <span aria-hidden="true">·</span>
            <span>{isAr ? `السمة: ${activeTheme.nameAr}` : `Theme: ${activeTheme.nameEn}`}</span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => updateSettings({ appUiLang: isAr ? 'en' : 'ar' })}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5" />
              {isAr ? 'English UI' : 'واجهة عربية'}
            </button>
            <button
              type="button"
              onClick={() => updateSettings({ appDarkMode: !settings.appDarkMode })}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              {settings.appDarkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
              {settings.appDarkMode ? (isAr ? 'وضع نهاري' : 'Light') : isAr ? 'وضع داكن' : 'Dark'}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8 space-y-8">
        {/* TAB 1: OVERVIEW, BRAND IDENTITY & ONBOARDING WIZARD */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              <div className="lg:col-span-7 p-6 sm:p-8 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col justify-between space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 shrink-0 bg-slate-900">
                    <img
                      src={brandEmblem}
                      alt="Lisan AI Keyboard Brand Emblem"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="space-y-2">
                    <h1 className="text-2xl sm:text-4xl font-bold tracking-tight text-balance">
                      {isAr ? 'لسان – لوحة المفاتيح الذكية متعددة اللغات' : 'Lisan AI Keyboard – Multilingual Smart IME'}
                    </h1>
                    <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
                      {isAr
                        ? 'اكتب، تحدث، ترجم... بلغتك وبكل اللغات. تجربة كتابة عربية وإنجليزية متكاملة مع التشكيل الكامل، الكتابة الصوتية، الترجمة الفورية، والتخصيص الكامل.'
                        : 'Write, speak, and translate in your language and every language. Built with native Arabic/Harakat precision, real voice dictation, instant AI translation, and full visual customization.'}
                    </p>
                  </div>
                </div>

                {/* Activation Status & Quick Actions */}
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 space-y-3">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <span className="text-sm font-semibold">
                      {isAr ? 'حالة لوحة المفاتيح والتجهيز' : 'Keyboard Activation & Readiness'}
                    </span>
                    <span className="text-xs text-emerald-500 font-medium">
                      {settings.isKeyboardEnabledInSim && settings.isDefaultKeyboardInSim
                        ? isAr
                          ? 'مفعّلة ومختارة كلوحة افتراضية في المحاكي'
                          : 'Enabled & Active in Studio Simulator'
                        : isAr
                          ? 'بانتظار إكمال التفعيل'
                          : 'Pending Activation'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <button
                      type="button"
                      onClick={() => updateSettings({ isKeyboardEnabledInSim: true })}
                      className="px-3.5 py-2 rounded-lg bg-slate-900 dark:bg-slate-800 text-white text-xs font-medium cursor-pointer"
                    >
                      {isAr ? '1. تفعيل لوحة المفاتيح' : '1. Enable Keyboard'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        updateSettings({ isKeyboardEnabledInSim: true, isDefaultKeyboardInSim: true });
                        setActiveTab('keyboard');
                      }}
                      className="px-3.5 py-2 rounded-lg bg-indigo-600 text-white text-xs font-semibold cursor-pointer"
                    >
                      {isAr ? '2. اختيار لسان وتجربتها الآن' : '2. Select Lisan & Test Live'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('design')}
                      className="px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-medium cursor-pointer"
                    >
                      {isAr ? 'معرض السمات (4 نماذج)' : '4 Design Models'}
                    </button>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-5 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-900 relative min-h-[260px]">
                <img
                  src={heroBackdrop}
                  alt="Lisan Hardware Product Studio"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent p-6 flex flex-col justify-end text-white">
                  <p className="text-xs text-slate-300">
                    {isAr ? 'أيقونة تكيفية وشاشة افتتاحية مدمجة' : 'Adaptive Icon & Splash Screen Included'}
                  </p>
                  <p className="text-base font-semibold mt-1">
                    {isAr ? 'مشروع Kotlin + Jetpack Compose من 12 وحدة معمارية' : '12-Module Kotlin + Jetpack Compose Android IME'}
                  </p>
                </div>
              </div>
            </section>

            {/* 6-Step Onboarding Wizard */}
            <section className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h2 className="text-lg font-semibold">
                  {isAr ? 'معالج الإعداد الأولي (Onboarding)' : 'First-Run Onboarding Wizard'}
                </h2>
                <span className="text-xs text-slate-500 tabular-nums">
                  {isAr ? `الخطوة ${onboardingStep} من 6` : `Step ${onboardingStep} of 6`}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2.5">
                {[
                  { step: 1, ar: 'اختيار اللغات', en: 'Pick Languages' },
                  { step: 2, ar: 'تفعيل من Android', en: 'Enable in Android' },
                  { step: 3, ar: 'تعيين كافتراضية', en: 'Set as Default' },
                  { step: 4, ar: 'إذن الميكروفون عند الصوت', en: 'Mic on Demand' },
                  { step: 5, ar: 'تنزيل نماذج الترجمة', en: 'Download Models' },
                  { step: 6, ar: 'اختيار السمة', en: 'Choose Theme' },
                ].map((s) => (
                  <button
                    key={s.step}
                    type="button"
                    onClick={() => setOnboardingStep(s.step)}
                    className={`p-3 rounded-xl border text-start text-xs transition-colors cursor-pointer ${
                      onboardingStep === s.step
                        ? 'border-indigo-500 bg-indigo-500/10 font-semibold'
                        : 'border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono tabular-nums">0{s.step}</span>
                      {onboardingStep > s.step && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />}
                    </div>
                    <span>{isAr ? s.ar : s.en}</span>
                  </button>
                ))}
              </div>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between flex-wrap gap-3 text-xs">
                <span>
                  {onboardingStep === 1 && (isAr ? 'اختر العربية والإنجليزية أو أضف لغات أخرى من مدير اللغات.' : 'Select Arabic, English, or additional languages from Language Manager.')}
                  {onboardingStep === 2 && (isAr ? 'على هاتف Android: الإعدادات ← النظام ← اللغات والإدخال ← لوحة المفاتيح على الشاشة ← فعّل Lisan.' : 'On Android: Settings → System → Languages & input → On-screen keyboard → Enable Lisan.')}
                  {onboardingStep === 3 && (isAr ? 'اضغط أيقونة الكيبورد واختر Lisan AI Keyboard لتكون اللوحة الافتراضية في جميع التطبيقات.' : 'Open the Input Method Picker and choose Lisan AI Keyboard as your default IME.')}
                  {onboardingStep === 4 && (isAr ? 'لا نطلب إذن الميكروفون أثناء التثبيت؛ يُطلب فقط عند ضغط زر الميكروفون.' : 'Microphone permission is never requested on install; only when tapping the Mic button.')}
                  {onboardingStep === 5 && (isAr ? 'نزّل حزم ML Kit للترجمة دون اتصال، أو فعّل الترجمة السحابية عند الحاجة.' : 'Download ML Kit offline models or enable opt-in cloud translation.')}
                  {onboardingStep === 6 && (isAr ? 'اختر بين النماذج الأربعة: الداكن الفاخر، الفاتح العصري، التدرج الذكي، أو الاحترافي البسيط.' : 'Choose from 4 signature models: Premium Dark, Modern Light, Gradient AI, or Minimal Professional.')}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    if (onboardingStep < 6) setOnboardingStep((s) => s + 1);
                    else setActiveTab('keyboard');
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-indigo-600 text-white font-semibold cursor-pointer"
                >
                  {onboardingStep < 6 ? (isAr ? 'الخطوة التالية' : 'Next Step') : isAr ? 'ابدأ الكتابة الآن' : 'Launch Keyboard'}
                </button>
              </div>
            </section>

            {/* Adaptive Icon & Product Craft Showcase */}
            <section className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
              <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
                <h2 className="text-lg font-semibold">
                  {isAr ? 'الأيقونة التكيفية وشاشة البداية (Splash Screen)' : 'Adaptive Icon & Splash Screen Identity'}
                </h2>
                <div className="flex items-center gap-5 flex-wrap">
                  <div className="text-center space-y-1.5">
                    <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-amber-500/40 bg-slate-950">
                      <img
                        src={brandEmblem}
                        alt="Adaptive Circle Icon"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <span className="text-[11px] text-slate-500 block">Circle Mask</span>
                  </div>
                  <div className="text-center space-y-1.5">
                    <div className="w-20 h-20 rounded-2xl overflow-hidden border-2 border-amber-500/40 bg-slate-950">
                      <img
                        src={brandEmblem}
                        alt="Adaptive Squircle Icon"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <span className="text-[11px] text-slate-500 block">Squircle Mask</span>
                  </div>
                  <div className="flex-1 min-w-[180px] p-4 rounded-xl bg-slate-950 text-white border border-slate-800 flex items-center gap-3">
                    <img
                      src={brandEmblem}
                      alt="Splash Preview"
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-lg object-cover"
                    />
                    <div>
                      <p className="text-sm font-bold">Lisan AI Keyboard</p>
                      <p className="text-[11px] text-slate-400">اكتب، تحدث، ترجم...</p>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        )}

        {/* TAB 2: LIVE ANDROID KEYBOARD SIMULATOR & APP TESTBED */}
        {activeTab === 'keyboard' && (
          <div className="max-w-3xl mx-auto">
            {/* Main Column: Simulated Android App + Live Interactive Keyboard */}
            <div className="space-y-4">
              {/* Target App Selector */}
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-1.5 flex-wrap">
                  {SIM_APPS.map((app) => (
                    <button
                      key={app.id}
                      type="button"
                      onClick={() => {
                        setSimApp(app.id);
                        setCursorPos(simTexts[app.id].length);
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 cursor-pointer ${
                        simApp === app.id
                          ? 'bg-indigo-600 text-white'
                          : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      {app.sensitive ? <Lock className="w-3.5 h-3.5" /> : <MessageSquare className="w-3.5 h-3.5" />}
                      {app.name}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={() => setKeyboardVisible((v) => !v)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-medium cursor-pointer"
                >
                  {keyboardVisible ? (isAr ? 'إخفاء اللوحة' : 'Hide Keyboard') : isAr ? 'إظهار اللوحة' : 'Show Keyboard'}
                </button>
              </div>

              {/* Simulated App Text Editor */}
              <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span className="font-medium">
                    {currentSimMeta.name} · {currentSimMeta.sensitive ? (isAr ? 'حقل حساس' : 'Password Input') : isAr ? 'حقل إدخال حر' : 'Rich Text Input'}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        if (currentFieldText && !currentSimMeta.sensitive) {
                          setClipboardItems((prev) => [
                            {
                              id: `c-${Date.now()}`,
                              text: currentFieldText,
                              category: 'General',
                              pinned: false,
                              createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                            },
                            ...prev,
                          ]);
                          navigator.clipboard?.writeText(currentFieldText).catch(() => {});
                        }
                      }}
                      className="px-2 py-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1 cursor-pointer"
                    >
                      <ClipboardCopy className="w-3.5 h-3.5" />
                      {isAr ? 'نسخ للحافظة' : 'Copy'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        handleFieldTextChange('');
                        setCursorPos(0);
                      }}
                      className="px-2 py-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-rose-500 cursor-pointer"
                    >
                      {isAr ? 'مسح' : 'Clear'}
                    </button>
                  </div>
                </div>

                {currentSimMeta.sensitive ? (
                  <input
                    type="password"
                    value={currentFieldText}
                    onChange={(e) => {
                      handleFieldTextChange(e.target.value);
                      setCursorPos(e.target.selectionStart ?? e.target.value.length);
                    }}
                    placeholder={isAr ? currentSimMeta.placeholderAr : currentSimMeta.placeholderEn}
                    className="w-full px-3.5 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-base outline-none"
                  />
                ) : (
                  <textarea
                    ref={textInputRef}
                    rows={4}
                    dir="auto"
                    value={currentFieldText}
                    onClick={(e) => setCursorPos(e.currentTarget.selectionStart ?? currentFieldText.length)}
                    onKeyUp={(e) => setCursorPos(e.currentTarget.selectionStart ?? currentFieldText.length)}
                    onChange={(e) => {
                      handleFieldTextChange(e.target.value);
                      setCursorPos(e.target.selectionStart ?? e.target.value.length);
                    }}
                    placeholder={isAr ? currentSimMeta.placeholderAr : currentSimMeta.placeholderEn}
                    className="w-full px-3.5 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-base leading-relaxed outline-none resize-none"
                  />
                )}
              </div>

              {/* Live Lisan Keyboard Emulator */}
              {keyboardVisible && (
                <InteractiveKeyboard
                  uiLang={settings.appUiLang}
                  theme={activeTheme}
                  customization={customization}
                  settings={settings}
                  text={currentFieldText}
                  onTextChange={handleFieldTextChange}
                  cursorPos={cursorPos}
                  onCursorChange={setCursorPos}
                  isSensitiveField={Boolean(currentSimMeta.sensitive)}
                  personalWords={personalWords}
                  ignoredWords={ignoredWords}
                  onAddPersonalWord={(w) => setPersonalWords((prev) => Array.from(new Set([w, ...prev])))}
                  clipboardItems={clipboardItems}
                  onSaveClipboard={(t, cat = 'General') =>
                    setClipboardItems((prev) => [
                      {
                        id: `c-${Date.now()}`,
                        text: t,
                        category: cat,
                        pinned: false,
                        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                      },
                      ...prev,
                    ])
                  }
                  onTogglePinClip={(id) =>
                    setClipboardItems((prev) => prev.map((c) => (c.id === id ? { ...c, pinned: !c.pinned } : c)))
                  }
                  onDeleteClip={(id) => setClipboardItems((prev) => prev.filter((c) => c.id !== id))}
                  onClearClips={() => setClipboardItems([])}
                  onEditClip={(id, newText) =>
                    setClipboardItems((prev) => prev.map((c) => (c.id === id ? { ...c, text: newText } : c)))
                  }
                  onAddTranslationHistory={(entry) => setTranslationHistory((prev) => [entry, ...prev.slice(0, 24)])}
                  onToggleLanguage={handleToggleKeyboardLang}
                  onToggleHarakat={() =>
                    setCustomization((c) => ({ ...c, showArabicHarakatRow: !c.showArabicHarakatRow }))
                  }
                  onOpenSettings={() => setActiveTab('settings')}
                />
              )}
            </div>

            <div className="mt-4 flex items-center justify-between gap-3 flex-wrap text-xs">
              <button type="button" onClick={() => setActiveTab('design')} className="text-indigo-500 hover:underline cursor-pointer">
                {isAr ? 'السمات والخطوط والأبعاد ←' : 'Themes, fonts & sizing →'}
              </button>
              <button type="button" onClick={() => setActiveTab('settings')} className="text-indigo-500 hover:underline cursor-pointer">
                {isAr ? 'كل الإعدادات ←' : 'All settings →'}
              </button>
            </div>
            <details className="mt-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 text-xs text-slate-600 dark:text-slate-300">
              <summary className="cursor-pointer font-medium">{isAr ? 'نصائح الاختبار' : 'Testing tips'}</summary>
              <div className="mt-2 space-y-1.5">
                <p>{isAr ? 'اضغط مطولاً على (ا، ل، ي، 1) لعرض الهمزات والأرقام الهندية.' : 'Long-press keys like (ا, ل, ي, 1) for Hamza and Hindi numeral alternates.'}</p>
                <p>{isAr ? 'اختر Password Field أعلاه للتحقق من وضع الخصوصية.' : 'Select "Password Field" above to verify Private Mode.'}</p>
              </div>
            </details>
          </div>
        )}

        {/* TAB 3: DESIGN STUDIO, THEMES GALLERY, DIMENSIONS & FONTS */}
        {activeTab === 'design' && (
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
            <div className="xl:col-span-7 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
              <ThemesAndCustomizationPanel
                uiLang={settings.appUiLang}
                activeTheme={activeTheme}
                customThemes={customThemes}
                onSelectTheme={setActiveTheme}
                onSaveCustomTheme={(t) => setCustomThemes((prev) => [t, ...prev])}
                customization={customization}
                onChangeCustomization={setCustomization}
                fonts={fonts}
                onToggleInstallFont={(id) =>
                  setFonts((prev) => prev.map((f) => (f.id === id ? { ...f, installed: !f.installed } : f)))
                }
              />
            </div>

            <div className="xl:col-span-5 space-y-3 xl:sticky xl:top-20">
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-2">
                <h3 className="text-sm font-semibold">
                  {isAr ? 'معاينة حية فورية للتغييرات' : 'Live Customization Preview'}
                </h3>
                <p className="text-xs text-slate-500">
                  {isAr
                    ? 'أي تعديل على السمة أو الخط أو الارتفاع أو الألوان ينعكس هنا فوراً.'
                    : 'Every theme, font, height, spacing, and color change updates this keyboard immediately.'}
                </p>
              </div>
              <InteractiveKeyboard
                uiLang={settings.appUiLang}
                theme={activeTheme}
                customization={customization}
                settings={settings}
                text={currentFieldText}
                onTextChange={handleFieldTextChange}
                cursorPos={cursorPos}
                onCursorChange={setCursorPos}
                isSensitiveField={false}
                personalWords={personalWords}
                ignoredWords={ignoredWords}
                onAddPersonalWord={(w) => setPersonalWords((prev) => Array.from(new Set([w, ...prev])))}
                clipboardItems={clipboardItems}
                onSaveClipboard={(t) =>
                  setClipboardItems((prev) => [
                    {
                      id: `c-${Date.now()}`,
                      text: t,
                      category: 'General',
                      pinned: false,
                      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    },
                    ...prev,
                  ])
                }
                onTogglePinClip={(id) =>
                  setClipboardItems((prev) => prev.map((c) => (c.id === id ? { ...c, pinned: !c.pinned } : c)))
                }
                onDeleteClip={(id) => setClipboardItems((prev) => prev.filter((c) => c.id !== id))}
                onClearClips={() => setClipboardItems([])}
                onEditClip={(id, newText) =>
                  setClipboardItems((prev) => prev.map((c) => (c.id === id ? { ...c, text: newText } : c)))
                }
                onAddTranslationHistory={(entry) => setTranslationHistory((prev) => [entry, ...prev.slice(0, 24)])}
                onToggleLanguage={handleToggleKeyboardLang}
                onToggleHarakat={() =>
                  setCustomization((c) => ({ ...c, showArabicHarakatRow: !c.showArabicHarakatRow }))
                }
                onOpenSettings={() => setActiveTab('settings')}
              />
            </div>
          </div>
        )}

        {/* TAB 4: STANDALONE AI TRANSLATION & HISTORY WORKSPACE */}
        {activeTab === 'translate' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Languages className="w-5 h-5 text-indigo-500" />
                  {isAr ? 'مترجم لسان اليدوي والفوري' : 'Lisan Standalone Translation Workspace'}
                </h2>
                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.enableCloudTranslation}
                    onChange={(e) => updateSettings({ enableCloudTranslation: e.target.checked })}
                    className="accent-indigo-600"
                  />
                  <span>{isAr ? 'موافقة على الترجمة السحابية HTTPS' : 'Allow HTTPS Cloud Translation'}</span>
                </label>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <select
                  value={manualSourceLang}
                  onChange={(e) => setManualSourceLang(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-xs"
                >
                  <option value="auto">{isAr ? 'اكتشاف اللغة تلقائياً' : 'Auto Detect'}</option>
                  <option value="Arabic">العربية</option>
                  <option value="English">English</option>
                  <option value="French">Français</option>
                  <option value="Spanish">Español</option>
                  <option value="Turkish">Türkçe</option>
                  <option value="German">Deutsch</option>
                </select>
                <button
                  type="button"
                  onClick={() => {
                    if (manualSourceLang !== 'auto') {
                      const prevSrc = manualSourceLang;
                      setManualSourceLang(manualTargetLang);
                      setManualTargetLang(prevSrc);
                    }
                    if (manualResultText) {
                      setManualSourceText(manualResultText);
                      setManualResultText(manualSourceText);
                    }
                  }}
                  className="p-2 rounded-xl border border-slate-300 dark:border-slate-700 cursor-pointer"
                  title={isAr ? 'تبديل اللغتين' : 'Swap Languages'}
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
                <select
                  value={manualTargetLang}
                  onChange={(e) => setManualTargetLang(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-xs"
                >
                  <option value="English">English</option>
                  <option value="Arabic">العربية</option>
                  <option value="French">Français</option>
                  <option value="Spanish">Español</option>
                  <option value="Turkish">Türkçe</option>
                  <option value="German">Deutsch</option>
                </select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <textarea
                  rows={5}
                  dir="auto"
                  value={manualSourceText}
                  onChange={(e) => setManualSourceText(e.target.value)}
                  placeholder={isAr ? 'أدخل أو الصق النص هنا...' : 'Enter or paste text here...'}
                  className="w-full p-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm outline-none"
                />
                <textarea
                  rows={5}
                  dir="auto"
                  readOnly
                  value={manualResultText}
                  placeholder={isAr ? 'ستظهر الترجمة هنا...' : 'Translation appears here...'}
                  className="w-full p-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm outline-none"
                />
              </div>

              {manualError && <p className="text-xs text-rose-500">{manualError}</p>}

              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={runManualTranslate}
                    disabled={manualLoading}
                    className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
                  >
                    {manualLoading ? (isAr ? 'جارٍ الترجمة...' : 'Translating...') : isAr ? 'ترجمة' : 'Translate'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setManualSourceText('');
                      setManualResultText('');
                    }}
                    className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs cursor-pointer"
                  >
                    {isAr ? 'مسح النصوص' : 'Clear'}
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={!manualResultText}
                    onClick={() => navigator.clipboard?.writeText(manualResultText)}
                    className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs flex items-center gap-1.5 disabled:opacity-40 cursor-pointer"
                  >
                    <ClipboardCopy className="w-3.5 h-3.5" />
                    {isAr ? 'نسخ الترجمة' : 'Copy'}
                  </button>
                  <button
                    type="button"
                    disabled={!manualResultText}
                    onClick={() => {
                      if (navigator.share) {
                        navigator.share({ text: manualResultText }).catch(() => {});
                      } else {
                        navigator.clipboard?.writeText(manualResultText);
                      }
                    }}
                    className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs flex items-center gap-1.5 disabled:opacity-40 cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    {isAr ? 'مشاركة' : 'Share'}
                  </button>
                </div>
              </div>
            </div>

            <div className="lg:col-span-4 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">{isAr ? 'سجل الترجمات' : 'Translation History'}</h3>
                {translationHistory.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setTranslationHistory([])}
                    className="text-xs text-rose-500 cursor-pointer"
                  >
                    {isAr ? 'مسح' : 'Clear'}
                  </button>
                )}
              </div>

              {translationHistory.length === 0 ? (
                <p className="text-xs text-slate-500 py-8 text-center">
                  {isAr ? 'لا يوجد سجل ترجمات بعد.' : 'No translations recorded yet.'}
                </p>
              ) : (
                <div className="space-y-2.5 max-h-[360px] overflow-y-auto lisan-scroll">
                  {translationHistory.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between text-[11px] text-slate-500">
                        <span>
                          {item.sourceLang} → {item.targetLang}
                        </span>
                        <span className="tabular-nums">{item.createdAt}</span>
                      </div>
                      <p className="opacity-80">{item.original}</p>
                      <p className="font-medium text-indigo-500">{item.translated}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 5: 20-SECTION SETTINGS, LANGUAGE PACKS, PRIVACY, SUPPORT & ARCHIVE */}
        {activeTab === 'settings' && (
          <div className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
            <SettingsAndSupportPanel
              uiLang={settings.appUiLang}
              settings={settings}
              onUpdateSettings={updateSettings}
              onResetAllSettings={() => {
                setSettings(DEFAULT_SETTINGS);
                setCustomization(DEFAULT_CUSTOMIZATION);
                setActiveTheme(SIGNATURE_THEMES[0]);
              }}
              onExportBackup={handleExportFullBackup}
              onImportBackup={handleImportFullBackup}
              onWipeLocalData={handleWipeAllData}
              languagePacks={languagePacks}
              onToggleLanguagePack={(code) =>
                setLanguagePacks((prev) =>
                  prev.map((p) => (p.code === code ? { ...p, enabledOnKeyboard: !p.enabledOnKeyboard } : p))
                )
              }
              onSetDefaultLanguagePack={(code) => {
                setLanguagePacks((prev) =>
                  prev.map((p) => ({
                    ...p,
                    isDefault: p.code === code,
                    enabledOnKeyboard: p.enabledOnKeyboard || p.code === code,
                  }))
                );
                updateSettings({ keyboardLang: code });
              }}
              onDownloadLanguageModel={handleDownloadLanguageModel}
              personalWords={personalWords}
              onRemovePersonalWord={(w) => setPersonalWords((prev) => prev.filter((x) => x !== w))}
              ignoredWords={ignoredWords}
              onRemoveIgnoredWord={(w) => setIgnoredWords((prev) => prev.filter((x) => x !== w))}
            />
          </div>
        )}
      </main>

      <footer className="border-t border-slate-200 dark:border-slate-800 py-5 px-4 sm:px-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-3">
          <span>Lisan AI Keyboard – لسان · {isAr ? 'اكتب، تحدث، ترجم... بلغتك وبكل اللغات.' : 'Write, speak, translate... in every language.'}</span>
          <div className="flex items-center gap-4">
            <button type="button" onClick={() => setActiveTab('settings')} className="hover:underline cursor-pointer">
              nidalwatfa99@gmail.com
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
