export type UiLanguage = 'ar' | 'en';
export type KeyboardLangCode = 'ar' | 'en' | 'fr' | 'es' | 'tr' | 'de';
export type KeyShape = 'rounded' | 'pill' | 'sharp' | 'squircle';
export type DesignModelId = 'premium_dark' | 'modern_light' | 'gradient_ai' | 'minimal_professional';

export interface KeyboardTheme {
  id: string;
  nameEn: string;
  nameAr: string;
  category:
    | 'Signature'
    | 'Dark'
    | 'Light'
    | 'Colorful'
    | 'Gradient'
    | 'Transparent'
    | 'Professional'
    | 'Minimal'
    | 'Nature'
    | 'Futuristic'
    | 'Custom';
  modelId: DesignModelId;
  bgColor: string;
  bgGradientEnd?: string;
  bgOpacity: number;
  keyBg: string;
  keyText: string;
  numberText: string;
  symbolText: string;
  specialKeyBg: string;
  micKeyBg: string;
  translateKeyBg: string;
  borderColor: string;
  borderWidth: number;
  cornerRadius: number;
  shadowLevel: number;
  keyShape: KeyShape;
}

export type ToolbarButtonId =
  | 'translate'
  | 'voice'
  | 'clipboard'
  | 'emoji'
  | 'search'
  | 'settings'
  | 'language'
  | 'harakat'
  | 'ai';

export interface KeyboardCustomization {
  heightPx: number;
  widthPercent: number;
  keyHeightPx: number;
  keyGapPx: number;
  letterSizePx: number;
  symbolSizePx: number;
  toolbarHeightPx: number;
  showNumberRow: boolean;
  showSuggestionsRow: boolean;
  showToolbarRow: boolean;
  showArabicHarakatRow: boolean;
  keyShape: KeyShape;
  cornerRadiusPx: number;
  borderWidthPx: number;
  shadowLevel: number;
  bgOpacity: number;
  fontFamily: string;
  toolbarOrder: ToolbarButtonId[];
  hiddenToolbarButtons: ToolbarButtonId[];
}

export interface LisanSettings {
  appUiLang: UiLanguage;
  appDarkMode: boolean;
  keyboardLang: KeyboardLangCode;
  voiceLang: string;
  translationSourceLang: string;
  translationTargetLang: string;
  autocorrectLevel: 0 | 1 | 2 | 3;
  enablePredictions: boolean;
  preserveArabicDiacritics: boolean;
  enableClipboardHistory: boolean;
  enableCloudTranslation: boolean;
  enableCloudAiAssistant: boolean;
  hapticMs: number;
  keypressSound: boolean;
  preferOfflineVoice: boolean;
  emojiSkinTone: string;
  notificationsEnabled: boolean;
  isKeyboardEnabledInSim: boolean;
  isDefaultKeyboardInSim: boolean;
}

export interface ClipboardItem {
  id: string;
  text: string;
  category: 'General' | 'Frequent' | 'Work' | 'Code';
  pinned: boolean;
  createdAt: string;
}

export interface TranslationHistoryEntry {
  id: string;
  original: string;
  translated: string;
  sourceLang: string;
  targetLang: string;
  provider: string;
  createdAt: string;
}

export interface LanguagePackItem {
  code: KeyboardLangCode;
  nameEn: string;
  nameAr: string;
  nativeName: string;
  dir: 'rtl' | 'ltr';
  enabledOnKeyboard: boolean;
  isDefault: boolean;
  dictSizeMb: number;
  mlModelSizeMb: number;
  dictStatus: 'installed' | 'available' | 'downloading' | 'paused';
  modelStatus: 'installed' | 'available' | 'downloading' | 'paused';
  progress: number;
}

export interface FontItem {
  id: string;
  name: string;
  cssFamily: string;
  script: 'Arabic' | 'Latin' | 'Bilingual';
  license: string;
  sizeKb: number;
  installed: boolean;
  builtin: boolean;
}

export interface KeyDef {
  id: string;
  label: string;
  output: string;
  alternates?: string[];
  wide?: number;
  kind?: 'letter' | 'special' | 'mic' | 'translate' | 'space' | 'enter' | 'backspace';
}
