package com.lisan.keyboard

import android.content.Context
import android.view.inputmethod.InputMethodManager
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LisanImeInstrumentedTest {
    @Test
    fun appContextResolvesPackageAndInputMethodServiceRegistered() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        assertTrue(imm.inputMethodList.any { it.packageName == "com.lisan.keyboard" })
    }
}
