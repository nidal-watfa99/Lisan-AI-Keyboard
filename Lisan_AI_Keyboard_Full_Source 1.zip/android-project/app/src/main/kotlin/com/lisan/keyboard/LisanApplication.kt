package com.lisan.keyboard

import android.app.Application
import com.lisan.keyboard.clipboard.ClipboardProvider
import com.lisan.keyboard.clipboard.ClipboardRepository
import com.lisan.keyboard.language.LanguagePackManager
import com.lisan.keyboard.prediction.PredictionEngine
import com.lisan.keyboard.privacy.PrivacyGuard
import com.lisan.keyboard.settings.SettingsRepository
import com.lisan.keyboard.translation.MlKitTranslationEngine

class LisanApplication : Application() {
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(applicationContext) }
    val privacyGuard: PrivacyGuard by lazy { PrivacyGuard(applicationContext) }
    val languagePackManager: LanguagePackManager by lazy { LanguagePackManager() }
    val predictionEngine: PredictionEngine by lazy { PredictionEngine() }
    val translationEngine: MlKitTranslationEngine by lazy { MlKitTranslationEngine() }
    val clipboardRepository: ClipboardRepository by lazy { ClipboardProvider.get(applicationContext) }
}
