package com.lisan.keyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.lisan.keyboard.clipboard.ClipboardEntryEntity
import com.lisan.keyboard.settings.LisanUserPreferences
import com.lisan.keyboard.themes.ThemeGallery
import kotlinx.coroutines.launch
import java.util.Locale

const val DEVELOPER_EMAIL = "nidalwatfa99@gmail.com"
// Replace with the real store/project link once published. Until then the share text carries no link.
const val SHARE_LINK = ""

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF8B7CFF))) {
                Surface(Modifier.fillMaxSize()) { LisanApp() }
            }
        }
    }
}

private enum class Screen(val title: String) {
    HOME("Lisan · لسان"), SETTINGS("Settings · الإعدادات"), THEMES("Themes · السمات"),
    LANGUAGES("Languages · اللغات"), TRANSLATE("Translate · ترجمة"), CLIPBOARD("Clipboard · الحافظة"),
    PRIVACY("Privacy · الخصوصية"), SUPPORT("Contact developer · تواصل مع المطور")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LisanApp() {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as LisanApplication
    val prefs by app.settingsRepository.preferences.collectAsState(initial = LisanUserPreferences())
    var screen by remember { mutableStateOf(Screen.HOME) }
    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(screen.title) },
            navigationIcon = { if (screen != Screen.HOME) TextButton({ screen = Screen.HOME }) { Text("←") } }
        )
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (screen) {
                Screen.HOME -> HomeScreen(prefs) { screen = it }
                Screen.SETTINGS -> SettingsScreen(app, prefs)
                Screen.THEMES -> ThemesScreen(app, prefs)
                Screen.LANGUAGES -> LanguagesScreen(app, prefs)
                Screen.TRANSLATE -> TranslateScreen(app, prefs)
                Screen.CLIPBOARD -> ClipboardScreen(app)
                Screen.PRIVACY -> PrivacyScreen(app)
                Screen.SUPPORT -> SupportScreen()
            }
        }
    }
}

@Composable
private fun NavCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun HomeScreen(prefs: LisanUserPreferences, go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    var tick by remember { mutableIntStateOf(0) }
    val enabled = remember(tick) { imm.enabledInputMethodList.any { it.packageName == ctx.packageName } }
    val isDefault = remember(tick) {
        Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.contains(ctx.packageName) == true
    }
    var test by remember { mutableStateOf("") }

    Text("اكتب، تحدث، ترجم... بلغتك وبكل اللغات.", style = MaterialTheme.typography.bodyLarge)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                when {
                    isDefault -> "✅ مفعّلة ومختارة افتراضياً · Active and default"
                    enabled -> "⚠ مفعّلة، اخترها كلوحة افتراضية · Enabled, select it"
                    else -> "⬜ غير مفعّلة · Not enabled"
                }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ ctx.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }) { Text("1) تفعيل · Enable") }
                Button({ imm.showInputMethodPicker() }) { Text("2) اختيار · Select") }
            }
            OutlinedButton({ tick++ }) { Text("تحديث الحالة · Refresh") }
        }
    }
    OutlinedTextField(test, { test = it }, Modifier.fillMaxWidth(), label = { Text("جرّب لسان هنا · Try Lisan here") })
    NavCard("🌍 الترجمة · Translate", "ترجمة نص يدوياً على الجهاز") { go(Screen.TRANSLATE) }
    NavCard("🎨 السمات · Themes", "الألوان والمظهر") { go(Screen.THEMES) }
    NavCard("🈯 اللغات · Languages", "لغات الكيبورد ونماذج الترجمة") { go(Screen.LANGUAGES) }
    NavCard("📋 الحافظة · Clipboard", "إدارة العناصر المحفوظة") { go(Screen.CLIPBOARD) }
    NavCard("⚙ الإعدادات · Settings", "الأبعاد، الصفوف، التصحيح، الصوت") { go(Screen.SETTINGS) }
    NavCard("🔒 الخصوصية · Privacy", "سياسة الخصوصية وحذف البيانات") { go(Screen.PRIVACY) }
    NavCard("✉ تواصل مع المطور · Contact", "الإبلاغ عن مشكلة") { go(Screen.SUPPORT) }
    OutlinedButton({
        val text = "Lisan AI Keyboard – لسان" + if (SHARE_LINK.isNotBlank()) "\n$SHARE_LINK" else ""
        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
        ctx.startActivity(Intent.createChooser(send, null)) // native Android Sharesheet
    }) { Text("↗ مشاركة التطبيق · Share app") }
}

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(value, onChange)
    }
}

@Composable
private fun SliderRow(label: String, value: Int, range: IntRange, onDone: (Int) -> Unit) {
    var local by remember(value) { mutableFloatStateOf(value.toFloat()) }
    Text("$label: ${local.toInt()}")
    Slider(local, { local = it }, valueRange = range.first.toFloat()..range.last.toFloat(), onValueChangeFinished = { onDone(local.toInt()) })
}

@Composable
private fun SettingsScreen(app: LisanApplication, prefs: LisanUserPreferences) {
    val scope = rememberCoroutineScope()
    fun update(f: (LisanUserPreferences) -> LisanUserPreferences) { scope.launch { app.settingsRepository.update(f) } }

    Text("المظهر · Appearance", style = MaterialTheme.typography.titleMedium)
    SliderRow("ارتفاع الأزرار · Key height (dp)", prefs.keyHeightDp, 34..60) { v -> update { it.copy(keyHeightDp = v) } }
    SliderRow("المسافة بين الأزرار · Key gap (dp)", prefs.keySpacingDp.toInt(), 0..10) { v -> update { it.copy(keySpacingDp = v.toFloat()) } }
    SliderRow("استدارة الحواف · Corner radius (dp)", prefs.cornerRadiusDp, 0..24) { v -> update { it.copy(cornerRadiusDp = v) } }
    SliderRow("حجم الأحرف · Letter size (sp)", prefs.letterSizeSp.toInt(), 14..28) { v -> update { it.copy(letterSizeSp = v.toFloat()) } }
    SliderRow("ارتفاع شريط الأدوات · Toolbar height (dp)", prefs.toolbarHeightDp, 28..56) { v -> update { it.copy(toolbarHeightDp = v) } }

    Text("الصفوف · Rows", style = MaterialTheme.typography.titleMedium)
    SwitchRow("شريط الأدوات · Toolbar", prefs.showToolbarRow) { v -> update { it.copy(showToolbarRow = v) } }
    SwitchRow("صف الأرقام · Number row", prefs.showNumberRow) { v -> update { it.copy(showNumberRow = v) } }
    SwitchRow("صف الاقتراحات · Suggestions row", prefs.showSuggestionsRow) { v -> update { it.copy(showSuggestionsRow = v) } }
    SwitchRow("صف الحركات · Arabic harakat row", prefs.showArabicHarakatRow) { v -> update { it.copy(showArabicHarakatRow = v) } }

    Text("الكتابة · Typing", style = MaterialTheme.typography.titleMedium)
    SwitchRow("التنبؤ بالكلمات · Predictions", prefs.enablePredictions) { v -> update { it.copy(enablePredictions = v) } }
    SwitchRow("الاحتفاظ بالتشكيل · Preserve diacritics", prefs.preserveArabicDiacritics) { v -> update { it.copy(preserveArabicDiacritics = v) } }
    SliderRow("التصحيح التلقائي (0 = إيقاف) · Autocorrect level", prefs.autocorrectLevel, 0..3) { v -> update { it.copy(autocorrectLevel = v) } }
    SliderRow("الاهتزاز (0 = إيقاف) · Haptics ms", prefs.hapticFeedbackMs, 0..30) { v -> update { it.copy(hapticFeedbackMs = v) } }

    Text("الصوت · Voice", style = MaterialTheme.typography.titleMedium)
    var vl by remember(prefs.voiceLanguage) { mutableStateOf(prefs.voiceLanguage) }
    OutlinedTextField(vl, { vl = it; update { p -> p.copy(voiceLanguage = it.trim().ifEmpty { "auto" }) } }, Modifier.fillMaxWidth(),
        singleLine = true, label = { Text("لغة التعرف (ar-SA, en-US, auto) · Recognition language") })

    OutlinedButton({ scope.launch { app.settingsRepository.resetDefaults() } }) { Text("استعادة الافتراضي · Reset defaults") }
}

@Composable
private fun ThemesScreen(app: LisanApplication, prefs: LisanUserPreferences) {
    val scope = rememberCoroutineScope()
    ThemeGallery.signatureModels.forEach { t ->
        val selected = prefs.activeThemeId == t.id
        Card(Modifier.fillMaxWidth().clickable { scope.launch { app.settingsRepository.update { it.copy(activeThemeId = t.id) } } }) {
            Column(Modifier.padding(12.dp)) {
                Text((if (selected) "✅ " else "") + "${t.nameEn} · ${t.nameAr}", style = MaterialTheme.typography.titleMedium)
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(t.backgroundHex, t.keySurfaceHex, t.specialKeySurfaceHex, t.micKeyHex, t.translateKeyHex).forEach { c ->
                        Box(Modifier.size(32.dp).background(Color(c.toInt())))
                    }
                }
            }
        }
    }
}

@Composable
private fun LanguagesScreen(app: LisanApplication, prefs: LisanUserPreferences) {
    val scope = rememberCoroutineScope()
    val engine = app.translationEngine
    Text("لغات الكيبورد · Keyboard languages", style = MaterialTheme.typography.titleMedium)
    Text("العربية والإنجليزية لهما تخطيطان كاملان. اللغات اللاتينية الأخرى تستخدم تخطيط QWERTY.", style = MaterialTheme.typography.bodySmall)
    listOf("ar" to "العربية", "en" to "English", "fr" to "Français", "es" to "Español", "de" to "Deutsch", "tr" to "Türkçe").forEach { (code, name) ->
        val on = code in prefs.enabledKeyboardLanguages
        SwitchRow("$name ($code)", on) { v ->
            scope.launch {
                app.settingsRepository.update { p ->
                    val list = if (v) (p.enabledKeyboardLanguages + code).distinct() else p.enabledKeyboardLanguages - code
                    p.copy(enabledKeyboardLanguages = list.ifEmpty { listOf("ar") })
                }
            }
        }
    }

    Text("نماذج الترجمة (تُنزَّل عند طلبك فقط) · Translation models", style = MaterialTheme.typography.titleMedium)
    var status by remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    var msg by remember { mutableStateOf("") }
    val codes = listOf("ar", "en", "fr", "es", "de", "tr", "it", "ru", "fa", "ur", "hi", "zh", "ja", "ko", "pt")
    LaunchedEffect(Unit) { status = codes.associateWith { engine.isOfflineModelDownloaded(it) } }
    if (msg.isNotEmpty()) Text(msg)
    codes.forEach { code ->
        val installed = status[code] == true
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("${Locale(code).getDisplayName(Locale.getDefault())} ($code)" + if (installed) " ✅" else "", Modifier.weight(1f))
            if (installed && code != "en") TextButton({
                scope.launch { engine.deleteLanguageModel(code); status = codes.associateWith { engine.isOfflineModelDownloaded(it) } }
            }) { Text("حذف") }
            else if (!installed) TextButton({
                scope.launch {
                    msg = "Downloading $code…"
                    msg = engine.downloadLanguageModel(code).fold({ "✔ $code" }, { "✖ ${it.message}" })
                    status = codes.associateWith { engine.isOfflineModelDownloaded(it) }
                }
            }) { Text("تنزيل") }
        }
    }
}

@Composable
private fun TranslateScreen(app: LisanApplication, prefs: LisanUserPreferences) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var src by remember { mutableStateOf("") }
    var out by remember { mutableStateOf("") }
    var target by remember { mutableStateOf(prefs.translationTargetLanguage.ifBlank { Locale.getDefault().language }) }
    var busy by remember { mutableStateOf(false) }
    OutlinedTextField(src, { src = it }, Modifier.fillMaxWidth(), label = { Text("النص · Text") })
    OutlinedTextField(target, { target = it.trim() }, singleLine = true, label = { Text("لغة الهدف (ar, en, fr…) · Target") })
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(enabled = !busy, onClick = {
            if (src.isBlank()) { out = "أدخل نصاً أولاً"; return@Button }
            busy = true
            scope.launch {
                val e = app.translationEngine
                val from = e.detectLanguage(src).getOrDefault("en")
                // Explicit button press = explicit consent to download the needed models.
                val d1 = e.downloadLanguageModel(from); val d2 = e.downloadLanguageModel(target)
                out = if (d1.isFailure || d2.isFailure) "✖ " + (d1.exceptionOrNull() ?: d2.exceptionOrNull())?.message
                else e.translate(src, from, target, false).fold({ it.translatedText }, { "✖ ${it.message}" })
                busy = false
            }
        }) { Text(if (busy) "…" else "ترجم · Translate") }
        TextButton({ src = ""; out = "" }) { Text("مسح") }
    }
    Text(out, style = MaterialTheme.typography.titleMedium)
    Row {
        TextButton({ (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("t", out)) }) { Text("نسخ") }
        TextButton({
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, out) }, null))
        }) { Text("مشاركة") }
    }
}

@Composable
private fun ClipboardScreen(app: LisanApplication) {
    val scope = rememberCoroutineScope()
    val repo = app.clipboardRepository
    var query by remember { mutableStateOf("") }
    val items by remember(query) { if (query.isBlank()) repo.observeItems() else repo.searchItems(query) }
        .collectAsState(initial = emptyList<ClipboardEntryEntity>())
    var editing by remember { mutableStateOf<ClipboardEntryEntity?>(null) }
    var draft by remember { mutableStateOf("") }
    OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("بحث · Search") })
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button({ repo.readCurrentSystemClipOnce()?.let { c -> scope.launch { repo.saveClipExplicitly(c) } } }) { Text("＋ حفظ المنسوخ") }
        OutlinedButton({ scope.launch { repo.clearAll() } }) { Text("مسح الكل") }
    }
    items.forEach { e ->
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                if (editing?.id == e.id) {
                    OutlinedTextField(draft, { draft = it }, Modifier.fillMaxWidth())
                    TextButton({ scope.launch { repo.updateContent(e, draft, e.category) }; editing = null }) { Text("حفظ") }
                } else {
                    Text((if (e.isPinned) "📌 " else "") + e.content)
                    Row {
                        TextButton({ scope.launch { repo.togglePin(e) } }) { Text(if (e.isPinned) "إلغاء التثبيت" else "تثبيت") }
                        TextButton({ editing = e; draft = e.content }) { Text("تعديل") }
                        TextButton({ scope.launch { repo.delete(e.id) } }) { Text("حذف") }
                    }
                }
            }
        }
    }
}

@Composable
private fun PrivacyScreen(app: LisanApplication) {
    val scope = rememberCoroutineScope()
    var done by remember { mutableStateOf(false) }
    Text(
        """
• لا نسجّل ضغطات المفاتيح ولا نخزّن كلمات المرور.
• الحافظة لا تُقرأ في الخلفية؛ تُقرأ فقط عند ضغطك زر الحفظ أو اللصق أو الترجمة.
• الميكروفون يعمل فقط أثناء فتح لوحة الصوت، ولا تُحفظ تسجيلات. التعرف الصوتي تؤديه خدمة الجهاز وقد يستخدم الشبكة.
• الترجمة تتم على الجهاز عبر Google ML Kit، وتنزيل النماذج يحدث فقط عند طلبك.
• لا تُرسل نصوصك إلى أي خادم تابع للتطبيق.
• الصوت والترجمة والحافظة وأدوات الكتابة معطّلة في حقول كلمات المرور.
        """.trimIndent()
    )
    Button({
        scope.launch {
            app.privacyGuard.wipeAllLocalData()
            app.clipboardRepository.clearAll()
            app.settingsRepository.resetDefaults()
            done = true
        }
    }) { Text("حذف كل البيانات المحلية · Delete all local data") }
    if (done) Text("✔ تم الحذف")
}

@Composable
private fun SupportScreen() {
    val ctx = LocalContext.current
    var kind by remember { mutableStateOf("Bug") }
    var desc by remember { mutableStateOf("") }
    var withDevice by remember { mutableStateOf(true) }
    var note by remember { mutableStateOf("") }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("Bug", "Idea", "Voice", "Translate").forEach { k -> FilterChip(kind == k, { kind = k }, { Text(k) }) }
    }
    OutlinedTextField(desc, { desc = it }, Modifier.fillMaxWidth().height(160.dp), label = { Text("صف المشكلة · Describe the problem") })
    SwitchRow("إرفاق إصدار Android وطراز الجهاز", withDevice) { withDevice = it }
    Text("لا تُرفق نصوصك ولا محتوى الحافظة.", style = MaterialTheme.typography.bodySmall)
    val body = buildString {
        appendLine(desc); appendLine(); appendLine("Type: $kind"); appendLine("App: 1.0.0")
        if (withDevice) { appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"); appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}") }
    }
    Button({
        val mail = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
            putExtra(Intent.EXTRA_EMAIL, arrayOf(DEVELOPER_EMAIL)); putExtra(Intent.EXTRA_SUBJECT, "Lisan AI Keyboard – $kind"); putExtra(Intent.EXTRA_TEXT, body)
        }
        try { ctx.startActivity(mail) } catch (e: Exception) {
            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("report", "To: $DEVELOPER_EMAIL\n$body"))
            note = "لا يوجد تطبيق بريد؛ نُسخ التقرير"
        }
    }) { Text("مراسلة المطور · Email developer") }
    OutlinedButton({
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("report", "To: $DEVELOPER_EMAIL\n$body")); note = "✔ نُسخ"
    }) { Text("نسخ التقرير") }
    if (note.isNotEmpty()) Text(note)
}
