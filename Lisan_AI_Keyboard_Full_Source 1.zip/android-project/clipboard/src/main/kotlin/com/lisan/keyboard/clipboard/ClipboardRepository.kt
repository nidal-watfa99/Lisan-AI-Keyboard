package com.lisan.keyboard.clipboard

import android.content.ClipboardManager
import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "clipboard_entries")
data class ClipboardEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val content: String,
    val category: String = "General",
    val isPinned: Boolean = false,
    val createdAtEpochMs: Long = System.currentTimeMillis()
)

@Dao
interface ClipboardDao {
    @Query("SELECT * FROM clipboard_entries ORDER BY isPinned DESC, createdAtEpochMs DESC")
    fun observeAll(): Flow<List<ClipboardEntryEntity>>

    @Query("SELECT * FROM clipboard_entries WHERE content LIKE '%' || :query || '%' ORDER BY isPinned DESC, createdAtEpochMs DESC")
    fun search(query: String): Flow<List<ClipboardEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: ClipboardEntryEntity)

    @Update
    suspend fun update(entry: ClipboardEntryEntity)

    @Query("DELETE FROM clipboard_entries WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM clipboard_entries WHERE isPinned = 0")
    suspend fun clearUnpinned()

    @Query("DELETE FROM clipboard_entries")
    suspend fun clearAll()
}

@Database(entities = [ClipboardEntryEntity::class], version = 1, exportSchema = false)
abstract class ClipboardDatabase : RoomDatabase() {
    abstract fun clipboardDao(): ClipboardDao
}

/**
 * Privacy-first Clipboard Repository:
 * NEVER listens in the background. Reads Android's primary clip only when
 * explicitly requested by the user inside the keyboard or app UI.
 */
class ClipboardRepository(
    private val context: Context,
    private val dao: ClipboardDao
) {
    fun observeItems(): Flow<List<ClipboardEntryEntity>> = dao.observeAll()
    fun searchItems(query: String): Flow<List<ClipboardEntryEntity>> = dao.search(query)

    fun readCurrentSystemClipOnce(): String? {
        val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return null
        val clip = manager.primaryClip ?: return null
        if (clip.itemCount <= 0) return null
        return clip.getItemAt(0).coerceToText(context)?.toString()?.takeIf { it.isNotBlank() }
    }

    suspend fun saveClipExplicitly(text: String, category: String = "General", pinned: Boolean = false) {
        if (text.isBlank()) return
        dao.insert(ClipboardEntryEntity(content = text, category = category, isPinned = pinned))
    }

    suspend fun togglePin(entry: ClipboardEntryEntity) {
        dao.update(entry.copy(isPinned = !entry.isPinned))
    }

    suspend fun updateContent(entry: ClipboardEntryEntity, newText: String, newCategory: String) {
        dao.update(entry.copy(content = newText, category = newCategory))
    }

    suspend fun delete(id: Long) = dao.deleteById(id)
    suspend fun clearAll() = dao.clearAll()
}

/** Single shared Room instance for the whole process (app UI + keyboard service). */
object ClipboardProvider {
    @Volatile private var repo: ClipboardRepository? = null
    fun get(context: Context): ClipboardRepository = repo ?: synchronized(this) {
        repo ?: run {
            val app = context.applicationContext
            val db = Room.databaseBuilder(app, ClipboardDatabase::class.java, "lisan_clipboard.db").build()
            ClipboardRepository(app, db.clipboardDao()).also { repo = it }
        }
    }
}
