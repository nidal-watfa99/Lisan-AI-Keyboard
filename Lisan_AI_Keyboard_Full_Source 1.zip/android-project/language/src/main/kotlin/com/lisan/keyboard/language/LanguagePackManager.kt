package com.lisan.keyboard.language

import com.lisan.keyboard.core.KeyboardLanguage
import com.lisan.keyboard.core.ScriptDirection
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class DownloadStatus {
    NOT_DOWNLOADED,
    DOWNLOADING,
    PAUSED,
    INSTALLED,
    UNAVAILABLE
}

data class LanguagePackInfo(
    val language: KeyboardLanguage,
    val isEnabledOnKeyboard: Boolean,
    val isDefault: Boolean,
    val dictionarySizeMb: Double,
    val translationModelSizeMb: Double,
    val dictionaryStatus: DownloadStatus,
    val translationModelStatus: DownloadStatus,
    val progressPercent: Int = 0
)

class LanguagePackManager {
    private val _packs = MutableStateFlow(
        listOf(
            LanguagePackInfo(KeyboardLanguage.ARABIC, true, true, 14.2, 31.8, DownloadStatus.INSTALLED, DownloadStatus.NOT_DOWNLOADED, 100),
            LanguagePackInfo(KeyboardLanguage.ENGLISH, true, false, 12.6, 28.4, DownloadStatus.INSTALLED, DownloadStatus.INSTALLED, 100),
            LanguagePackInfo(KeyboardLanguage.FRENCH, false, false, 11.4, 29.1, DownloadStatus.NOT_DOWNLOADED, DownloadStatus.NOT_DOWNLOADED),
            LanguagePackInfo(KeyboardLanguage.SPANISH, false, false, 11.9, 29.5, DownloadStatus.NOT_DOWNLOADED, DownloadStatus.NOT_DOWNLOADED),
            LanguagePackInfo(KeyboardLanguage.TURKISH, false, false, 10.8, 27.6, DownloadStatus.NOT_DOWNLOADED, DownloadStatus.NOT_DOWNLOADED),
            LanguagePackInfo(KeyboardLanguage.GERMAN, false, false, 13.1, 30.2, DownloadStatus.NOT_DOWNLOADED, DownloadStatus.NOT_DOWNLOADED)
        )
    )
    val packs: StateFlow<List<LanguagePackInfo>> = _packs.asStateFlow()

    fun toggleKeyboardLanguage(code: String, enabled: Boolean) {
        _packs.value = _packs.value.map {
            if (it.language.code == code) it.copy(isEnabledOnKeyboard = enabled) else it
        }
    }

    fun setDefaultLanguage(code: String) {
        _packs.value = _packs.value.map {
            it.copy(isDefault = it.language.code == code, isEnabledOnKeyboard = it.isEnabledOnKeyboard || it.language.code == code)
        }
    }

    fun search(query: String): List<LanguagePackInfo> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return _packs.value
        return _packs.value.filter {
            it.language.displayNameEn.lowercase().contains(q) ||
                it.language.nativeName.contains(q) ||
                it.language.code.lowercase().contains(q)
        }
    }
}
