package com.lisan.keyboard.core

import kotlinx.coroutines.flow.Flow

/**
 * Platform-agnostic contracts designed for clean reuse across Android (Kotlin)
 * and future iOS (Swift) keyboard extensions.
 */
enum class ScriptDirection { LTR, RTL }

enum class KeyboardLanguage(
    val code: String,
    val displayNameEn: String,
    val nativeName: String,
    val direction: ScriptDirection
) {
    ARABIC("ar", "Arabic", "العربية", ScriptDirection.RTL),
    ENGLISH("en", "English", "English", ScriptDirection.LTR),
    FRENCH("fr", "French", "Français", ScriptDirection.LTR),
    SPANISH("es", "Spanish", "Español", ScriptDirection.LTR),
    TURKISH("tr", "Turkish", "Türkçe", ScriptDirection.LTR),
    GERMAN("de", "German", "Deutsch", ScriptDirection.LTR);

    companion object {
        fun fromCode(code: String): KeyboardLanguage =
            entries.firstOrNull { it.code == code } ?: ENGLISH
    }
}

enum class InputSensitivity {
    NORMAL,
    PASSWORD,
    EMAIL,
    NUMBER,
    URI
}

data class TextFieldContext(
    val packageName: String?,
    val sensitivity: InputSensitivity,
    val languageHint: String?,
    val allowCloudAi: Boolean
)

data class TranslationResult(
    val originalText: String,
    val translatedText: String,
    val sourceLang: String,
    val targetLang: String,
    val providerName: String,
    val isOffline: Boolean
)

interface TranslationServiceContract {
    suspend fun translate(
        text: String,
        sourceLang: String,
        targetLang: String,
        allowCloudFallback: Boolean
    ): Result<TranslationResult>

    suspend fun detectLanguage(text: String): Result<String>
    suspend fun isOfflineModelDownloaded(langCode: String): Boolean
}

sealed interface VoiceRecognitionState {
    data object Idle : VoiceRecognitionState
    data object Listening : VoiceRecognitionState
    data class PartialResult(val text: String) : VoiceRecognitionState
    data class FinalResult(val text: String) : VoiceRecognitionState
    data object Processing : VoiceRecognitionState
    data class Error(val message: String, val recoverable: Boolean = true) : VoiceRecognitionState
}

interface VoiceRecognizerContract {
    val state: Flow<VoiceRecognitionState>
    fun startListening(languageTag: String, preferOffline: Boolean)
    fun stopListening()
    fun cancel()
}
