plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.lisan.keyboard.ime"
    compileSdk = 35
    defaultConfig { minSdk = 26 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(project(":shared-core"))
    implementation(project(":privacy"))
    implementation(project(":settings"))
    implementation(project(":themes"))
    implementation(project(":language"))
    implementation(project(":prediction"))
    implementation(project(":emoji"))
    implementation(project(":clipboard"))
    implementation(project(":voice"))
    implementation(project(":translation"))

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.room.runtime)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.serialization.json)
    testImplementation(libs.junit)
}
