package com.lisan.keyboard.ime

import com.lisan.keyboard.core.KeyboardLanguage

data class KeySpec(
    val primaryLabel: String,
    val outputText: String = primaryLabel,
    val longPressAlternates: List<String> = emptyList(),
    val weight: Float = 1f,
    val isSpecial: Boolean = false
)

object KeyboardLayoutRegistry {

    val arabicHarakatKeys: List<KeySpec> = listOf(
        KeySpec("َ", "َ", listOf("ً")),
        KeySpec("ُ", "ُ", listOf("ٌ")),
        KeySpec("ِ", "ِ", listOf("ٍ")),
        KeySpec("ْ", "ْ"),
        KeySpec("ّ", "ّ", listOf("َّ", "ُّ", "ِّ")),
        KeySpec("ً", "ً"),
        KeySpec("ٌ", "ٌ"),
        KeySpec("ٍ", "ٍ"),
        KeySpec("ـ", "ـ"),
        KeySpec("ٰ", "ٰ")
    )

    val arabicRows: List<List<KeySpec>> = listOf(
        listOf(
            KeySpec("ض"), KeySpec("ص"), KeySpec("ث"), KeySpec("ق"), KeySpec("ف"),
            KeySpec("غ"), KeySpec("ع"), KeySpec("ه", "ه", listOf("ة")), KeySpec("خ"), KeySpec("ح"), KeySpec("ج")
        ),
        listOf(
            KeySpec("ش"), KeySpec("س"), KeySpec("ي", "ي", listOf("ى", "ئ")), KeySpec("ب"), KeySpec("ل", "ل", listOf("لا", "لأ", "لإ", "لآ")),
            KeySpec("ا", "ا", listOf("أ", "إ", "آ", "ء")), KeySpec("ت", "ت", listOf("ة")), KeySpec("ن"), KeySpec("م"), KeySpec("ك"), KeySpec("ط")
        ),
        listOf(
            KeySpec("ذ"), KeySpec("ئ"), KeySpec("ء"), KeySpec("ؤ"), KeySpec("ر"),
            KeySpec("لا"), KeySpec("ى"), KeySpec("ة"), KeySpec("و", "و", listOf("ؤ")), KeySpec("ز"), KeySpec("ظ"), KeySpec("د")
        )
    )

    val englishRows: List<List<KeySpec>> = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p").map { KeySpec(it) },
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l").map { KeySpec(it) },
        listOf("z", "x", "c", "v", "b", "n", "m").map { KeySpec(it) }
    )

    val numberRowArabic: List<KeySpec> = listOf("١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩", "٠").mapIndexed { idx, ar ->
        val latin = ((idx + 1) % 10).toString()
        KeySpec(primaryLabel = latin, outputText = latin, longPressAlternates = listOf(ar))
    }

    val symbolRows: List<List<KeySpec>> = listOf(
        listOf("@", "#", "$", "%", "&", "-", "+", "(", ")", "/").map { KeySpec(it) },
        listOf("*", "\"", "'", ":", ";", "!", "?", "،", "؛", "؟").map { KeySpec(it) },
        listOf("~", "`", "|", "\\", "{", "}", "[", "]", "<", ">").map { KeySpec(it) }
    )

    fun getLetterRows(language: KeyboardLanguage): List<List<KeySpec>> =
        when (language) {
            KeyboardLanguage.ARABIC -> arabicRows
            else -> englishRows
        }
}
