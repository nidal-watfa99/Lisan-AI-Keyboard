package com.lisan.keyboard.ime

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.lisan.keyboard.clipboard.ClipboardEntryEntity
import com.lisan.keyboard.clipboard.ClipboardProvider
import com.lisan.keyboard.core.InputSensitivity
import com.lisan.keyboard.core.KeyboardLanguage
import com.lisan.keyboard.core.VoiceRecognitionState
import com.lisan.keyboard.emoji.EmojiCatalog
import com.lisan.keyboard.emoji.EmojiCategory
import com.lisan.keyboard.prediction.PredictionEngine
import com.lisan.keyboard.privacy.InputSecurityClassifier
import com.lisan.keyboard.settings.LisanUserPreferences
import com.lisan.keyboard.settings.SettingsRepository
import com.lisan.keyboard.themes.KeyboardThemeSpec
import com.lisan.keyboard.themes.ThemeGallery
import com.lisan.keyboard.translation.MlKitTranslationEngine
import com.lisan.keyboard.voice.AndroidVoiceRecognizerAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Lisan AI Keyboard input method. Uses plain Views (not Compose) inside the IME window.
 * Panels (voice, translate, clipboard, emoji, AI tools) replace the key area and never read
 * the clipboard, microphone or network without an explicit tap by the user.
 */
class LisanInputMethodService : InputMethodService(), KeyboardActions {

    private lateinit var settingsRepo: SettingsRepository
    private lateinit var clipboardRepo: com.lisan.keyboard.clipboard.ClipboardRepository
    private val prediction = PredictionEngine()
    private val translator by lazy { MlKitTranslationEngine() }
    private var voice: AndroidVoiceRecognizerAdapter? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var panelJob: Job? = null

    private var prefs = LisanUserPreferences()
    private var language = KeyboardLanguage.ARABIC
    private var shifted = false
    private var symbols = false
    private var sensitive = false
    private var lastCorrection: Pair<String, String>? = null
    private var pendingTranslateSource: String? = null

    private var root: FrameLayout? = null
    private var surface: KeyboardSurface? = null
    private var panel: View? = null

    override fun onCreate() {
        super.onCreate()
        settingsRepo = SettingsRepository(applicationContext)
        clipboardRepo = ClipboardProvider.get(applicationContext)
        language = KeyboardLanguage.fromCode(prefs.enabledKeyboardLanguages.firstOrNull() ?: "ar")
        scope.launch {
            settingsRepo.preferences.collect { p ->
                prefs = p
                if (language.code !in enabledCodes()) language = KeyboardLanguage.fromCode(enabledCodes().first())
                refresh()
            }
        }
    }

    override fun onDestroy() {
        voice?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val frame = FrameLayout(this)
        val s = KeyboardSurface(this)
        frame.addView(s, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        root = frame; surface = s
        refresh()
        return frame
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val ctx = InputSecurityClassifier.classify(info)
        sensitive = ctx.sensitivity == InputSensitivity.PASSWORD
        symbols = ctx.sensitivity == InputSensitivity.NUMBER
        lastCorrection = null
        closePanel()
        updateAutoCaps()
        refresh()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        closePanel()
        super.onFinishInputView(finishingInput)
    }

    // ------------------------------------------------------------------ rendering

    private fun enabledCodes(): List<String> = prefs.enabledKeyboardLanguages.ifEmpty { listOf("ar", "en") }

    private fun theme(): KeyboardThemeSpec =
        ThemeGallery.signatureModels.firstOrNull { it.id == prefs.activeThemeId } ?: ThemeGallery.signatureModels.first()

    private fun currentWordAndPrev(): Pair<String, String?> {
        val before = currentInputConnection?.getTextBeforeCursor(60, 0)?.toString().orEmpty()
        val tokens = before.split(Regex("\\s+"))
        fun clean(w: String) = w.filter { it.isLetter() || com.lisan.keyboard.ime.ArabicShapingHelper.isHarakat(it) }
        val last = if (before.isNotEmpty() && !before.last().isWhitespace()) clean(tokens.last()) else ""
        val prev = if (last.isNotEmpty()) tokens.getOrNull(tokens.size - 2) else tokens.lastOrNull { it.isNotBlank() }
        return last to prev?.let(::clean)
    }

    private fun refresh() {
        val s = surface ?: return
        val (word, prev) = currentWordAndPrev()
        val suggestions = if (prefs.enablePredictions && !sensitive)
            prediction.suggest(word, prev, language.code, 3) else emptyList()
        s.render(prefs, theme(), SurfaceState(language, shifted, symbols, sensitive, suggestions), this)
    }

    private fun updateAutoCaps() {
        val info = currentInputEditorInfo ?: return
        if (info.inputType and InputType.TYPE_MASK_CLASS != InputType.TYPE_CLASS_TEXT) { shifted = false; return }
        shifted = language != KeyboardLanguage.ARABIC &&
            (currentInputConnection?.getCursorCapsMode(info.inputType) ?: 0) != 0
    }

    // ------------------------------------------------------------------ KeyboardActions

    override fun onText(text: String) {
        if (text == " ") { commitSpace(); return }
        val ic = currentInputConnection ?: return
        lastCorrection = null
        ic.commitText(text, 1)
        if (shifted) shifted = false
        if (text == "." || text == "!" || text == "?") updateAutoCaps()
        refresh()
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        val lc = lastCorrection
        if (lc != null) {
            val before = ic.getTextBeforeCursor(lc.second.length + 1, 0)?.toString().orEmpty()
            if (before == lc.second + " ") {
                ic.deleteSurroundingText(before.length, 0)
                ic.commitText(lc.first, 1)
                lastCorrection = null
                refresh(); return
            }
        }
        lastCorrection = null
        if (!ic.getSelectedText(0).isNullOrEmpty()) ic.commitText("", 1)
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        refresh()
    }

    override fun onEnter() {
        val ei = currentInputEditorInfo
        val action = ei?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        val noEnterAction = ei != null && (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        lastCorrection = null
        updateAutoCaps(); refresh()
    }

    override fun onShift() { shifted = !shifted; refresh() }

    override fun onSwitchLanguage() {
        val codes = enabledCodes()
        language = KeyboardLanguage.fromCode(codes[(codes.indexOf(language.code) + 1) % codes.size])
        symbols = false
        updateAutoCaps(); refresh()
    }

    override fun onToggleSymbols() { symbols = !symbols; refresh() }

    override fun onMoveCursor(delta: Int) {
        sendDownUpKeyEvents(if (delta < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT)
        refresh()
    }

    override fun onSuggestion(word: String) {
        val ic = currentInputConnection ?: return
        val (current, _) = currentWordAndPrev()
        if (current.isNotEmpty()) ic.deleteSurroundingText(current.length, 0)
        ic.commitText("$word ", 1)
        lastCorrection = null
        refresh()
    }

    /** Space: optional, user-controlled autocorrect (off by default) that can be undone with backspace. */
    private fun commitSpace() {
        val ic = currentInputConnection ?: return
        if (prefs.autocorrectLevel > 0 && !sensitive) {
            val (word, _) = currentWordAndPrev()
            val fix = if (word.isNotEmpty()) prediction.autocorrectCandidate(word, language.code, prefs.autocorrectLevel) else null
            if (fix != null && fix != word) {
                ic.deleteSurroundingText(word.length, 0)
                ic.commitText("$fix ", 1)
                lastCorrection = word to fix
                refresh(); return
            }
        }
        ic.commitText(" ", 1)
        lastCorrection = null
        refresh()
    }

    override fun onTool(tool: String) {
        when (tool) {
            "left" -> onMoveCursor(-1)
            "right" -> onMoveCursor(1)
            "voice" -> showVoice(translateAfter = false)
            "translate" -> if (blockSensitive()) Unit else showTranslate()
            "clipboard" -> if (blockSensitive()) Unit else showClipboard()
            "emoji" -> showEmoji()
            "ai" -> if (blockSensitive()) Unit else showAiTools()
            "harakat" -> scope.launch { settingsRepo.update { it.copy(showArabicHarakatRow = !it.showArabicHarakatRow) } }
            "settings" -> startActivity(
                Intent().setClassName(packageName, "com.lisan.keyboard.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private fun blockSensitive(): Boolean {
        if (sensitive) toast(if (language == KeyboardLanguage.ARABIC) "غير متاح في حقول كلمات المرور" else "Disabled in password fields")
        return sensitive
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun isAr() = language == KeyboardLanguage.ARABIC
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ panels

    private fun closePanel() {
        panelJob?.cancel(); panelJob = null
        voice?.cancel()
        panel?.let { root?.removeView(it) }
        panel = null
        surface?.visibility = View.VISIBLE
        currentInputConnection?.finishComposingText()
    }

    private fun openPanel(title: String, content: View) {
        val r = root ?: return
        closePanel()
        val t = theme()
        val h = (surface?.height ?: 0).takeIf { it > dp(200) } ?: dp(300)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(t.backgroundHex.toInt())
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = title; textSize = 15f; setTextColor(t.keyTextHex.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        header.addView(TextView(this).apply {
            text = "✕"; textSize = 20f; setTextColor(t.keyTextHex.toInt()); setPadding(dp(14), dp(6), dp(14), dp(6))
            contentDescription = "Close"; setOnClickListener { closePanel(); refresh() }
        })
        box.addView(header)
        box.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        surface?.visibility = View.INVISIBLE
        r.addView(box, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, h))
        panel = box
    }

    private fun button(label: String, accent: Boolean = false, onClick: () -> Unit): TextView {
        val t = theme()
        return TextView(this).apply {
            text = label; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(if (accent) Color.WHITE else t.keyTextHex.toInt())
            background = GradientDrawable().apply {
                setColor(if (accent) t.micKeyHex.toInt() else t.specialKeySurfaceHex.toInt()); cornerRadius = dp(10).toFloat()
            }
            setPadding(dp(12), dp(8), dp(12), dp(8))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun label(text: String, sizeSp: Float = 15f, color: Int = theme().keyTextHex.toInt()) = TextView(this).apply {
        this.text = text; textSize = sizeSp; setTextColor(color); setPadding(dp(4), dp(4), dp(4), dp(4))
    }

    private fun buttonRow(vararg views: View): View {
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        views.forEach { row.addView(it) }
        scroll.addView(row)
        return scroll
    }

    // ------------------------------------------------------------------ voice

    private fun showVoice(translateAfter: Boolean) {
        if (blockSensitive()) return
        val adapter = voice ?: AndroidVoiceRecognizerAdapter(this).also { voice = it }
        if (!adapter.hasRecordAudioPermission()) {
            // An IME cannot show the runtime permission dialog; a transparent activity does it.
            startActivity(Intent().setClassName(packageName, "com.lisan.keyboard.MicPermissionActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            toast(if (isAr()) "امنح إذن الميكروفون ثم اضغط الميكروفون مرة أخرى" else "Grant microphone permission, then tap the mic again")
            return
        }
        val t = theme()
        val status = label(if (isAr()) "اضغط الميكروفون وتحدث" else "Tap the mic and speak", 16f, t.keyTextHex.toInt()).apply { gravity = Gravity.CENTER }
        val langInfo = label("${prefs.voiceLanguage}  →  ${if (translateAfter) targetLang() else (if (isAr()) "كتابة" else "typing")}", 12f, t.symbolTextHex.toInt()).apply { gravity = Gravity.CENTER }
        var continuous = true
        var listening = false

        fun start() {
            continuous = true; listening = true
            adapter.startListening(prefs.voiceLanguage, preferOffline = false)
        }
        val mic = button("🎤", accent = true) { start() }
        val stop = button("⏹") { continuous = false; listening = false; adapter.stopListening(); status.text = if (isAr()) "متوقف مؤقتاً" else "Paused" }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            addView(status); addView(langInfo)
            addView(buttonRow(mic, stop))
        }
        openPanel(if (translateAfter) "🎤 → 🌍" else "🎤", content)

        panelJob = scope.launch {
            adapter.state.drop(1).collect { st ->
                val ic = currentInputConnection
                when (st) {
                    is VoiceRecognitionState.Listening -> status.text = if (isAr()) "🎙 أستمع..." else "🎙 Listening..."
                    is VoiceRecognitionState.Processing -> status.text = if (isAr()) "جارٍ المعالجة..." else "Processing..."
                    is VoiceRecognitionState.PartialResult -> {
                        // Live text appears directly in the target field as composing text.
                        if (!translateAfter) ic?.setComposingText(st.text, 1) else status.text = st.text
                    }
                    is VoiceRecognitionState.FinalResult -> {
                        if (translateAfter) {
                            status.text = st.text
                            translateAndInsert(st.text, status)
                        } else {
                            ic?.commitText(st.text + " ", 1)
                            status.text = "✔ " + st.text
                        }
                        refresh0()
                        if (continuous && listening) adapter.startListening(prefs.voiceLanguage, false)
                    }
                    is VoiceRecognitionState.Error -> {
                        ic?.finishComposingText()
                        listening = false
                        status.text = voiceErrorText(st.message)
                    }
                    is VoiceRecognitionState.Idle -> Unit
                }
            }
        }
        start()
    }

    private fun refresh0() { /* keep panel open; suggestions recomputed on close */ }

    private fun voiceErrorText(message: String): String = when {
        message.contains("permission", true) -> if (isAr()) "إذن الميكروفون مطلوب" else "Microphone permission required"
        message.contains("No speech", true) -> if (isAr()) "لم أسمع شيئاً، اضغط الميكروفون" else "Didn't catch that. Tap the mic."
        message.contains("Network", true) -> if (isAr()) "لا يوجد اتصال. جرّب حزمة التعرف دون اتصال من إعدادات النظام." else "No connection. Try an offline speech pack in system settings."
        else -> message
    }

    // ------------------------------------------------------------------ translation

    private val translateTargets = listOf("ar", "en", "fr", "es", "de", "tr", "it", "ru", "fa", "ur", "hi", "zh", "ja", "ko", "pt")

    private fun targetLang(): String =
        prefs.translationTargetLanguage.ifBlank { Locale.getDefault().language }.takeIf { it in translateTargets } ?: "en"

    private fun fieldText(): String {
        val ic = currentInputConnection ?: return ""
        val sel = ic.getSelectedText(0)?.toString()
        if (!sel.isNullOrEmpty()) return sel
        return (ic.getTextBeforeCursor(2000, 0)?.toString().orEmpty() + ic.getTextAfterCursor(2000, 0)?.toString().orEmpty()).trim()
    }

    private fun readClipboardOnce(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        return clip.getItemAt(0).coerceToText(this)?.toString()?.takeIf { it.isNotBlank() }
    }

    private fun insertReplacingSelection(text: String) {
        currentInputConnection?.commitText(text, 1)
    }

    private fun translateAndInsert(text: String, status: TextView) {
        scope.launch {
            val r = translator.translate(text, "auto", targetLang(), allowCloudFallback = false)
            r.onSuccess { insertReplacingSelection(it.translatedText + " "); status.text = it.translatedText }
            r.onFailure { status.text = if (isAr()) "النموذج غير منزّل. افتح الترجمة واضغط تنزيل." else "Model not downloaded. Open Translate and tap Download." }
        }
    }

    private fun showTranslate() {
        val t = theme()
        var target = targetLang()
        var source = pendingTranslateSource ?: ""
        pendingTranslateSource = null
        var result = ""

        val sourceView = label(source.ifEmpty { if (isAr()) "اختر مصدر النص بالأزرار أدناه" else "Pick a text source below" }, 14f, t.symbolTextHex.toInt())
        val resultView = label("", 17f, t.translateKeyHex.toInt())
        val statusView = label("", 12f, t.symbolTextHex.toInt())
        val targetBtn = button("→ $target") { }
        val dl = button(if (isAr()) "⬇ تنزيل النماذج" else "⬇ Download models") { }
        dl.visibility = View.GONE

        fun setSource(s: String) { source = s; sourceView.text = s.ifEmpty { "—" }; resultView.text = ""; result = "" }

        fun doTranslate(allowDownload: Boolean) {
            if (source.isBlank()) { statusView.text = if (isAr()) "أدخل نصاً أولاً" else "Enter text first"; return }
            statusView.text = "…"; dl.visibility = View.GONE
            scope.launch {
                val src = translator.detectLanguage(source).getOrDefault("en")
                if (src == target) { statusView.text = if (isAr()) "اللغة المصدر هي نفسها لغة الهدف" else "Source and target are the same"; return@launch }
                if (allowDownload) {
                    statusView.text = if (isAr()) "جارٍ التنزيل..." else "Downloading..."
                    val a = translator.downloadLanguageModel(src); val b = translator.downloadLanguageModel(target)
                    if (a.isFailure || b.isFailure) { statusView.text = (a.exceptionOrNull() ?: b.exceptionOrNull())?.message ?: "Download failed"; dl.visibility = View.VISIBLE; return@launch }
                }
                val r = translator.translate(source, src, target, allowCloudFallback = false)
                r.onSuccess { result = it.translatedText; resultView.text = result; statusView.text = "$src → $target" }
                r.onFailure {
                    statusView.text = if (isAr()) "نموذج الترجمة غير منزّل ($src → $target)" else "Translation model not downloaded ($src → $target)"
                    dl.visibility = View.VISIBLE
                }
            }
        }
        dl.setOnClickListener { doTranslate(true) }
        targetBtn.setOnClickListener {
            target = translateTargets[(translateTargets.indexOf(target) + 1) % translateTargets.size]
            targetBtn.text = "→ $target"
            scope.launch { settingsRepo.update { it.copy(translationTargetLanguage = target) } }
            resultView.text = ""; result = ""
        }
        val fromField = button(if (isAr()) "من الحقل" else "From field") { setSource(fieldText()) }
        val fromClip = button(if (isAr()) "📋 من الحافظة" else "📋 Clipboard") { setSource(readClipboardOnce().orEmpty()) }
        val fromVoice = button("🎤") { showVoice(translateAfter = true) }
        val go = button(if (isAr()) "ترجم" else "Translate", accent = true) { doTranslate(false) }
        val insert = button(if (isAr()) "إدراج" else "Insert") { if (result.isNotEmpty()) { insertReplacingSelection(result); toast("✔") } }
        val copy = button(if (isAr()) "نسخ" else "Copy") {
            if (result.isNotEmpty()) {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("translation", result)); toast("✔")
            }
        }
        val swap = button("⇄") {
            if (result.isNotEmpty()) { val tmp = result; setSource(tmp); statusView.text = "" }
        }

        val scroll = ScrollView(this).apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(buttonRow(fromField, fromClip, fromVoice))
                addView(sourceView)
                addView(buttonRow(targetBtn, go, dl))
                addView(resultView)
                addView(statusView)
                addView(buttonRow(insert, copy, swap))
            })
        }
        openPanel(if (isAr()) "🌍 الترجمة" else "🌍 Translate", scroll)
    }

    // ------------------------------------------------------------------ clipboard

    private fun showClipboard() {
        val t = theme()
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = buttonRow(
            button(if (isAr()) "＋ حفظ المنسوخ" else "＋ Save clip") {
                val c = readClipboardOnce()
                if (c == null) toast(if (isAr()) "لا يوجد نص منسوخ" else "Clipboard is empty")
                else scope.launch { clipboardRepo.saveClipExplicitly(c) }
            },
            button(if (isAr()) "🗑 مسح الكل" else "🗑 Clear all") { scope.launch { clipboardRepo.clearAll() } }
        )
        val scroll = ScrollView(this).apply { addView(list) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(top); addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)) }
        openPanel(if (isAr()) "📋 الحافظة" else "📋 Clipboard", box)
        panelJob = scope.launch {
            clipboardRepo.observeItems().collect { items ->
                list.removeAllViews()
                if (items.isEmpty()) list.addView(label(if (isAr()) "لا عناصر. انسخ نصاً ثم اضغط «حفظ المنسوخ»." else "No items. Copy text, then tap “Save clip”.", 13f, t.symbolTextHex.toInt()))
                items.forEach { e -> list.addView(clipRow(e)) }
            }
        }
    }

    private fun clipRow(e: ClipboardEntryEntity): View {
        val t = theme()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply {
            text = (if (e.isPinned) "📌 " else "") + e.content.take(120); textSize = 14f; maxLines = 2
            setTextColor(t.keyTextHex.toInt()); setPadding(dp(6), dp(10), dp(6), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { currentInputConnection?.commitText(e.content, 1) }
            setOnLongClickListener { scope.launch { clipboardRepo.togglePin(e) }; true }
        })
        row.addView(label("🌍", 16f).apply { setOnClickListener { pendingTranslateSource = e.content; showTranslate() } })
        row.addView(label("✕", 16f).apply { setOnClickListener { scope.launch { clipboardRepo.delete(e.id) } } })
        return row
    }

    // ------------------------------------------------------------------ emoji

    private val emojiPrefs by lazy { getSharedPreferences("lisan_ime_state", Context.MODE_PRIVATE) }
    private val flagCountries = listOf("SA","AE","EG","SY","PS","JO","IQ","LB","KW","QA","BH","OM","YE","SD","LY","TN","DZ","MA","TR","US","GB","FR","DE","ES","IT","RU","CN","JP","KR","IN","PK","BR","CA","AU")

    private fun flag(cc: String): String = String(cc.flatMap { listOf(0x1F1E6 + (it - 'A')) }.flatMap { Character.toChars(it).toList() }.toCharArray())

    private fun emojiForCategory(cat: EmojiCategory, paint: Paint): List<String> {
        fun range(vararg r: IntRange) = r.flatMap { it.toList() }.map { String(Character.toChars(it)) }
        val raw: List<String> = when (cat) {
            EmojiCategory.RECENT -> (emojiPrefs.getString("recent", "") ?: "").split("|").filter { it.isNotEmpty() }
            EmojiCategory.FAVORITES -> (emojiPrefs.getString("fav", "") ?: "").split("|").filter { it.isNotEmpty() }
            EmojiCategory.SMILEYS -> range(0x1F600..0x1F64F, 0x1F910..0x1F92F, 0x1F44B..0x1F450, 0x1F64F..0x1F64F)
            EmojiCategory.ANIMALS -> range(0x1F400..0x1F43F, 0x1F980..0x1F9AE)
            EmojiCategory.FOOD -> range(0x1F345..0x1F37F, 0x1F950..0x1F96B, 0x2615..0x2615)
            EmojiCategory.NATURE -> range(0x1F300..0x1F344, 0x1F330..0x1F344, 0x1F4A7..0x1F4A7)
            EmojiCategory.TRAVEL -> range(0x1F680..0x1F6C5, 0x1F3E0..0x1F3F0)
            EmojiCategory.ACTIVITIES -> range(0x26BD..0x26BE, 0x1F3A0..0x1F3CA, 0x1F3CF..0x1F3D3)
            EmojiCategory.OBJECTS -> range(0x1F4A1..0x1F4FF, 0x1F50A..0x1F52B)
            EmojiCategory.SYMBOLS -> range(0x2764..0x2764, 0x1F493..0x1F49F, 0x2600..0x2610, 0x2705..0x2705, 0x2728..0x2728, 0x274C..0x274C)
            EmojiCategory.FLAGS -> flagCountries.map(::flag)
        }
        return (raw + (if (cat == EmojiCategory.SMILEYS || cat == EmojiCategory.SYMBOLS || cat == EmojiCategory.FLAGS)
            EmojiCatalog.items.filter { it.category == cat }.map { it.glyph } else emptyList()))
            .distinct().filter { cat == EmojiCategory.RECENT || cat == EmojiCategory.FAVORITES || paint.hasGlyph(it) }
    }

    private fun showEmoji() {
        val t = theme()
        val paint = Paint()
        val grid = GridLayout(this).apply { columnCount = 8 }
        val scroll = ScrollView(this).apply { addView(grid) }
        var tone = 0
        fun withTone(e: String): String {
            val cp = e.codePointAt(0)
            val capable = cp in 0x1F44A..0x1F450 || cp in 0x1F466..0x1F478 || cp in 0x1F64B..0x1F64F || cp == 0x1F4AA || cp == 0x1F590
            return if (tone > 0 && capable && e.codePointCount(0, e.length) == 1) e + EmojiCatalog.skinToneModifiers[tone] else e
        }
        fun remember(key: String, e: String, max: Int) {
            val cur = (emojiPrefs.getString(key, "") ?: "").split("|").filter { it.isNotEmpty() && it != e }
            emojiPrefs.edit().putString(key, (listOf(e) + cur).take(max).joinToString("|")).apply()
        }
        fun fill(cat: EmojiCategory) {
            grid.removeAllViews()
            val items = emojiForCategory(cat, paint)
            if (items.isEmpty()) grid.addView(label(if (isAr()) "فارغ" else "Empty", 13f, t.symbolTextHex.toInt()))
            items.forEach { e ->
                grid.addView(TextView(this).apply {
                    text = e; textSize = 24f; gravity = Gravity.CENTER; setPadding(dp(4), dp(8), dp(4), dp(8))
                    layoutParams = GridLayout.LayoutParams().apply { width = (resources.displayMetrics.widthPixels - dp(20)) / 8; height = GridLayout.LayoutParams.WRAP_CONTENT }
                    setOnClickListener { val out = withTone(e); currentInputConnection?.commitText(out, 1); remember("recent", out, 32) }
                    setOnLongClickListener { remember("fav", e, 64); toast("★"); true }
                })
            }
        }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val icons = mapOf(EmojiCategory.RECENT to "🕘", EmojiCategory.FAVORITES to "★", EmojiCategory.SMILEYS to "😀", EmojiCategory.ANIMALS to "🐱", EmojiCategory.FOOD to "🍔",
            EmojiCategory.NATURE to "🌿", EmojiCategory.TRAVEL to "🚗", EmojiCategory.ACTIVITIES to "⚽", EmojiCategory.OBJECTS to "💡", EmojiCategory.SYMBOLS to "❤", EmojiCategory.FLAGS to "🏳")
        EmojiCategory.values().forEach { c -> tabs.addView(button(icons[c] ?: c.titleEn) { fill(c) }) }
        tabs.addView(button("✋") { tone = (tone + 1) % EmojiCatalog.skinToneModifiers.size; toast(if (tone == 0) "—" else "✋" + EmojiCatalog.skinToneModifiers[tone]) })
        tabs.addView(button("⌫") { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) })
        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(tabs) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(tabScroll); addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)) }
        openPanel("😊", box)
        fill(if ((emojiPrefs.getString("recent", "") ?: "").isNotEmpty()) EmojiCategory.RECENT else EmojiCategory.SMILEYS)
    }

    // ------------------------------------------------------------------ AI writing tools (local, no network)

    private fun showAiTools() {
        val t = theme()
        val note = label(
            if (isAr()) "أدوات محلية تعمل على النص المحدد أو كامل الحقل. لا يُرسَل أي نص إلى الإنترنت."
            else "Local tools on the selected text or the whole field. Nothing is sent online.", 12f, t.symbolTextHex.toInt()
        )
        fun applyTool(f: (String) -> String) {
            val ic = currentInputConnection ?: return
            val sel = ic.getSelectedText(0)?.toString()
            if (!sel.isNullOrEmpty()) { ic.commitText(f(sel), 1); return }
            val before = ic.getTextBeforeCursor(5000, 0)?.toString().orEmpty()
            val after = ic.getTextAfterCursor(5000, 0)?.toString().orEmpty()
            if (before.isEmpty() && after.isEmpty()) { toast(if (isAr()) "لا يوجد نص" else "No text"); return }
            ic.deleteSurroundingText(before.length, after.length)
            ic.commitText(f(before + after), 1)
        }
        val tools = listOf(
            (if (isAr()) "إزالة المسافات الزائدة" else "Trim extra spaces") to { s: String -> s.trim().replace(Regex("\\s+"), " ") },
            (if (isAr()) "إزالة التشكيل" else "Remove diacritics") to { s: String -> s.filterNot { ArabicShapingHelper.isHarakat(it) && it != 'ـ' }.replace("ـ", "") },
            (if (isAr()) "أرقام هندية ٠١٢" else "Eastern digits ٠١٢") to { s: String -> ArabicShapingHelper.toEasternArabicNumerals(s) },
            (if (isAr()) "أرقام لاتينية 012" else "Latin digits 012") to { s: String -> s.map { c -> if (c in '٠'..'٩') ('0' + (c - '٠')) else c }.joinToString("") },
            (if (isAr()) "بداية الجمل كبيرة" else "Capitalize sentences") to { s: String -> s.split(Regex("(?<=[.!?؟])\\s+")).joinToString(" ") { x -> x.replaceFirstChar { it.uppercase() } } },
            "UPPERCASE" to { s: String -> s.uppercase() },
            "lowercase" to { s: String -> s.lowercase() }
        )
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(note) }
        tools.forEach { (name, fn) -> col.addView(button(name) { applyTool(fn) }) }
        openPanel("✨", ScrollView(this).apply { addView(col) })
    }
}
