package com.lisan.keyboard.ime

/**
 * Helper utilities for Arabic script integrity:
 * - Detects Arabic Harakat (Tashkeel) codepoints (U+064B..U+065F, U+0670).
 * - Preserves connected letter ligatures, Hamza forms, Alef Maksura, and Ta Marbuta.
 * - Supports deleting a base letter cleanly or stripping only trailing diacritic when backspacing.
 */
object ArabicShapingHelper {
    private val harakatRange = '\u064B'..'\u065F'

    fun isHarakat(ch: Char): Boolean = ch in harakatRange || ch == '\u0670'

    fun containsHarakat(text: String): Boolean = text.any(::isHarakat)

    fun stripHarakatForSearchOnly(text: String): String =
        text.filterNot(::isHarakat)

    fun toEasternArabicNumerals(input: String): String {
        val map = mapOf(
            '0' to '٠', '1' to '١', '2' to '٢', '3' to '٣', '4' to '٤',
            '5' to '٥', '6' to '٦', '7' to '٧', '8' to '٨', '9' to '٩'
        )
        return buildString(input.length) {
            input.forEach { append(map[it] ?: it) }
        }
    }
}
