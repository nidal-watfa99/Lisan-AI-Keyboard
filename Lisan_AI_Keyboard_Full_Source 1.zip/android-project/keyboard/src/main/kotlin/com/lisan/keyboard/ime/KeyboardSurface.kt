package com.lisan.keyboard.ime

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import com.lisan.keyboard.core.KeyboardLanguage
import com.lisan.keyboard.settings.LisanUserPreferences
import com.lisan.keyboard.themes.KeyboardThemeSpec

/** Callbacks from the keyboard surface to the input method service. */
interface KeyboardActions {
    fun onText(text: String)
    fun onBackspace()
    fun onEnter()
    fun onShift()
    fun onSwitchLanguage()
    fun onToggleSymbols()
    fun onMoveCursor(delta: Int)
    fun onTool(tool: String)
    fun onSuggestion(word: String)
}

data class SurfaceState(
    val language: KeyboardLanguage,
    val shifted: Boolean,
    val symbols: Boolean,
    val sensitive: Boolean,
    val suggestions: List<String>
)

/**
 * Plain Android View keyboard (no Compose inside the IME window: a ComposeView inside an
 * InputMethodService crashes without lifecycle owners). Every setting is applied on render().
 */
class KeyboardSurface(context: Context) : LinearLayout(context) {
    private val density = context.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())
    private fun dp(v: Float) = (v * density).toInt()
    private fun dp(v: Int) = (v * density).toInt()
    private fun argb(v: Long) = v.toInt()

    init { orientation = VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }

    fun render(p: LisanUserPreferences, t: KeyboardThemeSpec, s: SurfaceState, a: KeyboardActions) {
        removeAllViews()
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(argb(t.backgroundHex), argb(t.backgroundGradientEndHex ?: t.backgroundHex))
        )
        background = bg
        alpha = 1f
        setPadding(dp(3), dp(3), dp(3), dp(4))
        val keyH = dp(p.keyHeightDp)
        val gap = dp(p.keySpacingDp)
        val radius = dp(p.cornerRadiusDp).toFloat()
        val isAr = s.language == KeyboardLanguage.ARABIC

        if (p.showToolbarRow) addView(toolbar(p, t, s, a, dp(p.toolbarHeightDp)))
        if (p.showSuggestionsRow && p.enablePredictions && !s.sensitive && s.suggestions.isNotEmpty())
            addView(suggestionRow(t, s, a, dp(34)))
        if (p.showArabicHarakatRow && isAr && !s.symbols)
            addView(keyRow(KeyboardLayoutRegistry.arabicHarakatKeys, p, t, s, a, dp(36), gap, radius, harakat = true))
        if (p.showNumberRow) addView(keyRow(KeyboardLayoutRegistry.numberRowArabic, p, t, s, a, keyH, gap, radius, numbers = true))

        val rows = if (s.symbols) KeyboardLayoutRegistry.symbolRows else KeyboardLayoutRegistry.getLetterRows(s.language)
        rows.forEachIndexed { index, row ->
            val line = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER }
            // Shift key (Latin layouts only) sits at the start of the last letter row.
            if (index == rows.lastIndex && !isAr && !s.symbols) {
                line.addView(special(if (s.shifted) "⬆" else "⇧", t, keyH, gap, radius, 1.4f) { a.onShift() })
            }
            row.forEach { key -> line.addView(letterKey(key, p, t, s, a, keyH, gap, radius)) }
            addView(line)
        }

        val bottom = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER }
        bottom.addView(special(if (s.symbols) (if (isAr) "أبج" else "ABC") else "?123", t, keyH, gap, radius, 1.3f) { a.onToggleSymbols() })
        bottom.addView(special("🌐", t, keyH, gap, radius, 1f) { a.onSwitchLanguage() })
        bottom.addView(plain(if (isAr) "،" else ",", t, keyH, gap, radius, 0.9f) { a.onText(if (isAr) "،" else ",") })
        bottom.addView(spaceKey(s, t, keyH, gap, radius, p) { a.onText(" ") })
        bottom.addView(plain(".", t, keyH, gap, radius, 0.9f) { a.onText(".") })
        bottom.addView(backspaceKey(t, keyH, gap, radius, a))
        bottom.addView(enterKey(t, keyH, gap, radius, a))
        addView(bottom)
    }

    // ---------- toolbar ----------
    private fun toolbar(p: LisanUserPreferences, t: KeyboardThemeSpec, s: SurfaceState, a: KeyboardActions, h: Int): View {
        val row = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun tool(label: String, id: String, color: Int, desc: String) = TextView(context).apply {
            text = label; textSize = 17f; gravity = Gravity.CENTER; setTextColor(color)
            contentDescription = desc
            layoutParams = LinearLayout.LayoutParams(0, h, 1f)
            setOnClickListener { a.onTool(id) }
        }
        val text = argb(t.keyTextHex)
        p.toolbarOrder.forEach { id ->
            when (id) {
                "voice" -> row.addView(tool("🎤", "voice", argb(t.micKeyHex).takeIf { !s.sensitive } ?: text, "Voice"))
                "translate" -> row.addView(tool("🌍", "translate", argb(t.translateKeyHex), "Translate"))
                "clipboard" -> row.addView(tool("📋", "clipboard", text, "Clipboard"))
                "emoji" -> row.addView(tool("😊", "emoji", text, "Emoji"))
                "harakat" -> { if (s.language == KeyboardLanguage.ARABIC) row.addView(tool("ـَ", "harakat", text, "Harakat")) }
                "ai" -> row.addView(tool("✨", "ai", argb(t.numberTextHex), "AI tools"))
                "settings" -> row.addView(tool("⚙", "settings", text, "Settings"))
            }
        }
        if (s.language == KeyboardLanguage.ARABIC && "harakat" !in p.toolbarOrder) row.addView(tool("ـَ", "harakat", text, "Harakat"))
        row.addView(tool("◀", "left", argb(t.symbolTextHex), "Cursor left"))
        row.addView(tool("▶", "right", argb(t.symbolTextHex), "Cursor right"))
        return row
    }

    private fun suggestionRow(t: KeyboardThemeSpec, s: SurfaceState, a: KeyboardActions, h: Int): View {
        val row = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER }
        s.suggestions.take(3).forEach { word ->
            row.addView(TextView(context).apply {
                text = word; textSize = 16f; gravity = Gravity.CENTER; maxLines = 1
                setTextColor(argb(t.keyTextHex))
                layoutParams = LinearLayout.LayoutParams(0, h, 1f)
                setOnClickListener { a.onSuggestion(word) }
            })
        }
        return row
    }

    // ---------- keys ----------
    private fun shape(color: Int, radius: Float, t: KeyboardThemeSpec) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
        if (t.borderWidthDp > 0f) setStroke(maxOf(1, (t.borderWidthDp * density).toInt()), argb(t.borderHex))
    }

    private fun base(label: String, color: Int, textColor: Int, t: KeyboardThemeSpec, h: Int, gap: Int, radius: Float, w: Float, sizeSp: Float): TextView =
        TextView(context).apply {
            text = label; textSize = sizeSp; gravity = Gravity.CENTER; maxLines = 1; setTextColor(textColor)
            background = shape(color, radius, t)
            layoutParams = LinearLayout.LayoutParams(0, h, w).apply { setMargins(gap / 2, gap / 2, gap / 2, gap / 2) }
            isHapticFeedbackEnabled = true
            // Visual press feedback only; returning false keeps click/long-click working.
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.alpha = 0.65f
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1f
                }
                false
            }
        }

    private fun haptic(v: View, p: LisanUserPreferences?) { if (p == null || p.hapticFeedbackMs > 0) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

    private fun plain(label: String, t: KeyboardThemeSpec, h: Int, gap: Int, radius: Float, w: Float, onClick: () -> Unit) =
        base(label, argb(t.keySurfaceHex), argb(t.keyTextHex), t, h, gap, radius, w, 20f).apply {
            setOnClickListener { haptic(it, null); onClick() }
        }

    private fun special(label: String, t: KeyboardThemeSpec, h: Int, gap: Int, radius: Float, w: Float, onClick: () -> Unit) =
        base(label, argb(t.specialKeySurfaceHex), argb(t.keyTextHex), t, h, gap, radius, w, 16f).apply {
            setOnClickListener { haptic(it, null); onClick() }
        }

    private fun spaceKey(s: SurfaceState, t: KeyboardThemeSpec, h: Int, gap: Int, radius: Float, p: LisanUserPreferences, onClick: () -> Unit) =
        base(s.language.nativeName, argb(t.keySurfaceHex), argb(t.symbolTextHex), t, h, gap, radius, 4f, 13f).apply {
            setOnClickListener { haptic(it, p); onClick() }
        }

    private fun enterKey(t: KeyboardThemeSpec, h: Int, gap: Int, radius: Float, a: KeyboardActions) =
        base("⏎", argb(t.micKeyHex), Color.WHITE, t, h, gap, radius, 1.3f, 18f).apply {
            setOnClickListener { haptic(it, null); a.onEnter() }
        }

    /** Backspace repeats while held (character by character, then faster). */
    private fun backspaceKey(t: KeyboardThemeSpec, h: Int, gap: Int, radius: Float, a: KeyboardActions): TextView {
        val key = base("⌫", argb(t.specialKeySurfaceHex), argb(t.keyTextHex), t, h, gap, radius, 1.3f, 18f)
        val repeat = object : Runnable {
            override fun run() { a.onBackspace(); handler.postDelayed(this, 55) }
        }
        key.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { v.alpha = 0.65f; haptic(v, null); a.onBackspace(); handler.postDelayed(repeat, 400) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.alpha = 1f; handler.removeCallbacks(repeat) }
            }
            true
        }
        return key
    }

    private fun letterKey(
        key: KeySpec, p: LisanUserPreferences, t: KeyboardThemeSpec, s: SurfaceState, a: KeyboardActions,
        h: Int, gap: Int, radius: Float
    ): View {
        val latin = s.language != KeyboardLanguage.ARABIC && !s.symbols
        val label = if (latin && s.shifted) key.primaryLabel.uppercase() else key.primaryLabel
        val view = base(label, argb(t.keySurfaceHex), argb(t.keyTextHex), t, h, gap, radius, key.weight, p.letterSizeSp)
        view.setOnClickListener {
            haptic(it, p)
            a.onText(if (latin && s.shifted) key.outputText.uppercase() else key.outputText)
        }
        if (key.longPressAlternates.isNotEmpty()) view.setOnLongClickListener { v ->
            showAlternates(v, key.longPressAlternates, t, a); true
        }
        return view
    }

    private fun keyRow(
        keys: List<KeySpec>, p: LisanUserPreferences, t: KeyboardThemeSpec, s: SurfaceState, a: KeyboardActions,
        h: Int, gap: Int, radius: Float, harakat: Boolean = false, numbers: Boolean = false
    ): View {
        val line = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER }
        keys.forEach { key ->
            val shown = when {
                harakat -> "ـ" + key.primaryLabel.removePrefix("ـ").ifEmpty { key.primaryLabel } // tatweel carrier so the mark is visible
                numbers && s.language == KeyboardLanguage.ARABIC -> key.longPressAlternates.firstOrNull() ?: key.primaryLabel
                else -> key.primaryLabel
            }
            val color = if (numbers) argb(t.numberTextHex) else argb(t.keyTextHex)
            val v = base(if (key.primaryLabel == "ـ") "ـ" else shown, argb(t.specialKeySurfaceHex), color, t, h, gap, radius, 1f, 16f)
            v.setOnClickListener {
                haptic(it, p)
                // In the Arabic number row the label is Eastern Arabic-Indic; commit exactly what is shown.
                a.onText(if (numbers && s.language == KeyboardLanguage.ARABIC) shown else key.outputText)
            }
            if (key.longPressAlternates.isNotEmpty()) v.setOnLongClickListener { x -> showAlternates(x, listOf(key.outputText) + key.longPressAlternates, t, a); true }
            line.addView(v)
        }
        return line
    }

    private fun showAlternates(anchor: View, alts: List<String>, t: KeyboardThemeSpec, a: KeyboardActions) {
        val box = LinearLayout(context).apply {
            orientation = HORIZONTAL
            background = GradientDrawable().apply { setColor(argb(t.specialKeySurfaceHex)); cornerRadius = dp(10).toFloat(); setStroke(dp(1), argb(t.borderHex)) }
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val popup = PopupWindow(box, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, false)
        popup.isOutsideTouchable = true
        alts.distinct().forEach { alt ->
            box.addView(TextView(context).apply {
                text = alt; textSize = 24f; setTextColor(argb(t.keyTextHex)); gravity = Gravity.CENTER
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setOnClickListener { a.onText(alt); popup.dismiss() }
            })
        }
        popup.showAsDropDown(anchor, 0, -(anchor.height * 2 + dp(10)), Gravity.START)
    }

    override fun onDetachedFromWindow() { handler.removeCallbacksAndMessages(null); super.onDetachedFromWindow() }
}
