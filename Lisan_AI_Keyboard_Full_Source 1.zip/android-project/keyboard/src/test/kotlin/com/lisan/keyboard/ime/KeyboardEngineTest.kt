package com.lisan.keyboard.ime

import com.lisan.keyboard.core.KeyboardLanguage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class KeyboardEngineTest {
    @Test
    fun `arabic layout includes harakat diacritics and connected letter keys`() {
        assertEquals(10, KeyboardLayoutRegistry.arabicHarakatKeys.size)
        assertTrue(KeyboardLayoutRegistry.arabicHarakatKeys.any { it.outputText == "ّ" })
        assertTrue(KeyboardLayoutRegistry.getLetterRows(KeyboardLanguage.ARABIC).flatten().any { it.primaryLabel == "ض" })
    }

    @Test
    fun `english layout renders 3 standard QWERTY rows`() {
        val rows = KeyboardLayoutRegistry.getLetterRows(KeyboardLanguage.ENGLISH)
        assertEquals(3, rows.size)
        assertEquals(10, rows[0].size)
    }
}

class ArabicHelperTest {
    @Test
    fun `eastern digits conversion keeps non digits`() {
        assertEquals("١٢٣ abc", ArabicShapingHelper.toEasternArabicNumerals("123 abc"))
    }

    @Test
    fun `harakat detection`() {
        assertTrue(ArabicShapingHelper.isHarakat('َ'))
        assertTrue(!ArabicShapingHelper.isHarakat('ب'))
        assertEquals("مرحبا", ArabicShapingHelper.stripHarakatForSearchOnly("مَرْحَبا"))
    }

    @Test
    fun `symbol rows have three rows of ten keys`() {
        assertEquals(3, KeyboardLayoutRegistry.symbolRows.size)
        KeyboardLayoutRegistry.symbolRows.forEach { assertEquals(10, it.size) }
    }
}
