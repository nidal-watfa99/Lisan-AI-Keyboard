pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "LisanAIKeyboard"

include(":app")
include(":shared-core")
include(":privacy")
include(":settings")
include(":themes")
include(":language")
include(":prediction")
include(":emoji")
include(":clipboard")
include(":voice")
include(":translation")
include(":keyboard")
