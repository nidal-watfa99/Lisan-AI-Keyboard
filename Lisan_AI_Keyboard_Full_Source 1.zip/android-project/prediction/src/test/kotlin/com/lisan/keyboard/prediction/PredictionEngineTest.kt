package com.lisan.keyboard.prediction

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PredictionEngineTest {
    @Test
    fun `preserves arabic diacritics and never autocorrects voweled words`() {
        val engine = PredictionEngine()
        assertNull(engine.autocorrectCandidate("مَرْحَباً", "ar", 2))
    }

    @Test
    fun `personal dictionary words appear in suggestions`() {
        val engine = PredictionEngine()
        engine.addPersonalWord("نضال")
        val suggestions = engine.suggest("نض", null, "ar")
        assertTrue(suggestions.contains("نضال"))
        assertEquals(listOf("عليكم", "تحياتي", "أهلاً"), engine.suggest("", "السلام", "ar"))
    }
}
