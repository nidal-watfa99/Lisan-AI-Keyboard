package com.lisan.keyboard.prediction

/**
 * Bilingual Arabic/English autocorrect, next-word prediction, and personal dictionary engine.
 * Preserves Arabic Harakat (tashkeel) and never overrides ignored or sensitive words.
 */
class PredictionEngine {
    private val personalWords = linkedSetOf<String>()
    private val ignoredWords = hashSetOf<String>()

    private val arabicVocab = listOf(
        "السلام", "عليكم", "ورحمة", "الله", "وبركاته", "مرحباً", "أهلاً", "شكراً",
        "جزيلاً", "تطبيق", "لوحة", "المفاتيح", "الذكية", "لسان", "الترجمة", "الفورية",
        "الكتابة", "الصوتية", "اللغة", "العربية", "الإنجليزية", "ممتاز", "رائع", "اليوم"
    )

    private val englishVocab = listOf(
        "hello", "thanks", "please", "meeting", "tomorrow", "schedule", "keyboard",
        "translation", "message", "awesome", "welcome", "project", "update", "confirm"
    )

    private val arabicBigrams = mapOf(
        "السلام" to listOf("عليكم", "تحياتي", "أهلاً"),
        "عليكم" to listOf("ورحمة", "السلام", "جميعاً"),
        "شكراً" to listOf("جزيلاً", "لك", "لكم"),
        "لوحة" to listOf("المفاتيح", "لسان", "الكتابة")
    )

    private val englishBigrams = mapOf(
        "thank" to listOf("you", "you!", "everyone"),
        "good" to listOf("morning", "afternoon", "evening"),
        "see" to listOf("you", "soon", "tomorrow")
    )

    fun addPersonalWord(word: String) {
        val clean = word.trim()
        if (clean.isNotEmpty()) personalWords.add(clean)
    }

    fun removePersonalWord(word: String) {
        personalWords.remove(word.trim())
    }

    fun ignoreWord(word: String) {
        ignoredWords.add(word.trim().lowercase())
    }

    fun getPersonalWords(): List<String> = personalWords.toList()

    fun suggest(currentToken: String, previousWord: String?, langCode: String, limit: Int = 4): List<String> {
        val token = currentToken.trim()
        if (token.isEmpty()) {
            val prev = previousWord?.trim()
            if (!prev.isNullOrEmpty()) {
                val next = if (langCode == "ar") arabicBigrams[prev] else englishBigrams[prev.lowercase()]
                if (!next.isNullOrEmpty()) return next.take(limit)
            }
            return if (langCode == "ar") listOf("السلام", "مرحباً", "شكراً", "اليوم")
            else listOf("Hello", "Thanks", "Please", "Okay")
        }

        val pool = (personalWords + if (langCode == "ar") arabicVocab else englishVocab).distinct()
        return pool.filter {
            it.startsWith(token, ignoreCase = true) && !ignoredWords.contains(it.lowercase())
        }.take(limit)
    }

    fun autocorrectCandidate(token: String, langCode: String, level: Int): String? {
        if (level <= 0 || token.length < 2 || ignoredWords.contains(token.lowercase())) return null
        if (personalWords.any { it.equals(token, ignoreCase = true) }) return null
        // Never strip Arabic diacritics silently
        if (token.any { it in '\u064B'..'\u065F' }) return null

        val commonTyposEn = mapOf("teh" to "the", "recieve" to "receive", "adn" to "and", "thnak" to "thank")
        val commonTyposAr = mapOf("السلا" to "السلام", "شكرا" to "شكراً", "انشاء" to "إن شاء")

        return if (langCode == "ar") commonTyposAr[token] else commonTyposEn[token.lowercase()]
    }
}
