# APK Build & Installation Guide

## Prerequisites
1. Android Studio Ladybug (2024.2+) or newer.
2. JDK 17.
3. Android SDK Platform 35 (`compileSdk = 35`), Build-Tools `35.0.0`, and Android SDK Platform-Tools.

## Building Debug APK
2. Open the extracted folder in Android Studio (`File -> Open`).
3. Allow Gradle Sync to download dependencies from `libs.versions.toml`.
4. Run from terminal or Android Studio:
   ```bash
   ./gradlew assembleDebug
   ```
   Output APK path: `app/build/outputs/apk/debug/app-debug.apk`.

## Building Signed Release APK
1. Configure a release keystore in `app/build.gradle.kts` via environment variables (never commit keystore passwords).
2. Run:
   ```bash
   ./gradlew assembleRelease
   ```

## Installing & Enabling Lisan Keyboard on Android
1. Install APK via USB debugging (`adb install -r app/build/outputs/apk/debug/app-debug.apk`) or transfer to your Android phone.
2. Open **Lisan AI Keyboard**.
3. Tap **1. Enable Keyboard** -> toggle **Lisan AI Keyboard – لسان** on in Android System Settings.
4. Tap **2. Select Lisan** -> pick **Lisan AI Keyboard** in the Input Method Picker.
5. Grant microphone permission only when using Voice-to-Text for the first time.

## Adding Languages
- Open **Language Manager** inside Lisan to toggle keyboard layouts (Arabic, English, French, Spanish, Turkish, German), select voice recognition language, and download ML Kit offline translation models.
