# Language & Offline Model Guide – دليل إضافة اللغات

Lisan separates four independent language preferences:
1. **Keyboard Layout Language**: Arabic (RTL + Harakat), English, French, Spanish, Turkish, German.
2. **Voice Recognition Language**: Manual selection or automatic detection.
3. **Translation Target Language**: Defaults to device language or user selection.
4. **App Interface Language**: Arabic (RTL) or English (LTR).

To add or download languages:
- Open **Languages & Packs** in Lisan.
- Search for any supported language, enable it for the keyboard, or tap **Download Model** to cache the Google ML Kit offline translation model on your device.
