# Privacy Policy – Lisan AI Keyboard (لسان)

1. **Zero Keylogging**: Lisan never records, logs, or transmits your keystrokes.
2. **Password & Sensitive Fields**: When Android signals a password, PIN, or incognito field (`InputType.TYPE_TEXT_VARIATION_PASSWORD` or `IME_FLAG_NO_PERSONALIZED_LEARNING`), predictions, personal learning, and all cloud AI tools are automatically disabled.
3. **Clipboard Respect**: Lisan never reads your system clipboard in the background. Clipboard items are accessed only when you explicitly open the Clipboard tool or tap Import.
4. **Voice & Microphone**: Microphone recording starts only when you press the microphone button and stops immediately when you finish. Audio is never recorded in the background or stored after transcription.
5. **Cloud AI Transparency**: On-device features (typing, local dictionary, ML Kit downloaded models) work offline. Cloud translation and AI writing assistance run ONLY when you explicitly trigger them and have enabled Cloud AI in Settings.
6. **Local Data Control**: You can delete all local preferences, personal words, translation history, and clipboard entries at any time from Privacy Settings.
7. **Support & Contact**: Issue reports sent to `nidalwatfa99@gmail.com` exclude personal typed text and clipboard contents, and redact emails/long numbers if diagnostic logs are attached with your permission.
