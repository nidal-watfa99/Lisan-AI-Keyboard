# Dependencies & Open-Source Licenses

## Android / Kotlin Dependencies
- AndroidX Core KTX, Activity Compose, Navigation Compose, Core SplashScreen — Apache License 2.0
- Jetpack Compose BOM & Material 3 — Apache License 2.0
- Kotlin Coroutines & Kotlinx Serialization — Apache License 2.0
- AndroidX DataStore & Room — Apache License 2.0
- AndroidX Security Crypto (Jetpack Security) — Apache License 2.0
- Google ML Kit Translate & Language ID — Google APIs Terms of Service

## Open-License Fonts Referenced in Font Library
- **Noto Sans Arabic / Noto Naskh Arabic / Noto Sans** — SIL Open Font License 1.1 (OFL)
- **Amiri** — SIL Open Font License 1.1 (OFL)
- **Cairo** — SIL Open Font License 1.1 (OFL)
- **Tajawal** — SIL Open Font License 1.1 (OFL)
- **IBM Plex Sans Arabic** — SIL Open Font License 1.1 (OFL)
- **Lato / Open Sans / Plus Jakarta Sans / DM Sans** — SIL Open Font License 1.1 (OFL)
- **Roboto** — Apache License 2.0
