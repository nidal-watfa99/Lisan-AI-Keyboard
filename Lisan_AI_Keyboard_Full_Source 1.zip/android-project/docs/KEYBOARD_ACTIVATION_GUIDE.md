# Keyboard Activation Guide – دليل تفعيل لوحة المفاتيح

1. Open **Lisan AI Keyboard – لسان** from your Android home screen or app drawer.
2. Tap **1. Enable Keyboard** to open Android System `On-screen keyboard` settings.
3. Toggle **Lisan AI Keyboard – لسان** ON and confirm the standard Android system IME security notice.
4. Return to Lisan and tap **2. Select Lisan** (or tap the keyboard icon in your Android navigation bar) to select **Lisan AI Keyboard** as your active input method.
5. Open WhatsApp, Telegram, Gmail, Notes, or any text box to start typing with Lisan.
