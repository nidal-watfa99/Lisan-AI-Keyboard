# Installation Guide – دليل التثبيت

2. Open the `android-project` folder inside **Android Studio Ladybug (2024.2+)**.
3. Wait for Gradle Sync to finish downloading dependencies (`Compose`, `Room`, `DataStore`, `Security Crypto`, `ML Kit`).
4. Connect an Android device (API 26+) with USB Debugging enabled, or launch an Android Virtual Device (AVD).
5. Click **Run 'app'** in Android Studio or execute `./gradlew installDebug` from the terminal.
