# Lisan AI Keyboard – لسان

**Write, speak, and translate... in your language and every language.**

Lisan AI Keyboard is a modular, privacy-first Android Input Method Editor (`InputMethodService`) built with Kotlin, Jetpack Compose, Material Design 3, Room, DataStore, Android Keystore, and Google ML Kit.

## Modules
- `app`: Launcher Activity, SplashScreen, Onboarding Wizard, Android Sharesheet, Developer Support (`nidalwatfa99@gmail.com`).
- `keyboard`: `LisanInputMethodService`, Arabic/English/Harakat layouts, cursor navigation, password sensitivity detection.
- `translation`: Google ML Kit on-device translation + language identification + explicit-consent cloud gateway interface.
- `voice`: `AndroidVoiceRecognizerAdapter` wrapping Android `SpeechRecognizer` with on-device preference and error recovery.
- `clipboard`: Room-backed Clipboard Manager (explicit user read only; never spies in background).
- `language`: Language pack & offline model download manager.
- `themes`: 4 signature design models (`Premium Dark`, `Modern Light`, `Gradient AI`, `Minimal Professional`) + JSON theme import/export.
- `prediction`: Bilingual Arabic/English autocorrect, bigram predictions, personal dictionary, Arabic diacritic preservation.
- `emoji`: Unicode emoji catalog with categories, search, and skin tone modifiers.
- `settings`: DataStore-backed preferences + JSON backup/restore.
- `privacy`: `InputSecurityClassifier`, AES-256 Keystore vault, log redaction, data wipe.
- `shared-core`: Platform-agnostic Kotlin interfaces structured for future Swift/iOS parity.

## Honest Environment & Build Note
This source archive was authored and verified structurally inside a Node.js/Web environment where JDK, Android SDK, and Gradle binaries are absent. Therefore, `.apk` compilation and on-device Android IME tests must be run locally in Android Studio or a CI runner with Android SDK 35 & JDK 17. See `docs/APK_BUILD_GUIDE.md` and `docs/FEATURES_STATUS.md`.
