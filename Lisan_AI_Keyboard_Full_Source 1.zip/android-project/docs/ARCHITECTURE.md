# Architecture & Cross-Platform Readiness

Lisan AI Keyboard follows **Clean Modular Architecture** with unidirectional state flow (`Kotlin Coroutines + StateFlow`).

## Module Dependency Graph
- `:shared-core` — Platform-agnostic contracts (`KeyboardLanguage`, `InputSensitivity`, `TranslationServiceContract`, `VoiceRecognizerContract`), ready to map directly to Swift protocols for a future iOS `UIInputViewController` extension.
- `:privacy` — `InputSecurityClassifier` (detects `TYPE_TEXT_VARIATION_PASSWORD`, `IME_FLAG_NO_PERSONALIZED_LEARNING`), `PrivacyGuard` (Android Keystore `EncryptedSharedPreferences`, crash log redaction, full local wipe).
- `:themes` — `ThemeGallery` (4 signature models + custom themes) and `ThemeSerializer` (JSON import/export).
- `:settings` — `SettingsRepository` backed by Jetpack `DataStore<Preferences>`.
- `:language` — `LanguagePackManager` separating keyboard layout language, voice language, translation target language, and app UI language.
- `:prediction` — `PredictionEngine` (Arabic/English dictionaries, bigram predictions, diacritic preservation).
- `:emoji` — `EmojiCatalog` (Unicode categories, search, skin-tone modifiers).
- `:clipboard` — `ClipboardRepository` + Room DAO (on-demand user-triggered read only).
- `:voice` — `AndroidVoiceRecognizerAdapter` (system & on-device `SpeechRecognizer`).
- `:translation` — `MlKitTranslationEngine` (Google ML Kit Translate & Language ID + optional HTTPS cloud gateway).
- `:keyboard` — `LisanInputMethodService` hosting a Jetpack Compose keyboard UI.
- `:app` — `MainActivity` onboarding, activation helper, testbed, native Sharesheet, developer report (`nidalwatfa99@gmail.com`).
