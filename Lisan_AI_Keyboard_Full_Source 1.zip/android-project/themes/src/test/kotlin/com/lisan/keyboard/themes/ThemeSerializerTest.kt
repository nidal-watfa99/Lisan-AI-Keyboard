package com.lisan.keyboard.themes

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ThemeSerializerTest {
    @Test
    fun `round-trip export and import preserves theme specification`() {
        val original = ThemeGallery.signatureModels.first()
        val encoded = ThemeSerializer.exportTheme(original)
        val decoded = ThemeSerializer.importTheme(encoded)
        assertTrue(decoded.isSuccess)
        assertEquals(original, decoded.getOrThrow())
    }
}
