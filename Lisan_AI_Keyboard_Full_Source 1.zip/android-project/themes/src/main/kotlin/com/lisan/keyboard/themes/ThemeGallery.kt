package com.lisan.keyboard.themes

import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
enum class KeyboardDesignModel {
    PREMIUM_DARK,
    MODERN_LIGHT,
    GRADIENT_AI,
    MINIMAL_PROFESSIONAL
}

@Serializable
enum class KeyShapeStyle {
    ROUNDED_RECT,
    PILL,
    SHARP_MODULAR,
    SOFT_SQUIRCLE
}

@Serializable
data class KeyboardThemeSpec(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val category: String,
    val model: KeyboardDesignModel,
    val backgroundHex: Long,
    val backgroundGradientEndHex: Long? = null,
    val backgroundOpacity: Float = 1.0f,
    val keySurfaceHex: Long,
    val keyTextHex: Long,
    val numberTextHex: Long,
    val symbolTextHex: Long,
    val specialKeySurfaceHex: Long,
    val micKeyHex: Long,
    val translateKeyHex: Long,
    val borderHex: Long,
    val borderWidthDp: Float = 1.0f,
    val cornerRadiusDp: Float = 8.0f,
    val shadowElevationDp: Float = 1.0f,
    val keyShape: KeyShapeStyle = KeyShapeStyle.ROUNDED_RECT
)

object ThemeGallery {
    val signatureModels: List<KeyboardThemeSpec> = listOf(
        KeyboardThemeSpec(
            id = "premium_dark",
            nameEn = "Premium Dark",
            nameAr = "الداكن الفاخر",
            category = "Signature",
            model = KeyboardDesignModel.PREMIUM_DARK,
            backgroundHex = 0xFF0B0F19,
            keySurfaceHex = 0xFF171E2E,
            keyTextHex = 0xFFF8FAFC,
            numberTextHex = 0xFFCBD5E1,
            symbolTextHex = 0xFF94A3B8,
            specialKeySurfaceHex = 0xFF1E293B,
            micKeyHex = 0xFF4F46E5,
            translateKeyHex = 0xFF0EA5E9,
            borderHex = 0xFF283548,
            cornerRadiusDp = 9f,
            shadowElevationDp = 2f
        ),
        KeyboardThemeSpec(
            id = "modern_light",
            nameEn = "Modern Light",
            nameAr = "الفاتح العصري",
            category = "Signature",
            model = KeyboardDesignModel.MODERN_LIGHT,
            backgroundHex = 0xFFF1F5F9,
            keySurfaceHex = 0xFFFFFFFF,
            keyTextHex = 0xFF0F172A,
            numberTextHex = 0xFF334155,
            symbolTextHex = 0xFF64748B,
            specialKeySurfaceHex = 0xFFE2E8F0,
            micKeyHex = 0xFF2563EB,
            translateKeyHex = 0xFF0D9488,
            borderHex = 0xFFCBD5E1,
            cornerRadiusDp = 9f,
            shadowElevationDp = 1.5f
        ),
        KeyboardThemeSpec(
            id = "gradient_ai",
            nameEn = "Gradient AI",
            nameAr = "التدرج الذكي",
            category = "Signature",
            model = KeyboardDesignModel.GRADIENT_AI,
            backgroundHex = 0xFF111827,
            backgroundGradientEndHex = 0xFF1E1B4B,
            keySurfaceHex = 0xFF1F2937,
            keyTextHex = 0xFFF9FAFB,
            numberTextHex = 0xFFA5B4FC,
            symbolTextHex = 0xFF93C5FD,
            specialKeySurfaceHex = 0xFF312E81,
            micKeyHex = 0xFF6366F1,
            translateKeyHex = 0xFF06B6D4,
            borderHex = 0xFF4338CA,
            cornerRadiusDp = 12f,
            shadowElevationDp = 3f
        ),
        KeyboardThemeSpec(
            id = "minimal_professional",
            nameEn = "Minimal Professional",
            nameAr = "الاحترافي البسيط",
            category = "Signature",
            model = KeyboardDesignModel.MINIMAL_PROFESSIONAL,
            backgroundHex = 0xFFF8FAFC,
            keySurfaceHex = 0xFFF1F5F9,
            keyTextHex = 0xFF1E293B,
            numberTextHex = 0xFF475569,
            symbolTextHex = 0xFF64748B,
            specialKeySurfaceHex = 0xFFE2E8F0,
            micKeyHex = 0xFF0F172A,
            translateKeyHex = 0xFF334155,
            borderHex = 0xFFE2E8F0,
            borderWidthDp = 0.5f,
            cornerRadiusDp = 6f,
            shadowElevationDp = 0f,
            keyShape = KeyShapeStyle.SHARP_MODULAR
        )
    )
}

object ThemeSerializer {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    fun exportTheme(spec: KeyboardThemeSpec): String = json.encodeToString(spec)
    fun importTheme(rawJson: String): Result<KeyboardThemeSpec> = runCatching {
        json.decodeFromString<KeyboardThemeSpec>(rawJson)
    }
}
