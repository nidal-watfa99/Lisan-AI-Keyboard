package com.lisan.keyboard.privacy

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PrivacyGuardTest {
    @Test
    fun `redactCrashDiagnostics strips emails and long numeric tokens`() {
        val sample = "Crash at user nidal@example.com with token 9876543210"
        val redacted = sample
            .replace(Regex("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}"), "[REDACTED_EMAIL]")
            .replace(Regex("\\b\\d{6,}\\b"), "[REDACTED_NUM]")
        assertFalse(redacted.contains("nidal@example.com"))
        assertFalse(redacted.contains("9876543210"))
        assertTrue(redacted.contains("[REDACTED_EMAIL]"))
        assertTrue(redacted.contains("[REDACTED_NUM]"))
    }
}
