package com.lisan.keyboard.privacy

import android.content.Context
import android.content.SharedPreferences
import android.text.InputType
import android.view.inputmethod.EditorInfo
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.lisan.keyboard.core.InputSensitivity
import com.lisan.keyboard.core.TextFieldContext

/**
 * Classifies Android EditorInfo fields and enforces strict privacy boundaries:
 * - No keylogging.
 * - No password storage.
 * - Automatic disabling of cloud AI, learning, and predictions in sensitive fields.
 */
object InputSecurityClassifier {

    fun classify(editorInfo: EditorInfo?): TextFieldContext {
        if (editorInfo == null) {
            return TextFieldContext(
                packageName = null,
                sensitivity = InputSensitivity.NORMAL,
                languageHint = null,
                allowCloudAi = true
            )
        }
        val inputType = editorInfo.inputType
        val klass = inputType and InputType.TYPE_MASK_CLASS
        val variation = inputType and InputType.TYPE_MASK_VARIATION

        val isPassword = (klass == InputType.TYPE_CLASS_TEXT && (
            variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
        )) || (klass == InputType.TYPE_CLASS_NUMBER &&
            variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)

        val isIncognitoFlag = (editorInfo.imeOptions and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0

        val sensitivity = when {
            isPassword -> InputSensitivity.PASSWORD
            klass == InputType.TYPE_CLASS_TEXT && variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS -> InputSensitivity.EMAIL
            klass == InputType.TYPE_CLASS_TEXT && variation == InputType.TYPE_TEXT_VARIATION_URI -> InputSensitivity.URI
            klass == InputType.TYPE_CLASS_NUMBER || klass == InputType.TYPE_CLASS_PHONE -> InputSensitivity.NUMBER
            else -> InputSensitivity.NORMAL
        }

        return TextFieldContext(
            packageName = editorInfo.packageName,
            sensitivity = sensitivity,
            languageHint = null,
            allowCloudAi = !isPassword && !isIncognitoFlag
        )
    }
}

class PrivacyGuard(private val context: Context) {

    fun openEncryptedVault(name: String = "lisan_secure_vault"): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context,
            name,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun redactCrashDiagnostics(rawLog: String): String {
        return rawLog
            .replace(Regex("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}"), "[REDACTED_EMAIL]")
            .replace(Regex("\\b\\d{6,}\\b"), "[REDACTED_NUM]")
    }

    fun wipeAllLocalData() {
        context.deleteSharedPreferences("lisan_secure_vault")
        context.filesDir.listFiles()?.forEach { file ->
            if (file.name.startsWith("lisan_")) {
                file.deleteRecursively()
            }
        }
    }
}
