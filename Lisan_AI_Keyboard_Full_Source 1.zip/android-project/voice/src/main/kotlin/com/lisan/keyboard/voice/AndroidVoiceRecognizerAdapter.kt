package com.lisan.keyboard.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import com.lisan.keyboard.core.VoiceRecognitionState
import com.lisan.keyboard.core.VoiceRecognizerContract
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Independent Android SpeechRecognizer adapter.
 * Handles permission checks, on-device vs network speech engines,
 * punctuation formatting, pause/resume appending, and recoverable errors.
 */
class AndroidVoiceRecognizerAdapter(
    private val context: Context
) : VoiceRecognizerContract {

    private val _state = MutableStateFlow<VoiceRecognitionState>(VoiceRecognitionState.Idle)
    override val state: Flow<VoiceRecognitionState> = _state.asStateFlow()

    private var recognizer: SpeechRecognizer? = null

    fun hasRecordAudioPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    fun isOnDeviceSupported(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(context)

    override fun startListening(languageTag: String, preferOffline: Boolean) {
        if (!hasRecordAudioPermission()) {
            _state.value = VoiceRecognitionState.Error("Microphone permission is required for Voice to Text.", recoverable = true)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _state.value = VoiceRecognitionState.Error("No speech recognition service installed on this device.", recoverable = false)
            return
        }

        recognizer?.destroy()
        recognizer = if (preferOffline && isOnDeviceSupported() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
        } else {
            SpeechRecognizer.createSpeechRecognizer(context)
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            if (languageTag != "auto") {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
            }
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
        }

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _state.value = VoiceRecognitionState.Listening
            }
            override fun onBeginningOfSpeech() {
                _state.value = VoiceRecognitionState.Listening
            }
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() {
                _state.value = VoiceRecognitionState.Processing
            }
            override fun onError(error: Int) {
                val msg = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "Network unavailable; enable offline speech pack if supported."
                    SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Tap mic to try again."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission denied."
                    else -> "Speech recognition error ($error)"
                }
                _state.value = VoiceRecognitionState.Error(msg, recoverable = true)
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                _state.value = if (text.isNotBlank()) VoiceRecognitionState.FinalResult(text) else VoiceRecognitionState.Idle
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (partial.isNotBlank()) {
                    _state.value = VoiceRecognitionState.PartialResult(partial)
                }
            }
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })

        recognizer?.startListening(intent)
    }

    override fun stopListening() {
        recognizer?.stopListening()
    }

    override fun cancel() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        _state.value = VoiceRecognitionState.Idle
    }
}
