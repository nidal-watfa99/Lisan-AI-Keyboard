package com.lisan.keyboard.translation

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.lisan.keyboard.core.TranslationResult
import com.lisan.keyboard.core.TranslationServiceContract
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

interface CloudTranslationGateway {
    suspend fun translateViaHttps(text: String, sourceLang: String, targetLang: String): Result<String>
}

/**
 * Google ML Kit on-device translation engine with verifiable model management
 * and explicit user-consent cloud fallback hook (no keys embedded in APK).
 */
class MlKitTranslationEngine(
    private val cloudGateway: CloudTranslationGateway? = null
) : TranslationServiceContract {

    private val modelManager = RemoteModelManager.getInstance()
    private val languageIdentifier = LanguageIdentification.getClient()

    private fun mapCode(code: String): String? = TranslateLanguage.fromLanguageTag(code)

    override suspend fun isOfflineModelDownloaded(langCode: String): Boolean =
        suspendCancellableCoroutine { cont ->
            val mapped = mapCode(langCode)
            if (mapped == null) {
                cont.resume(false)
                return@suspendCancellableCoroutine
            }
            val model = TranslateRemoteModel.Builder(mapped).build()
            modelManager.isModelDownloaded(model)
                .addOnSuccessListener { downloaded -> cont.resume(downloaded) }
                .addOnFailureListener { cont.resume(false) }
        }

    suspend fun downloadLanguageModel(langCode: String, requireWifi: Boolean = false): Result<Unit> =
        suspendCancellableCoroutine { cont ->
            val mapped = mapCode(langCode)
            if (mapped == null) {
                cont.resume(Result.failure(IllegalArgumentException("Unsupported ML Kit language: $langCode")))
                return@suspendCancellableCoroutine
            }
            val model = TranslateRemoteModel.Builder(mapped).build()
            val conditions = DownloadConditions.Builder().apply {
                if (requireWifi) requireWifi()
            }.build()
            modelManager.download(model, conditions)
                .addOnSuccessListener { cont.resume(Result.success(Unit)) }
                .addOnFailureListener { e -> cont.resume(Result.failure(e)) }
        }

    suspend fun deleteLanguageModel(langCode: String): Result<Unit> =
        suspendCancellableCoroutine { cont ->
            val mapped = mapCode(langCode) ?: return@suspendCancellableCoroutine cont.resume(Result.success(Unit))
            val model = TranslateRemoteModel.Builder(mapped).build()
            modelManager.deleteDownloadedModel(model)
                .addOnSuccessListener { cont.resume(Result.success(Unit)) }
                .addOnFailureListener { e -> cont.resume(Result.failure(e)) }
        }

    override suspend fun detectLanguage(text: String): Result<String> =
        suspendCancellableCoroutine { cont ->
            languageIdentifier.identifyLanguage(text)
                .addOnSuccessListener { tag ->
                    cont.resume(Result.success(if (tag == "und") "en" else tag))
                }
                .addOnFailureListener { e -> cont.resume(Result.failure(e)) }
        }

    override suspend fun translate(
        text: String,
        sourceLang: String,
        targetLang: String,
        allowCloudFallback: Boolean
    ): Result<TranslationResult> {
        val resolvedSource = if (sourceLang == "auto") {
            detectLanguage(text).getOrDefault("en")
        } else sourceLang

        val mlSrc = mapCode(resolvedSource)
        val mlDst = mapCode(targetLang)
        if (mlSrc != null && mlDst != null && isOfflineModelDownloaded(resolvedSource) && isOfflineModelDownloaded(targetLang)) {
            val onDeviceResult = translateOnDevice(text, mlSrc, mlDst)
            if (onDeviceResult.isSuccess) {
                return Result.success(
                    TranslationResult(
                        originalText = text,
                        translatedText = onDeviceResult.getOrThrow(),
                        sourceLang = resolvedSource,
                        targetLang = targetLang,
                        providerName = "Google ML Kit (On-Device)",
                        isOffline = true
                    )
                )
            }
        }

        if (allowCloudFallback && cloudGateway != null) {
            val cloud = cloudGateway.translateViaHttps(text, resolvedSource, targetLang)
            if (cloud.isSuccess) {
                return Result.success(
                    TranslationResult(
                        originalText = text,
                        translatedText = cloud.getOrThrow(),
                        sourceLang = resolvedSource,
                        targetLang = targetLang,
                        providerName = "Lisan HTTPS Cloud Translation",
                        isOffline = false
                    )
                )
            }
        }

        return Result.failure(
            IllegalStateException("Offline model not downloaded for $resolvedSource -> $targetLang and cloud translation is disabled.")
        )
    }

    private suspend fun translateOnDevice(text: String, src: String, dst: String): Result<String> =
        suspendCancellableCoroutine { cont ->
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(src)
                .setTargetLanguage(dst)
                .build()
            val translator = Translation.getClient(options)
            translator.translate(text)
                .addOnSuccessListener { translated ->
                    translator.close()
                    cont.resume(Result.success(translated))
                }
                .addOnFailureListener { err ->
                    translator.close()
                    cont.resume(Result.failure(err))
                }
        }
}
