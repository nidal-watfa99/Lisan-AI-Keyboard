package com.lisan.keyboard.emoji

enum class EmojiCategory(val titleEn: String, val titleAr: String) {
    RECENT("Recent", "المستخدمة مؤخراً"),
    FAVORITES("Favorites", "المفضلة"),
    SMILEYS("Smileys", "الوجوه"),
    ANIMALS("Animals", "الحيوانات"),
    FOOD("Food", "الطعام"),
    NATURE("Nature", "الطبيعة"),
    TRAVEL("Travel", "السفر"),
    ACTIVITIES("Activities", "الأنشطة"),
    OBJECTS("Objects", "الأشياء"),
    SYMBOLS("Symbols", "الرموز"),
    FLAGS("Flags", "الأعلام")
}

data class EmojiItem(
    val glyph: String,
    val nameEn: String,
    val nameAr: String,
    val category: EmojiCategory,
    val supportsSkinTone: Boolean = false
)

object EmojiCatalog {
    val skinToneModifiers = listOf("", "\uD83C\uDFFB", "\uD83C\uDFFC", "\uD83C\uDFFD", "\uD83C\uDFFE", "\uD83C\uDFFF")

    val items: List<EmojiItem> = listOf(
        EmojiItem("😀", "grinning face", "وجه مبتسم", EmojiCategory.SMILEYS),
        EmojiItem("😂", "tears of joy", "ضحك", EmojiCategory.SMILEYS),
        EmojiItem("❤️", "red heart", "قلب أحمر", EmojiCategory.SYMBOLS),
        EmojiItem("👍", "thumbs up", "إعجاب", EmojiCategory.SMILEYS, supportsSkinTone = true),
        EmojiItem("🙏", "folded hands", "شكر", EmojiCategory.SMILEYS, supportsSkinTone = true),
        EmojiItem("👋", "waving hand", "تلويح", EmojiCategory.SMILEYS, supportsSkinTone = true),
        EmojiItem("🦁", "lion", "أسد", EmojiCategory.ANIMALS),
        EmojiItem("☕", "coffee", "قهوة", EmojiCategory.FOOD),
        EmojiItem("🌙", "crescent moon", "هلال", EmojiCategory.NATURE),
        EmojiItem("✈️", "airplane", "طائرة", EmojiCategory.TRAVEL),
        EmojiItem("⚽", "soccer ball", "كرة قدم", EmojiCategory.ACTIVITIES),
        EmojiItem("💻", "laptop", "حاسوب", EmojiCategory.OBJECTS),
        EmojiItem("🇸🇦", "Saudi Arabia", "السعودية", EmojiCategory.FLAGS),
        EmojiItem("🇦🇪", "UAE", "الإمارات", EmojiCategory.FLAGS),
        EmojiItem("🇪🇬", "Egypt", "مصر", EmojiCategory.FLAGS),
        EmojiItem("🇵🇸", "Palestine", "فلسطين", EmojiCategory.FLAGS),
        EmojiItem("🇬🇧", "UK", "بريطانيا", EmojiCategory.FLAGS),
        EmojiItem("🇺🇸", "USA", "أمريكا", EmojiCategory.FLAGS)
    )

    fun applySkinTone(item: EmojiItem, modifier: String): String {
        if (!item.supportsSkinTone || modifier.isEmpty()) return item.glyph
        return item.glyph + modifier
    }
}
