package com.lisan.keyboard.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.lisanDataStore: DataStore<Preferences> by preferencesDataStore(name = "lisan_settings")

@Serializable
data class LisanUserPreferences(
    val activeKeyboardLanguage: String = "ar",
    val voiceLanguage: String = "ar-SA",
    val translationTargetLanguage: String = "", // blank = device language
    val appUiLanguage: String = "ar",
    val activeThemeId: String = "premium_dark",
    val fontFamilyId: String = "noto_sans_arabic",
    val keyHeightDp: Int = 44,
    val cornerRadiusDp: Int = 9,
    val keyboardWidthPercent: Int = 100,
    val keySpacingDp: Float = 5f,
    val letterSizeSp: Float = 19f,
    val symbolSizeSp: Float = 13f,
    val toolbarHeightDp: Int = 36,
    val showNumberRow: Boolean = true,
    val showSuggestionsRow: Boolean = true,
    val showToolbarRow: Boolean = true,
    val showArabicHarakatRow: Boolean = false,
    val autocorrectLevel: Int = 0, // 0 = off (default), 1 = gentle, 2 = standard, 3 = strict
    val enablePredictions: Boolean = true,
    val preserveArabicDiacritics: Boolean = true,
    val enableClipboardHistory: Boolean = true,
    val enableCloudAiAssistant: Boolean = false, // explicit opt-in
    val allowCloudTranslation: Boolean = false, // explicit opt-in
    val hapticFeedbackMs: Int = 12,
    val soundOnKeypress: Boolean = false,
    val enabledKeyboardLanguages: List<String> = listOf("ar", "en"),
    val toolbarOrder: List<String> = listOf("voice", "translate", "clipboard", "emoji", "ai", "settings")
)

class SettingsRepository(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
    private val prefsKey = stringPreferencesKey("lisan_prefs_json")

    val preferences: Flow<LisanUserPreferences> = context.lisanDataStore.data.map { prefs ->
        val raw = prefs[prefsKey]
        if (raw.isNullOrBlank()) LisanUserPreferences()
        else runCatching { json.decodeFromString<LisanUserPreferences>(raw) }.getOrDefault(LisanUserPreferences())
    }

    suspend fun update(transform: (LisanUserPreferences) -> LisanUserPreferences) {
        context.lisanDataStore.edit { prefs ->
            val current = prefs[prefsKey]?.let {
                runCatching { json.decodeFromString<LisanUserPreferences>(it) }.getOrNull()
            } ?: LisanUserPreferences()
            prefs[prefsKey] = json.encodeToString(transform(current))
        }
    }

    suspend fun resetDefaults() {
        context.lisanDataStore.edit { prefs ->
            prefs[prefsKey] = json.encodeToString(LisanUserPreferences())
        }
    }

    suspend fun exportBackupJson(current: LisanUserPreferences): String = json.encodeToString(current)
}
